#!/usr/bin/env python3
"""Builds "Quillio Installer.pkg" (a standard macOS installer wizard) without needing a Mac.

    python3 installer/build_pkg.py --wheels /path/to/wheelhouse --out dist/

Needs: pip install libarchive-c; bomutils' `mkbom` on PATH (https://github.com/hogliux/bomutils);
rsvg-convert (icon). On a Mac you can instead use Apple's pkgbuild/productbuild with the same files.

Layout of the finished package (same as productbuild output):
    Distribution, Resources/*.html, AcademicHubComponent.pkg/{PackageInfo,Bom,Payload,Scripts}
Payload  = the two apps for /Applications.
Scripts  = postinstall + the whole program + bundled Python packages (wheels).
"""
import argparse
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import libarchive

HERE = Path(__file__).resolve().parent
SRC = HERE.parent
VERSION = "1.0.0"
PKG_ID = "com.academichub.pkg"
UID, GID = 0, 80  # root:admin, like items in /Applications

APP_PLIST = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>{name}</string>
  <key>CFBundleDisplayName</key><string>{name}</string>
  <key>CFBundleIdentifier</key><string>{ident}</string>
  <key>CFBundleExecutable</key><string>{exe}</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleSignature</key><string>????</string>
  <key>CFBundleVersion</key><string>{version}</string>
  <key>CFBundleShortVersionString</key><string>{version}</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.education</string>
  <key>LSUIElement</key><{ui}/>
  <key>NSHumanReadableCopyright</key><string>Copyright 2026 RED</string>
</dict>
</plist>
"""

OPEN_APP = r"""#!/bin/bash
# Opens the Quillio dashboard window. The real work is in open-window.sh, which starts the window through
# launchd in your own desktop session (this keeps the window from coming up blank).
HOME_DIR="/Library/Application Support/AcademicHub"
if [ -x "$HOME_DIR/bin/open-window.sh" ]; then
  exec "$HOME_DIR/bin/open-window.sh"
fi
/usr/bin/osascript -e 'display dialog "Quillio is not set up on this Mac. Run the Quillio installer again." buttons {"OK"} default button "OK" with icon caution'
"""

UNINSTALL_APP = r"""#!/bin/bash
# Removes Quillio. Needs an administrator password.
SYS="/Library/Application Support/AcademicHub"
TMP="$(/usr/bin/mktemp -d)"
trap '/bin/rm -rf "$TMP"' EXIT

cat > "$TMP/gone.scpt" <<'AS'
display dialog "Quillio is not installed on this Mac." buttons {"OK"} default button "OK"
AS
cat > "$TMP/ask.scpt" <<'AS'
try
  set r to button returned of (display dialog "This removes Quillio. Your guarded apps will open normally again.\n\nKeep the quiz questions and results on this Mac?" with title "Uninstall Quillio" buttons {"Cancel", "Delete everything", "Keep my quizzes"} default button "Keep my quizzes" cancel button "Cancel" with icon note)
  return r
on error
  return "Cancel"
end try
AS
cat > "$TMP/run.scpt" <<'AS'
on run argv
  set flag to item 1 of argv
  try
    do shell script (quoted form of "/Library/Application Support/AcademicHub/bin/uninstall.sh") & " " & flag & " && /bin/rm -rf '/Applications/Quillio.app' && /usr/sbin/pkgutil --forget com.academichub.pkg >/dev/null 2>&1; (/bin/sleep 3; /bin/rm -rf '/Applications/Uninstall Quillio.app') >/dev/null 2>&1 &" with administrator privileges
    return "ok"
  on error msg
    return "error: " & msg
  end try
end run
AS
cat > "$TMP/done.scpt" <<'AS'
display dialog "Quillio has been removed." buttons {"OK"} default button "OK" with title "Uninstall Quillio"
AS
cat > "$TMP/fail.scpt" <<'AS'
on run argv
  display dialog ("Quillio was not removed." & return & return & (item 1 of argv)) buttons {"OK"} default button "OK" with title "Uninstall Quillio" with icon caution
end run
AS

if [ ! -x "$SYS/bin/uninstall.sh" ]; then
  /usr/bin/osascript "$TMP/gone.scpt" >/dev/null 2>&1
  /bin/rm -rf "/Applications/Quillio.app" >/dev/null 2>&1
  exit 0
fi

CHOICE="$(/usr/bin/osascript "$TMP/ask.scpt" 2>/dev/null)"
case "$CHOICE" in
  "Keep my quizzes")   FLAG="--keep-data" ;;
  "Delete everything") FLAG="--purge" ;;
  *) exit 0 ;;
esac

RESULT="$(/usr/bin/osascript "$TMP/run.scpt" "$FLAG" 2>&1)"
if [ "$RESULT" = "ok" ]; then
  /usr/bin/osascript "$TMP/done.scpt" >/dev/null 2>&1
else
  /usr/bin/osascript "$TMP/fail.scpt" "$RESULT" >/dev/null 2>&1
fi
"""


def make_icns(png_dir: Path, out: Path) -> None:
    """Write an .icns made of PNG images (no iconutil needed)."""
    types = [("icp4", 16), ("icp5", 32), ("icp6", 64), ("ic07", 128), ("ic08", 256), ("ic09", 512), ("ic10", 1024)]
    chunks = b""
    for code, size in types:
        data = (png_dir / f"{size}.png").read_bytes()
        chunks += code.encode() + (len(data) + 8).to_bytes(4, "big") + data
    out.write_bytes(b"icns" + (len(chunks) + 8).to_bytes(4, "big") + chunks)


def render_icon(work: Path) -> Path:
    mascot = (SRC / "academic_hub/static/mascot.svg").read_text()
    inner = re.sub(r"^<svg[^>]*>", "", mascot.strip())
    inner = re.sub(r"</svg>\s*$", "", inner)
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="1024" height="1024">
  <rect x="100" y="100" width="824" height="824" rx="190" fill="#DDF264"/>
  <rect x="100" y="100" width="824" height="824" rx="190" fill="none" stroke="#171715" stroke-width="14"/>
  <g transform="translate(176 190) scale(2.6)">{inner}</g>
</svg>"""
    (work / "icon.svg").write_text(svg)
    pngs = work / "png"
    pngs.mkdir()
    for size in (16, 32, 64, 128, 256, 512, 1024):
        subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size), str(work / "icon.svg"), "-o", str(pngs / f"{size}.png")], check=True)
    icns = work / "AppIcon.icns"
    make_icns(pngs, icns)
    return icns


def build_app(root: Path, app_name: str, exe: str, ident: str, script: str, icns: Path, windowed: bool = False) -> None:
    app = root / "Applications" / f"{app_name}.app" / "Contents"
    (app / "MacOS").mkdir(parents=True)
    (app / "Resources").mkdir()
    (app / "Info.plist").write_text(APP_PLIST.format(name=app_name, ident=ident, exe=exe, version=VERSION, ui="false" if windowed else "true"))
    (app / "PkgInfo").write_text("APPL????")
    sh = app / "MacOS" / exe
    sh.write_text(script)
    sh.chmod(0o755)
    shutil.copy(icns, app / "Resources" / "AppIcon.icns")


# ----------------------------------------------------------------------------- archives
def add_tree(writer, base: Path, prefix: str = "./", modes: dict | None = None) -> tuple[int, int]:
    """Add every file under base (cpio paths start with ./). Returns (file count, total bytes)."""
    modes = modes or {}
    count = size = 0
    writer.add_file_from_memory(prefix.rstrip("/") or ".", 0, b"", filetype=0o040000, permission=0o755, uid=UID, gid=GID)
    for path in sorted(base.rglob("*")):
        rel = path.relative_to(base).as_posix()
        name = prefix + rel
        if path.is_dir():
            writer.add_file_from_memory(name, 0, b"", filetype=0o040000, permission=0o755, uid=UID, gid=GID)
            continue
        data = path.read_bytes()
        perm = modes.get(rel, 0o755 if os.access(path, os.X_OK) else 0o644)
        writer.add_file_from_memory(name, len(data), data, filetype=0o100000, permission=perm, uid=UID, gid=GID)
        count += 1
        size += len(data)
    return count, size


def cpio_gz(base: Path, out: Path, modes: dict | None = None) -> tuple[int, int]:
    with libarchive.file_writer(str(out), "cpio", "gzip") as w:
        return add_tree(w, base, "./", modes)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wheels", help="folder with macOS wheels to bundle (offline installer, ~160 MB). Omit for a small installer that downloads them while installing.")
    ap.add_argument("--out", default=str(SRC / "dist"))
    args = ap.parse_args()
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    wheels = Path(args.wheels) if args.wheels else None
    if wheels and not list(wheels.glob("*.whl")):
        sys.exit(f"No .whl files in {wheels}")

    work = Path(tempfile.mkdtemp(prefix="ah-pkg-"))
    try:
        icns = render_icon(work)

        # ---- payload: the two apps
        root = work / "root"
        build_app(root, "Quillio", "AcademicHub", "com.academichub.app", OPEN_APP, icns, windowed=True)
        build_app(root, "Uninstall Quillio", "UninstallAcademicHub", "com.academichub.uninstall", UNINSTALL_APP, icns)

        # ---- scripts: postinstall + program + wheels
        scripts = work / "scripts"
        scripts.mkdir()
        shutil.copy(HERE / "scripts" / "postinstall", scripts / "postinstall")
        for f in ("install.sh", "uninstall.sh", "requirements.txt"):
            shutil.copy(SRC / f, scripts / f)
        shutil.copytree(SRC / "scripts", scripts / "scripts")
        shutil.copytree(SRC / "academic_hub", scripts / "academic_hub", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        if wheels:
            shutil.copytree(wheels, scripts / "wheels")

        # ---- component package
        comp = work / "comp"
        comp.mkdir()
        n_files, payload_bytes = cpio_gz(root, comp / "Payload")
        script_modes = {"postinstall": 0o755, "install.sh": 0o755, "uninstall.sh": 0o755,
                        "scripts/launch.sh": 0o755, "scripts/open-window.sh": 0o755, "scripts/quillio": 0o755}
        cpio_gz(scripts, comp / "Scripts", script_modes)
        subprocess.run(["mkbom", "-u", str(UID), "-g", str(GID), str(root), str(comp / "Bom")], check=True)
        kbytes = max(1, payload_bytes // 1024)
        n_entries = sum(1 for _ in root.rglob('*')) + 1
        (comp / "PackageInfo").write_text(
            f'<?xml version="1.0" encoding="utf-8"?>\n'
            f'<pkg-info overwrite-permissions="false" relocatable="false" identifier="{PKG_ID}" '
            f'postinstall-action="none" version="{VERSION}" format-version="2" generator-version="AcademicHubBuild-1" '
            f'install-location="/" auth="root">\n'
            f'  <payload numberOfFiles="{n_entries}" installKBytes="{kbytes}"/>\n'
            f'  <scripts>\n    <postinstall file="./postinstall"/>\n  </scripts>\n'
            f'</pkg-info>\n'
        )

        # ---- Distribution (the wizard)
        dist = f"""<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
    <title>Quillio</title>
    <organization>com.academichub</organization>
    <welcome file="welcome.html" mime-type="text/html"/>
    <readme file="readme.html" mime-type="text/html"/>
    <license file="license.html" mime-type="text/html"/>
    <conclusion file="conclusion.html" mime-type="text/html"/>
    <options customize="never" require-scripts="false" hostArchitectures="arm64,x86_64"/>
    <domains enable_anywhere="false" enable_currentUserHome="false" enable_localSystem="true"/>
    <volume-check>
        <allowed-os-versions>
            <os-version min="12.0"/>
        </allowed-os-versions>
    </volume-check>
    <choices-outline>
        <line choice="default">
            <line choice="{PKG_ID}"/>
        </line>
    </choices-outline>
    <choice id="default"/>
    <choice id="{PKG_ID}" visible="false" title="Quillio" description="Quillio">
        <pkg-ref id="{PKG_ID}"/>
    </choice>
    <pkg-ref id="{PKG_ID}" version="{VERSION}" installKBytes="{kbytes}" onConclusion="none">#AcademicHubComponent.pkg</pkg-ref>
</installer-gui-script>
"""

        # ---- product archive (xar)
        final = out_dir / ("Quillio Installer (offline).pkg" if wheels else "Quillio Installer.pkg")
        if final.exists():
            final.unlink()
        with libarchive.file_writer(str(final), "xar", None, options="compression=none") as w:
            def put(name: str, data: bytes, perm=0o644):
                w.add_file_from_memory(name, len(data), data, filetype=0o100000, permission=perm, uid=0, gid=0)

            def mkdir(name: str):
                w.add_file_from_memory(name, 0, b"", filetype=0o040000, permission=0o755, uid=0, gid=0)

            put("Distribution", dist.encode())
            mkdir("Resources")
            for html in sorted((HERE / "resources").glob("*.html")):
                put(f"Resources/{html.name}", html.read_bytes())
            mkdir("AcademicHubComponent.pkg")
            for f in ("PackageInfo", "Bom", "Payload", "Scripts"):
                put(f"AcademicHubComponent.pkg/{f}", (comp / f).read_bytes())
        print(f"Built {final} ({final.stat().st_size / 1e6:.1f} MB)")
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
