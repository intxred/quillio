# Starts Quillio's background helpers (monitor + dashboard) for the protected account.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from academic_hub import supervisor  # noqa: E402

supervisor.main()
