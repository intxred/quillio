# Quillio for Windows: private Python + packages. Run by the installer (as administrator).
param([Parameter(Mandatory = $true)][string]$InstallDir)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$pyDir = Join-Path $InstallDir "python"
$py = Join-Path $pyDir "python.exe"

if (-not (Test-Path $py)) {
    # A private copy of Python, so nothing else on the computer is touched or can clash.
    $url = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
    $md5 = "fe8ef205f2e9c3ba44d0cf9954e1abd3"   # published on python.org/downloads/release/python-31210/
    $zip = Join-Path $env:TEMP "academic-hub-python.zip"
    Write-Host "Downloading Python 3.12 from python.org (about 11 MB)..."
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    if ((Get-FileHash -Path $zip -Algorithm MD5).Hash.ToLower() -ne $md5) {
        Remove-Item $zip -Force
        throw "The downloaded Python file does not match the checksum published by python.org. Nothing was installed."
    }
    New-Item -ItemType Directory -Force -Path $pyDir | Out-Null
    Expand-Archive -Path $zip -DestinationPath $pyDir -Force
    Remove-Item $zip -Force
    # Let this Python see its packages and the Quillio program folder.
    New-Item -ItemType Directory -Force -Path (Join-Path $pyDir "Lib\site-packages") | Out-Null
    Set-Content -Path (Join-Path $pyDir "python312._pth") -Encoding ascii -Value @(
        "python312.zip", ".", "Lib\site-packages", "..\app", "import site")
}

$pip = Get-ChildItem (Join-Path $InstallDir "pip") -Filter "pip-*.whl" | Select-Object -First 1
if (-not $pip) { throw "The bundled pip file is missing. Run the installer again." }

Write-Host "Installing the program's packages (about 300 MB, this takes a few minutes)..."
& $py (Join-Path $pip.FullName "pip") install --disable-pip-version-check --no-warn-script-location `
    -r (Join-Path $InstallDir "app\requirements.txt")
if ($LASTEXITCODE -ne 0) { throw "Installing the packages failed (exit code $LASTEXITCODE). Check the internet connection and run the installer again." }

& $py -c "import PySide6.QtWidgets, psutil, sqlite3; print('Packages OK')"
if ($LASTEXITCODE -ne 0) { throw "The packages did not install correctly." }
& $py -c "from PySide6.QtWebEngineWidgets import QWebEngineView" 2>$null
if ($LASTEXITCODE -ne 0) { Write-Host "Note: the app window needs Qt WebEngine, which is missing. The dashboard will open in the browser instead." }
Write-Host "Done."
