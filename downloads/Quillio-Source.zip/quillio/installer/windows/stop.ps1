# Stops Quillio's background programs (used by the uninstaller).
param([Parameter(Mandatory = $true)][string]$InstallDir)
for ($i = 0; $i -lt 2; $i++) {
    Get-CimInstance Win32_Process |
        Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith((Join-Path $InstallDir "python"), [StringComparison]::OrdinalIgnoreCase) } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
}
