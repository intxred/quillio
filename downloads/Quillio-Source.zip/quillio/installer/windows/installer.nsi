; Quillio for Windows: installer wizard (NSIS). Built by installer/build_windows.py.
Unicode true
!define APP "Quillio"
!define VERSION "1.0.0"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\AcademicHub"

!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"

Name "${APP}"
OutFile "${OUTFILE}"
InstallDir "$PROGRAMFILES64\${APP}"
InstallDirRegKey HKLM "Software\AcademicHub" "InstallDir"
RequestExecutionLevel admin
BrandingText "${APP} ${VERSION}"
SetCompressor /SOLID lzma
ShowInstDetails show

!define MUI_ICON "${ICON}"
!define MUI_UNICON "${ICON}"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Welcome to ${APP}"
!define MUI_WELCOMEPAGE_TEXT "${APP} is a quiz and assessment app you fully customize: your own subjects, questions and pass mark. It can put a quiz in front of the apps you choose (Roblox to start with). When a guarded app is opened it is closed and a full-screen exam appears; pass the exam and the app opens.$\r$\n$\r$\nOnly the apps on your list are guarded. Everything else on this computer works normally. Everything stays on this computer.$\r$\n$\r$\nClick Next to continue."
!define MUI_LICENSEPAGE_CHECKBOX
!define MUI_LICENSEPAGE_CHECKBOX_TEXT "I have read and accept the license agreement"
!define MUI_FINISHPAGE_TITLE "${APP} is installed"
!define MUI_FINISHPAGE_TEXT "Open ${APP} now and create the admin PIN. The PIN unlocks the dashboard, the Exit button on the exam and the parent unlock button.$\r$\n$\r$\nThe protection starts as soon as the app opens, and after that every time the protected account signs in."
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Open ${APP} now"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp

Var AccountName
Var AccountEdit

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "${LICENSE}"
Page custom AccountPage AccountPageLeave
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  ReadEnvStr $AccountName "USERNAME"
FunctionEnd

Function AccountPage
  !insertmacro MUI_HEADER_TEXT "Choose the account to protect" "${APP} guards your chosen apps for one Windows account."
  nsDialogs::Create 1018
  Pop $0
  ${NSD_CreateLabel} 0 0 100% 36u "Type the Windows user name of the account that uses the guarded apps. Other accounts, for example yours as a parent, are not affected."
  Pop $0
  ${NSD_CreateText} 0 42u 50% 12u "$AccountName"
  Pop $AccountEdit
  ${NSD_CreateLabel} 0 64u 100% 48u "Tip: make that account a Standard (not Administrator) account in Settings, Accounts, Other users. A Standard account cannot remove ${APP}."
  Pop $0
  nsDialogs::Show
FunctionEnd

Function AccountPageLeave
  ${NSD_GetText} $AccountEdit $AccountName
  ${If} $AccountName == ""
    MessageBox MB_OK|MB_ICONEXCLAMATION "Please type a user name."
    Abort
  ${EndIf}
  nsExec::Exec 'net user "$AccountName"'
  Pop $0
  ${If} $0 != 0
    MessageBox MB_OK|MB_ICONEXCLAMATION "There is no Windows account called '$AccountName' on this computer. Check the spelling."
    Abort
  ${EndIf}
FunctionEnd

Section "Install"
  SetRegView 64
  SetShellVarContext all

  ; stop an older copy first
  IfFileExists "$INSTDIR\stop.ps1" 0 +2
    nsExec::Exec 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1" -InstallDir "$INSTDIR"'

  SetOutPath "$INSTDIR\app"
  File /r /x "__pycache__" "${SRC}/academic_hub"
  File "${SRC}/requirements.txt"
  File "${WIN}/protect.pyw"
  File "${WIN}/academic_hub_window.pyw"

  SetOutPath "$INSTDIR\pip"
  File "${PIPWHEEL}"

  SetOutPath "$INSTDIR"
  File "${WIN}/setup.ps1"
  File "${WIN}/stop.ps1"
  File "/oname=academic_hub.ico" "${ICON}"

  ; which account is protected
  FileOpen $0 "$INSTDIR\config.json" w
  FileWrite $0 '{"user": "$AccountName", "port": 8765}$\r$\n'
  FileClose $0

  DetailPrint "Setting up Python and the program's packages. This needs the internet and takes several minutes..."
  nsExec::ExecToLog 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\setup.ps1" -InstallDir "$INSTDIR"'
  Pop $0
  ${If} $0 != 0
    MessageBox MB_OK|MB_ICONSTOP "The setup did not finish (code $0). Check the internet connection and run the installer again. The messages above say what went wrong."
    Abort
  ${EndIf}

  ; start the protection every time the protected account signs in
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Run" "AcademicHub" '"$INSTDIR\python\pythonw.exe" "$INSTDIR\app\protect.pyw"'

  ; shortcuts (start in the app folder)
  SetOutPath "$INSTDIR\app"
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortcut "$SMPROGRAMS\${APP}\${APP}.lnk" "$INSTDIR\python\pythonw.exe" '"$INSTDIR\app\academic_hub_window.pyw"' "$INSTDIR\academic_hub.ico"
  CreateShortcut "$SMPROGRAMS\${APP}\Uninstall ${APP}.lnk" "$INSTDIR\uninstall.exe"
  CreateShortcut "$DESKTOP\${APP}.lnk" "$INSTDIR\python\pythonw.exe" '"$INSTDIR\app\academic_hub_window.pyw"' "$INSTDIR\academic_hub.ico"

  ; uninstaller + entry in Settings, Apps
  WriteUninstaller "$INSTDIR\uninstall.exe"
  WriteRegStr HKLM "Software\AcademicHub" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM "Software\AcademicHub" "Account" "$AccountName"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayName" "${APP}"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "${UNINST_KEY}" "Publisher" "RED"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\academic_hub.ico"
  WriteRegStr HKLM "${UNINST_KEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoRepair" 1
SectionEnd

Function LaunchApp
  SetShellVarContext all
  ; explorer starts it as the signed-in user (not with the installer's administrator rights)
  Exec '"$WINDIR\explorer.exe" "$SMPROGRAMS\${APP}\${APP}.lnk"'
FunctionEnd

Section "Uninstall"
  SetRegView 64
  SetShellVarContext all
  nsExec::Exec 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1" -InstallDir "$INSTDIR"'
  ReadRegStr $1 HKLM "Software\AcademicHub" "Account"

  DeleteRegValue HKLM "Software\Microsoft\Windows\CurrentVersion\Run" "AcademicHub"
  Delete "$DESKTOP\${APP}.lnk"
  RMDir /r "$SMPROGRAMS\${APP}"
  DeleteRegKey HKLM "${UNINST_KEY}"
  DeleteRegKey HKLM "Software\AcademicHub"

  SetOutPath "$TEMP"
  RMDir /r "$INSTDIR"

  ${If} $1 != ""
    MessageBox MB_YESNO|MB_ICONQUESTION "Also delete the quiz questions and results of the account '$1'?$\r$\n$\r$\nChoose No to keep them." IDNO keepdata
    ReadEnvStr $2 "SystemDrive"
    RMDir /r "$2\Users\$1\AppData\Local\AcademicHub"
  ${EndIf}
  keepdata:
SectionEnd
