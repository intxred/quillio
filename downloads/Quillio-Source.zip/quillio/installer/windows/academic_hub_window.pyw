# Opens the Quillio window (the dashboard).
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from academic_hub import dashboard_app  # noqa: E402

sys.exit(dashboard_app.main())
