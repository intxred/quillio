#!/usr/bin/env python3
"""Builds "Quillio Setup.exe" (the Windows installer wizard) with NSIS. Works on Linux, macOS or Windows.

    python3 installer/build_windows.py --out dist/

Needs: `makensis` (NSIS 3; apt install nsis / brew install makensis), rsvg-convert (icon), pip (to fetch pip's wheel).
The installer downloads Python and the packages on the Windows PC while it installs (internet needed once).
"""
import argparse
import html
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent


def make_ico(png_dir: Path, out: Path) -> None:
    """An .ico made of PNG images (Windows Vista and newer read these)."""
    sizes = [16, 32, 48, 64, 128, 256]
    images = [(s, (png_dir / f"{s}.png").read_bytes()) for s in sizes]
    header = b"\x00\x00\x01\x00" + len(images).to_bytes(2, "little")
    offset = 6 + 16 * len(images)
    entries, blobs = b"", b""
    for size, data in images:
        dim = 0 if size >= 256 else size
        entries += bytes([dim, dim, 0, 0]) + (1).to_bytes(2, "little") + (32).to_bytes(2, "little")
        entries += len(data).to_bytes(4, "little") + offset.to_bytes(4, "little")
        blobs += data
        offset += len(data)
    out.write_bytes(header + entries + blobs)


def render_icon(work: Path) -> Path:
    mascot = (SRC / "academic_hub/static/mascot.svg").read_text()
    inner = re.sub(r"</svg>\s*$", "", re.sub(r"^<svg[^>]*>", "", mascot.strip()))
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="1024" height="1024">
  <rect x="40" y="40" width="944" height="944" rx="210" fill="#DDF264"/>
  <rect x="40" y="40" width="944" height="944" rx="210" fill="none" stroke="#171715" stroke-width="16"/>
  <g transform="translate(130 150) scale(2.9)">{inner}</g></svg>"""
    (work / "icon.svg").write_text(svg)
    pngs = work / "png"
    pngs.mkdir()
    for size in (16, 32, 48, 64, 128, 256):
        subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size), str(work / "icon.svg"), "-o", str(pngs / f"{size}.png")], check=True)
    ico = work / "academic_hub.ico"
    make_ico(pngs, ico)
    return ico


def license_text(out: Path) -> None:
    """The license screen shows plain text; derive it from the same HTML the Mac installer shows."""
    page = (HERE / "resources" / "license.html").read_text(encoding="utf-8")
    body = re.sub(r"(?is)<style.*?</style>|<head.*?</head>", "", page)
    body = re.sub(r"(?i)</h1>|</h2>|</p>|</div>", "\n\n", body)
    body = re.sub(r"(?i)<br\s*/?>", "\n", body)
    text = html.unescape(re.sub(r"<[^>]+>", "", body))
    text = "\n".join(line.strip() for line in text.splitlines())
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    out.write_text(text.replace("\n", "\r\n") + "\r\n", encoding="utf-8-sig")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(SRC / "dist"))
    args = ap.parse_args()
    if not shutil.which("makensis"):
        sys.exit("makensis not found (install NSIS: apt install nsis, or brew install makensis)")
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="ah-win-"))
    try:
        ico = render_icon(work)
        license_text(work / "license.txt")
        subprocess.run([sys.executable, "-m", "pip", "download", "--quiet", "--no-deps", "--only-binary=:all:", "-d", str(work / "pip"), "pip"], check=True)
        pip_wheel = next((work / "pip").glob("pip-*.whl"))
        exe = out_dir / "Quillio Setup.exe"
        subprocess.run([
            "makensis", "-V2",
            f"-DOUTFILE={exe}", f"-DICON={ico}", f"-DLICENSE={work / 'license.txt'}",
            f"-DSRC={SRC}", f"-DWIN={HERE / 'windows'}", f"-DPIPWHEEL={pip_wheel}",
            str(HERE / "windows" / "installer.nsi"),
        ], check=True)
        print(f"Built {exe} ({exe.stat().st_size / 1e6:.1f} MB)")
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
