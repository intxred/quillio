"""Grade 5 starter question bank: 8 subjects x 10 questions.

Each exam draws 10 questions spread evenly over the subjects (set in the dashboard),
preferring the questions a learner has seen least, so retries rotate through the bank.
Edit, add or remove anything from the dashboard.
"""

from __future__ import annotations

import json
import sqlite3
import time

SUBJECTS = [
    ("Mathematics", "➗"),
    ("Science", "🔬"),
    ("English", "📖"),
    ("Filipino", "🇵🇭"),
    ("Araling Panlipunan", "🗺️"),
    ("MAPEH", "🎨"),
    ("Computer Studies", "💻"),
    ("General Knowledge", "🌏"),
]

# (question, [choices], correct_index, explanation)
BANK: dict[str, list[tuple[str, list[str], int, str]]] = {
    "Mathematics": [
        ("What is 3/4 + 1/8?", ["4/12", "7/8", "5/8", "1"], 1,
         "Change 3/4 to eighths: 3/4 = 6/8. Then 6/8 + 1/8 = 7/8."),
        ("What is the greatest common factor (GCF) of 18 and 24?", ["3", "9", "6", "12"], 2,
         "Factors of 18: 1, 2, 3, 6, 9, 18. Factors of 24: 1, 2, 3, 4, 6, 8, 12, 24. The biggest shared factor is 6."),
        ("What is the least common multiple (LCM) of 4 and 6?", ["10", "12", "18", "24"], 1,
         "Multiples of 4: 4, 8, 12... Multiples of 6: 6, 12... The first shared multiple is 12."),
        ("What is 0.6 × 0.5?", ["0.03", "3.0", "0.3", "1.1"], 2,
         "6 × 5 = 30. There are two decimal places in total, so the answer is 0.30 = 0.3."),
        ("A rectangle is 12 cm long and 7 cm wide. What is its area?", ["38 sq cm", "84 sq cm", "19 sq cm", "96 sq cm"], 1,
         "Area = length × width = 12 × 7 = 84 square centimeters."),
        ("What is 25% of 80?", ["15", "25", "20", "40"], 2,
         "25% is one fourth. 80 ÷ 4 = 20."),
        ("Which of these numbers is a prime number?", ["21", "27", "33", "29"], 3,
         "29 can only be divided evenly by 1 and itself. 21 = 3 × 7, 27 = 3 × 9 and 33 = 3 × 11."),
        ("What is the volume of a cube with edges 3 cm long?", ["9 cu cm", "27 cu cm", "18 cu cm", "81 cu cm"], 1,
         "Volume = edge × edge × edge = 3 × 3 × 3 = 27 cubic centimeters."),
        ("Round 4,567 to the nearest hundred.", ["4,500", "4,570", "5,000", "4,600"], 3,
         "Look at the tens digit: 6 is 5 or more, so round the hundreds digit up. 4,567 becomes 4,600."),
        ("What is 2/3 of 36?", ["12", "18", "24", "30"], 2,
         "36 ÷ 3 = 12 for one third. Two thirds = 12 × 2 = 24."),
    ],
    "Science": [
        ("Which part of a plant absorbs water and minerals from the soil?", ["Leaves", "Roots", "Flowers", "Stem"], 1,
         "Roots take in water and minerals and also anchor the plant in the ground."),
        ("What process do green plants use to make their own food?", ["Respiration", "Digestion", "Photosynthesis", "Pollination"], 2,
         "In photosynthesis, plants use sunlight, water and carbon dioxide to make sugar and oxygen."),
        ("Which organ pumps blood throughout the body?", ["Lungs", "Brain", "Stomach", "Heart"], 3,
         "The heart is a muscle that pumps blood through the blood vessels."),
        ("What happens to liquid water when it is heated to 100°C at sea level?", ["It freezes", "It boils and becomes water vapor", "It becomes ice", "It disappears completely"], 1,
         "100°C is the boiling point of water. It changes into water vapor, a gas."),
        ("Which planet is closest to the Sun?", ["Venus", "Earth", "Mercury", "Mars"], 2,
         "Mercury is the first planet from the Sun, followed by Venus, Earth and Mars."),
        ("A seesaw is an example of which simple machine?", ["Pulley", "Inclined plane", "Wheel and axle", "Lever"], 3,
         "A seesaw is a bar that rests on and turns around a fixed point, which makes it a lever."),
        ("Sound usually travels fastest through which of these?", ["Air", "Steel", "Water", "A vacuum"], 1,
         "Particles in solids are packed closest together, so sound passes through them fastest. A vacuum carries no sound."),
        ("What is it called when water vapor cools and changes into liquid water?", ["Evaporation", "Melting", "Condensation", "Freezing"], 2,
         "Condensation happens when water vapor loses heat. It forms clouds and the water drops on a cold glass."),
        ("Which body system helps us breathe?", ["Digestive system", "Respiratory system", "Circulatory system", "Nervous system"], 1,
         "The respiratory system, including the nose, trachea and lungs, brings in oxygen and removes carbon dioxide."),
        ("Which type of rock forms when melted rock (magma or lava) cools and hardens?", ["Igneous", "Sedimentary", "Metamorphic", "Fossil"], 0,
         "Igneous rocks come from cooled magma or lava. Granite and basalt are examples."),
    ],
    "English": [
        ("Which sentence has correct subject-verb agreement?",
         ["The children plays outside.", "The children play outside.", "The children is playing outside.", "The children playing outside."], 1,
         "'Children' is plural, so it takes the plural verb 'play'."),
        ("What is the antonym (opposite) of 'ancient'?", ["Old", "Historic", "Huge", "Modern"], 3,
         "'Ancient' means very old, so its opposite is 'modern'."),
        ("Which word is closest in meaning to 'enormous'?", ["Tiny", "Huge", "Quiet", "Quick"], 1,
         "'Enormous' means extremely large, the same as 'huge'."),
        ("Which word is the adjective in this sentence? 'The tall boy kicked the ball.'", ["boy", "kicked", "tall", "ball"], 2,
         "An adjective describes a noun. 'Tall' describes the boy."),
        ("What is the past tense of the verb 'swim'?", ["Swimmed", "Swam", "Swum", "Swimming"], 1,
         "'Swim' is an irregular verb. Its simple past form is 'swam'."),
        ("Which punctuation mark completes this sentence? 'Where are you going___'", [".", "!", "?", ","], 2,
         "A question ends with a question mark."),
        ("Which word is the conjunction in this sentence? 'I wanted to play, but it was raining.'", ["wanted", "but", "play", "raining"], 1,
         "A conjunction joins ideas. 'But' joins two contrasting ideas."),
        ("Which of these is a complete sentence?",
         ["Running down the street.", "Because it was late.", "The cat slept on the sofa.", "After the rain stopped."], 2,
         "A complete sentence has a subject (the cat) and a predicate (slept on the sofa) and expresses a full thought."),
        ("What is the plural form of 'child'?", ["Childs", "Children", "Childrens", "Childes"], 1,
         "'Child' has an irregular plural: 'children'."),
        ("The prefix 'un-' in the word 'unhappy' means:", ["again", "before", "not", "too much"], 2,
         "The prefix 'un-' means 'not', so 'unhappy' means 'not happy'."),
    ],
    "Filipino": [
        ("Anong bahagi ng pananalita ang salitang 'maganda' sa pangungusap na 'Maganda ang bulaklak'?",
         ["Pangngalan", "Pandiwa", "Pang-uri", "Pang-abay"], 2,
         "Ang pang-uri ay naglalarawan sa pangngalan. Inilalarawan ng 'maganda' ang bulaklak."),
        ("Alin ang pandiwa sa pangungusap na 'Si Ana ay kumakanta sa entablado'?",
         ["Ana", "entablado", "kumakanta", "sa"], 2,
         "Ang pandiwa ay salitang nagsasaad ng kilos. Ang 'kumakanta' ay kilos."),
        ("Ano ang kasalungat ng salitang 'mataas'?", ["Malapad", "Mababa", "Malayo", "Mabilis"], 1,
         "Ang kasalungat ng 'mataas' ay 'mababa'."),
        ("Alin ang kasingkahulugan ng salitang 'masaya'?", ["Malungkot", "Mahirap", "Maligaya", "Maingay"], 2,
         "Magkapareho ang kahulugan ng 'masaya' at 'maligaya'."),
        ("Alin ang panghalip na panao sa pangungusap na 'Siya ay mabait'?", ["ay", "mabait", "Wala", "Siya"], 3,
         "Ang panghalip na panao ay pumapalit sa ngalan ng tao. Ang 'siya' ay panghalip na panao."),
        ("Ano ang tawag sa mga salitang nag-uugnay ng dalawang salita o parirala, tulad ng 'at', 'o' at 'ngunit'?",
         ["Pang-ukol", "Pangatnig", "Pang-angkop", "Pang-abay"], 1,
         "Ang pangatnig ay nag-uugnay ng mga salita, parirala o sugnay."),
        ("Ano ang kahulugan ng salawikain na 'Ang hindi marunong lumingon sa pinanggalingan ay hindi makararating sa paroroonan'?",
         ["Dapat nating tandaan at pasalamatan ang ating pinagmulan at mga tumulong sa atin",
          "Huwag lumingon kapag naglalakad", "Dapat laging maglakbay nang maaga", "Mahalaga ang mabilis na paglalakad"], 0,
         "Ipinapaalala nito na dapat tayong magpasalamat sa ating pinanggalingan at sa mga tumulong sa atin."),
        ("Ilan ang patinig sa alpabetong Filipino?", ["3", "6", "5", "8"], 2,
         "Limang patinig: a, e, i, o, u."),
        ("Alin sa mga sumusunod ang pangngalang pantangi?", ["lungsod", "bata", "ilog", "Maynila"], 3,
         "Ang pangngalang pantangi ay tiyak na ngalan at nagsisimula sa malaking titik, tulad ng Maynila."),
        ("Anong bantas ang ginagamit sa dulo ng pangungusap na patanong?", ["Tuldok", "Tandang pananong", "Kuwit", "Tandang padamdam"], 1,
         "Ang tandang pananong (?) ay nasa dulo ng pangungusap na nagtatanong."),
    ],
    "Araling Panlipunan": [
        ("Sino ang itinuturing na pambansang bayani ng Pilipinas?", ["Andrés Bonifacio", "José Rizal", "Emilio Aguinaldo", "Apolinario Mabini"], 1,
         "Si Dr. José Rizal ang kinikilalang pambansang bayani ng Pilipinas."),
        ("Anong taon idineklara ang kalayaan ng Pilipinas sa Kawit, Cavite?", ["1521", "1892", "1898", "1946"], 2,
         "Noong Hunyo 12, 1898, idineklara ni Emilio Aguinaldo ang kalayaan sa Kawit, Cavite."),
        ("Sino ang nanguna sa ekspedisyong Espanyol na nakarating sa Pilipinas noong 1521?",
         ["Miguel López de Legazpi", "Ferdinand Magellan", "Christopher Columbus", "Lapu-Lapu"], 1,
         "Si Ferdinand Magellan ang namuno sa ekspedisyon at dumating sa Pilipinas noong 1521."),
        ("Sino ang pinuno ng Mactan na tumalo sa pwersa ni Magellan noong 1521?", ["Humabon", "Sulayman", "Lapu-Lapu", "Dagohoy"], 2,
         "Si Lapu-Lapu ang pinuno ng Mactan na lumaban at tumalo kay Magellan."),
        ("Ano ang pinakamalaking pulo sa Pilipinas?", ["Mindanao", "Cebu", "Palawan", "Luzon"], 3,
         "Ang Luzon ang pinakamalaki at pinakamataong pulo ng bansa."),
        ("Anong samahang rebolusyonaryo ang itinatag ni Andrés Bonifacio noong 1892?", ["La Liga Filipina", "Katipunan", "Propaganda Movement", "Kataastaasang Sanggunian"], 1,
         "Itinatag ni Bonifacio ang Katipunan noong Hulyo 7, 1892 upang makamit ang kalayaan."),
        ("Ano ang tatlong pangunahing pangkat ng pulo sa Pilipinas?", ["Luzon, Visayas, Mindanao", "Luzon, Palawan, Cebu", "Visayas, Sulu, Batanes", "Mindanao, Mindoro, Samar"], 0,
         "Nahahati ang bansa sa Luzon, Visayas at Mindanao."),
        ("Ano ang tawag sa pamayanan ng mga sinaunang Pilipino bago dumating ang mga Espanyol, na pinamumunuan ng isang datu?", ["Kabisera", "Barangay", "Lalawigan", "Sultanato"], 1,
         "Ang barangay ang pangunahing yunit ng pamayanan at ang datu ang pinuno nito."),
        ("Ano ang kabisera ng Pilipinas?", ["Quezon City", "Cebu", "Davao", "Maynila"], 3,
         "Ang Maynila ang kabisera ng Pilipinas."),
        ("Sino ang kilala bilang 'Ina ng Katipunan' o 'Tandang Sora'?", ["Gabriela Silang", "Melchora Aquino", "Teresa Magbanua", "Josefa Llanes Escoda"], 1,
         "Si Melchora Aquino ay tumulong sa mga Katipunero at kilala bilang Tandang Sora."),
    ],
    "MAPEH": [
        ("In 4/4 time, how many beats does a quarter note get?", ["1", "2", "3", "4"], 0,
         "A quarter note gets one beat. A half note gets two and a whole note gets four."),
        ("What is the title of the Philippine national anthem?", ["Bayan Ko", "Lupang Hinirang", "Pilipinas Kong Mahal", "Magandang Pilipinas"], 1,
         "'Lupang Hinirang' is the national anthem of the Philippines."),
        ("Which are the three primary colors?", ["Red, yellow, blue", "Red, green, orange", "Blue, green, purple", "Yellow, orange, pink"], 0,
         "Red, yellow and blue cannot be made by mixing other colors."),
        ("What color do you get when you mix blue and yellow?", ["Orange", "Purple", "Green", "Brown"], 2,
         "Blue and yellow make green."),
        ("Which of these is a health-related component of physical fitness?", ["Eye color", "Height", "Shoe size", "Cardiovascular endurance"], 3,
         "Cardiovascular endurance is how well the heart and lungs work during exercise."),
        ("Why should we warm up before exercising?", ["To make us tired", "To prepare the muscles and help prevent injury", "To use up all our energy", "To skip the real exercise"], 1,
         "Warming up raises body temperature and loosens the muscles, which lowers the risk of injury."),
        ("Which food is a 'Grow' food that helps build strong muscles and bones?", ["Fish", "Candy", "Soda", "Potato chips"], 0,
         "Protein-rich foods such as fish, eggs and beans help the body grow and repair itself."),
        ("About how many hours of sleep does a 10 to 11 year old need each night?", ["4 to 5 hours", "6 to 7 hours", "9 to 12 hours", "14 to 16 hours"], 2,
         "Children aged 6 to 12 are advised to sleep about 9 to 12 hours each night."),
        ("In music, what does 'tempo' mean?", ["How loud the music is", "How fast or slow the music is", "How high or low a sound is", "The words of a song"], 1,
         "Tempo is the speed of the beat. Dynamics is how loud or soft the music is."),
        ("Which element of art refers to how light or dark a color is?", ["Line", "Shape", "Texture", "Value"], 3,
         "Value is the lightness or darkness of a color."),
    ],
    "Computer Studies": [
        ("What does CPU stand for?", ["Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Control Power Unit"], 0,
         "The CPU, or Central Processing Unit, is the 'brain' that carries out the computer's instructions."),
        ("Which of these is an input device?", ["Monitor", "Printer", "Keyboard", "Speaker"], 2,
         "An input device sends data to the computer. A keyboard does that; the others give output."),
        ("Which of these is a web browser?", ["Printer", "Safari", "Keyboard", "Mouse"], 1,
         "Safari is a web browser used to visit websites."),
        ("Which keyboard shortcut copies selected text on a Mac?", ["Command + V", "Command + X", "Command + C", "Command + Z"], 2,
         "Command + C copies. Command + V pastes, Command + X cuts and Command + Z undoes."),
        ("Which is the safest password?", ["password123", "Your birthday", "Your name", "A long mix of letters, numbers and symbols that only you know"], 3,
         "Long, unpredictable passwords are hard to guess. Never share them with friends."),
        ("Which two digits does a computer use in binary code?", ["1 and 2", "0 and 1", "0 and 9", "A and B"], 1,
         "Computers store information as binary digits (bits): 0 and 1."),
        ("A stranger online asks for your home address. What should you do?", ["Give it so you can be friends", "Do not share it and tell a trusted adult", "Share only your street", "Ask them to share theirs first"], 1,
         "Never share personal information with strangers online. Tell a parent, teacher or other trusted adult."),
        ("Which kind of software organizes data in rows and columns and can calculate with formulas?", ["Word processor", "Web browser", "Presentation software", "Spreadsheet"], 3,
         "Spreadsheet programs such as Excel or Numbers use rows, columns and formulas."),
        ("A file named 'picnic.jpg' is most likely what kind of file?", ["A song", "A picture", "A video", "A text document"], 1,
         "The .jpg extension means a JPEG image."),
        ("Which of these is software and not hardware?", ["Mouse", "Monitor", "Keyboard", "Operating system"], 3,
         "Software is a set of instructions you cannot touch. macOS and Windows are operating systems."),
    ],
    "General Knowledge": [
        ("How many days are there in a leap year?", ["365", "364", "366", "367"], 2,
         "A leap year has 366 days because February has 29 days."),
        ("Which is the largest ocean on Earth?", ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"], 3,
         "The Pacific Ocean is the largest and deepest ocean."),
        ("What is the national flower of the Philippines?", ["Rose", "Sampaguita", "Gumamela", "Ilang-ilang"], 1,
         "The sampaguita was declared the national flower in 1934."),
        ("What is the capital city of Japan?", ["Kyoto", "Osaka", "Tokyo", "Seoul"], 2,
         "Tokyo is the capital of Japan."),
        ("How many continents are there on Earth?", ["5", "6", "8", "7"], 3,
         "The seven continents are Asia, Africa, North America, South America, Antarctica, Europe and Australia/Oceania."),
        ("What is the national bird of the Philippines?", ["Maya", "Philippine eagle", "Hornbill", "Parrot"], 1,
         "In 1995 the Philippine eagle replaced the maya as the national bird."),
        ("Which planet is known as the 'Red Planet'?", ["Mars", "Jupiter", "Venus", "Saturn"], 0,
         "Iron oxide (rust) on its surface gives Mars its reddish color."),
        ("Which is the longest river in the Philippines?", ["Pasig River", "Agusan River", "Cagayan River", "Pampanga River"], 2,
         "The Cagayan River in northern Luzon is the longest river in the country."),
        ("Who painted the Mona Lisa?", ["Vincent van Gogh", "Pablo Picasso", "Michelangelo", "Leonardo da Vinci"], 3,
         "Leonardo da Vinci painted the Mona Lisa in the early 1500s."),
        ("What is the highest mountain in the world above sea level?", ["Mount Everest", "Mount Apo", "Mount Fuji", "Mount Kilimanjaro"], 0,
         "Mount Everest in the Himalayas is about 8,849 meters high. Mount Apo is the highest peak in the Philippines."),
    ],
}


def seed_defaults(conn: sqlite3.Connection) -> int:
    """Insert the starter subjects and questions. Returns the number of questions added."""
    now = int(time.time())
    added = 0
    for position, (name, icon) in enumerate(SUBJECTS):
        conn.execute(
            "INSERT OR IGNORE INTO subjects(name, icon, position) VALUES (?, ?, ?)",
            (name, icon, position),
        )
        subject_id = conn.execute("SELECT id FROM subjects WHERE name = ?", (name,)).fetchone()["id"]
        for text, choices, correct, explanation in BANK[name]:
            exists = conn.execute(
                "SELECT 1 FROM questions WHERE subject_id = ? AND text = ?", (subject_id, text)
            ).fetchone()
            if exists:
                continue
            conn.execute(
                "INSERT INTO questions(subject_id, text, choices, correct_index, explanation, "
                "created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (subject_id, text, json.dumps(choices, ensure_ascii=False), correct, explanation, now, now),
            )
            added += 1
    return added
