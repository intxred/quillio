"""Read-only statistics for the dashboard: overview, learning progress, history."""

from __future__ import annotations

import sqlite3
import time

from . import db, quiz_engine


def _attempt_row(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "kind": row["kind"],
        "target_name": row["target_name"],
        "started_at": row["started_at"],
        "finished_at": row["finished_at"],
        "duration_seconds": (row["finished_at"] - row["started_at"]) if row["finished_at"] else None,
        "total": row["total"],
        "correct": row["correct"],
        "score": row["score"],
        "passing_score": row["passing_score"],
        "passed": bool(row["passed"]),
    }


def session_size(conn: sqlite3.Connection) -> int:
    return quiz_engine.session_size(conn)


def overview(conn: sqlite3.Connection) -> dict:
    counts = conn.execute(
        "SELECT (SELECT COUNT(*) FROM subjects) AS subjects, "
        "(SELECT COUNT(*) FROM subjects WHERE enabled = 1) AS subjects_enabled, "
        "(SELECT COUNT(*) FROM questions) AS questions, "
        "(SELECT COUNT(*) FROM questions WHERE active = 1) AS questions_active"
    ).fetchone()
    quiz = conn.execute(
        "SELECT COUNT(*) AS attempts, COALESCE(SUM(passed), 0) AS passed, "
        "COALESCE(ROUND(AVG(score)), 0) AS avg_score, COALESCE(MAX(score), 0) AS best_score "
        "FROM attempts WHERE kind = 'quiz' AND finished_at IS NOT NULL"
    ).fetchone()
    overrides = conn.execute("SELECT COUNT(*) AS n FROM attempts WHERE kind = 'admin_override'").fetchone()["n"]
    added_30d = conn.execute(
        "SELECT COUNT(*) AS n FROM questions WHERE created_at >= ?", (db.now() - 30 * 86400,)
    ).fetchone()["n"]
    protected = conn.execute("SELECT COUNT(*) AS n FROM restricted_apps WHERE enabled = 1").fetchone()["n"]
    recent = [
        _attempt_row(r) for r in conn.execute("SELECT * FROM attempts ORDER BY id DESC LIMIT 8")
    ]
    unlocked = [
        {"bundle_id": r["bundle_id"], "app_name": r["app_name"], "granted_at": r["granted_at"],
         "expires_at": r["expires_at"], "reason": r["reason"]}
        for r in conn.execute(
            "SELECT * FROM unlocks WHERE active = 1 AND (expires_at IS NULL OR expires_at > ?) ORDER BY id DESC",
            (db.now(),),
        )
    ]
    return {
        "subjects": counts["subjects"],
        "subjects_enabled": counts["subjects_enabled"],
        "questions": counts["questions"],
        "questions_active": counts["questions_active"],
        "attempts": quiz["attempts"],
        "passed": quiz["passed"],
        "avg_score": int(quiz["avg_score"]),
        "best_score": quiz["best_score"],
        "admin_overrides": overrides,
        "questions_added_30d": added_30d,
        "pass_rate": round(100 * quiz["passed"] / quiz["attempts"]) if quiz["attempts"] else 0,
        "protected_apps": protected,
        "guard_enabled": db.get_int(conn, "guard_enabled", 1) == 1,
        "passing_score": db.get_int(conn, "passing_score", 70),
        "session_size": session_size(conn),
        "recent": recent,
        "unlocked": unlocked,
    }


def learning_progress(conn: sqlite3.Connection) -> dict:
    by_subject = [
        {
            "subject": r["subject_name"],
            "answered": r["answered"],
            "correct": r["correct"],
            "accuracy": round(100 * r["correct"] / r["answered"]) if r["answered"] else 0,
        }
        for r in conn.execute(
            "SELECT subject_name, COUNT(*) AS answered, SUM(is_correct) AS correct "
            "FROM attempt_answers GROUP BY subject_name ORDER BY subject_name"
        )
    ]
    trend = [
        {"id": r["id"], "started_at": r["started_at"], "score": r["score"], "passed": bool(r["passed"])}
        for r in conn.execute(
            "SELECT * FROM (SELECT * FROM attempts WHERE kind = 'quiz' AND finished_at IS NOT NULL "
            "ORDER BY id DESC LIMIT 30) ORDER BY id"
        )
    ]
    weakest = [
        {
            "subject": r["subject_name"],
            "question": r["question_text"],
            "asked": r["asked"],
            "missed": r["missed"],
            "miss_rate": round(100 * r["missed"] / r["asked"]),
        }
        for r in conn.execute(
            "SELECT subject_name, question_text, COUNT(*) AS asked, COUNT(*) - SUM(is_correct) AS missed "
            "FROM attempt_answers GROUP BY question_text, subject_name "
            "HAVING missed > 0 ORDER BY (1.0 * missed / asked) DESC, missed DESC LIMIT 10"
        )
    ]
    first_pass = conn.execute(
        "SELECT id, started_at FROM attempts WHERE kind = 'quiz' AND passed = 1 ORDER BY id LIMIT 1"
    ).fetchone()
    failed_before_pass = None
    if first_pass:
        failed_before_pass = conn.execute(
            "SELECT COUNT(*) AS n FROM attempts WHERE kind = 'quiz' AND passed = 0 "
            "AND finished_at IS NOT NULL AND id < ?",
            (first_pass["id"],),
        ).fetchone()["n"]
    day = 86400
    since = db.now() - 13 * day
    per_day: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT started_at, score, passed FROM attempts WHERE kind = 'quiz' AND finished_at IS NOT NULL "
        "AND started_at >= ? ORDER BY id",
        (since,),
    ):
        key = time.strftime("%Y-%m-%d", time.localtime(r["started_at"]))
        entry = per_day.setdefault(key, {"date": key, "attempts": 0, "passed": 0, "score_sum": 0})
        entry["attempts"] += 1
        entry["passed"] += r["passed"]
        entry["score_sum"] += r["score"]
    daily = [
        {"date": e["date"], "attempts": e["attempts"], "passed": e["passed"],
         "avg_score": round(e["score_sum"] / e["attempts"])}
        for e in per_day.values()
    ]
    return {
        "by_subject": by_subject,
        "trend": trend,
        "weakest": weakest,
        "failed_before_first_pass": failed_before_pass,
        "daily": daily,
    }


def list_attempts(conn: sqlite3.Connection, limit: int = 50, offset: int = 0) -> dict:
    total = conn.execute("SELECT COUNT(*) AS n FROM attempts").fetchone()["n"]
    rows = conn.execute(
        "SELECT * FROM attempts ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)
    ).fetchall()
    return {"total": total, "items": [_attempt_row(r) for r in rows]}


def attempt_detail(conn: sqlite3.Connection, attempt_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM attempts WHERE id = ?", (attempt_id,)).fetchone()
    if row is None:
        return None
    answers = [
        {
            "subject": a["subject_name"],
            "question": a["question_text"],
            "chosen": a["chosen_text"],
            "correct_answer": a["correct_text"],
            "is_correct": bool(a["is_correct"]),
        }
        for a in conn.execute("SELECT * FROM attempt_answers WHERE attempt_id = ? ORDER BY id", (attempt_id,))
    ]
    data = _attempt_row(row)
    data["answers"] = answers
    return data
