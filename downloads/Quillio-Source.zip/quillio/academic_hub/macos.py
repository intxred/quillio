"""Operating-system helpers for app monitoring and the exam window.

macOS uses AppKit (this file); Windows uses winos.py. Every function degrades to a harmless
no-op elsewhere, so the rest of the code (and the unit tests) run on any platform.
"""

from __future__ import annotations

import plistlib
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

IS_MAC = sys.platform == "darwin"
IS_WIN = sys.platform == "win32"

if IS_MAC:
    import AppKit  # type: ignore  # pyobjc-framework-Cocoa
    import Foundation  # type: ignore
    import objc  # type: ignore

# Kiosk behaviour while the quiz is on screen. DisableSessionTermination is left
# out on purpose: it would hide Log Out / Restart / Shut Down, and keeping those
# available means a hung quiz can never trap the Mac.
_KIOSK_OPTION_NAMES = (
    "NSApplicationPresentationHideDock",
    "NSApplicationPresentationHideMenuBar",
    "NSApplicationPresentationDisableAppleMenu",
    "NSApplicationPresentationDisableProcessSwitching",   # no Cmd+Tab / Cmd+Shift+Tab
    "NSApplicationPresentationDisableForceQuit",          # no Cmd+Opt+Esc
    "NSApplicationPresentationDisableHideApplication",    # no Cmd+H
)

_SCREEN_SAVER_LEVEL = 1000  # above the menu bar, Dock and other app windows


@dataclass
class RunningApp:
    pid: int
    name: str
    bundle_id: str
    _ref: Any = field(default=None, repr=False)

    def terminate(self) -> None:
        """Quit the app immediately (no 'save changes?' prompt can stall it)."""
        if self._ref is None:
            return
        if IS_WIN:
            from . import winos

            winos.terminate(self._ref)
        else:
            self._ref.forceTerminate()


def pump(seconds: float) -> None:
    """Sleep while letting Cocoa deliver workspace updates.

    NSWorkspace.runningApplications() goes stale in a process that never spins
    its run loop, so the monitor waits with the run loop instead of time.sleep().
    """
    if IS_MAC:
        Foundation.NSRunLoop.currentRunLoop().runUntilDate_(
            Foundation.NSDate.dateWithTimeIntervalSinceNow_(seconds)
        )
    else:
        time.sleep(seconds)


def running_apps() -> list[RunningApp]:
    """Regular (Dock-visible) applications that are currently running."""
    if IS_WIN:
        from . import winos

        return winos.running_apps(RunningApp)
    if not IS_MAC:
        return []
    apps: list[RunningApp] = []
    for app in AppKit.NSWorkspace.sharedWorkspace().runningApplications():
        if app.activationPolicy() != AppKit.NSApplicationActivationPolicyRegular:
            continue
        if app.isTerminated():
            continue
        apps.append(
            RunningApp(
                pid=int(app.processIdentifier()),
                name=str(app.localizedName() or ""),
                bundle_id=str(app.bundleIdentifier() or ""),
                _ref=app,
            )
        )
    return apps


def launch_app(name: str, bundle_id: str = "") -> None:
    if IS_WIN:
        return  # Roblox starts from its website; the exam tells the person to press Play there
    cmd = ["open", "-b", bundle_id] if bundle_id else ["open", "-a", name]
    if IS_MAC:
        subprocess.run(cmd, check=False)
    else:
        print("[dry-run] would run:", " ".join(cmd))


# ------------------------------------------------------------------ kiosk

def enter_kiosk_mode() -> bool:
    """Hide the Dock/menu bar and disable app switching and force quit."""
    if not IS_MAC:
        return False
    try:
        options = 0
        for option in _KIOSK_OPTION_NAMES:
            options |= getattr(AppKit, option)
        AppKit.NSApplication.sharedApplication().setPresentationOptions_(options)
        return True
    except Exception as exc:  # invalid combination or API change: keep going
        print("kiosk presentation options failed:", exc, file=sys.stderr)
        return False


_elevate_error_shown = False


def elevate_all_windows() -> bool:
    """Put every window of this process above everything, on every Space, including full-screen apps.

    The quiz process is started in the background by the monitor, and recent macOS versions refuse
    to let such an app take focus from the browser. A window can still be ordered to the front
    "regardless" of which app is active, so that is what this does (and it is repeated every second
    while the quiz is up). It goes through NSApplication.windows() so it does not depend on Qt's
    window ids.
    """
    global _elevate_error_shown
    if IS_WIN:
        from . import winos

        return winos.elevate_all_windows()
    if not IS_MAC:
        return False
    try:
        behavior = (
            AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces
            | AppKit.NSWindowCollectionBehaviorFullScreenAuxiliary
            | AppKit.NSWindowCollectionBehaviorIgnoresCycle
        )
        for window in AppKit.NSApplication.sharedApplication().windows():
            window.setLevel_(_SCREEN_SAVER_LEVEL)
            window.setCollectionBehavior_(behavior)
            window.setHidesOnDeactivate_(False)
            window.orderFrontRegardless()
        return True
    except Exception as exc:
        if not _elevate_error_shown:  # log once, not every second
            _elevate_error_shown = True
            print("could not elevate windows:", exc, file=sys.stderr)
        return False


def use_overlay_policy() -> bool:
    """Run the quiz process as an overlay ("accessory") app.

    macOS only lets a window cover another app's full-screen Space (a full-screen browser) when its
    app is not a regular Dock app. As an accessory app the exam also gets no Dock icon or menu bar.
    """
    if not IS_MAC:
        return False
    try:
        return bool(
            AppKit.NSApplication.sharedApplication().setActivationPolicy_(
                AppKit.NSApplicationActivationPolicyAccessory
            )
        )
    except Exception as exc:
        print("could not switch to overlay mode:", exc, file=sys.stderr)
        return False


def describe_windows() -> str:
    """One line per window (level, visibility, Space, position) for the quiz log, to diagnose focus issues."""
    if IS_WIN:
        from . import winos

        return winos.describe_windows()
    if not IS_MAC:
        return "not macOS"
    try:
        ns_app = AppKit.NSApplication.sharedApplication()
        lines = [f"policy={ns_app.activationPolicy()} active={bool(ns_app.isActive())}"]
        for window in ns_app.windows():
            frame = window.frame()
            lines.append(
                "window level=%s visible=%s onActiveSpace=%s frame=(%d,%d %dx%d)"
                % (window.level(), bool(window.isVisible()), bool(window.isOnActiveSpace()),
                   frame.origin.x, frame.origin.y, frame.size.width, frame.size.height)
            )
        return "; ".join(lines)
    except Exception as exc:
        return f"describe failed: {exc}"


def elevate_window(widget=None) -> bool:  # kept for callers that pass a Qt widget
    return elevate_all_windows()


def activate_app() -> None:
    """Ask macOS to make this app the active one. Newer macOS may ignore this for a background
    app, which is why the windows are also ordered to the front directly (elevate_all_windows)."""
    if IS_WIN:
        from . import winos

        winos.activate_app()
        return
    if not IS_MAC:
        return
    try:
        ns_app = AppKit.NSApplication.sharedApplication()
        ns_app.activateIgnoringOtherApps_(True)
        AppKit.NSRunningApplication.currentApplication().activateWithOptions_(
            AppKit.NSApplicationActivateIgnoringOtherApps | AppKit.NSApplicationActivateAllWindows
        )
    except Exception as exc:
        print("could not activate app:", exc, file=sys.stderr)


# ------------------------------------------------------------------ discovery

def installed_apps() -> list[dict]:
    """Applications found in the standard folders, for the dashboard's picker."""
    if IS_WIN:
        from . import winos

        return winos.installed_apps()
    roots = [
        Path("/Applications"),
        Path("/Applications/Utilities"),
        Path("/System/Applications"),
        Path("/System/Applications/Utilities"),
        Path.home() / "Applications",
    ]
    found: dict[str, dict] = {}
    for root in roots:
        if not root.is_dir():
            continue
        for app in sorted(root.glob("*.app")):
            try:
                with open(app / "Contents" / "Info.plist", "rb") as fh:
                    info = plistlib.load(fh)
            except (OSError, plistlib.InvalidFileException, ValueError):
                continue
            bundle = info.get("CFBundleIdentifier", "")
            name = info.get("CFBundleDisplayName") or info.get("CFBundleName") or app.stem
            if bundle and bundle not in found:
                found[bundle] = {"name": str(name), "bundle_id": str(bundle)}
    return sorted(found.values(), key=lambda a: a["name"].casefold())
