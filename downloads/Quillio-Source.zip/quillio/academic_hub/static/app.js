/* Quillio dashboard. Plain JavaScript, no external libraries or network calls.
   All user-supplied text is inserted with textContent, never innerHTML. */
(function () {
  'use strict';

  var state = { csrf: null, view: 'overview', subjectFilter: '', search: '' };
  var root = document.getElementById('app');

  // ---------------------------------------------------------------- helpers
  function h(tag, attrs) {
    var node = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      var value = attrs[key];
      if (value === null || value === undefined || value === false) return;
      if (key.indexOf('on') === 0 && typeof value === 'function') node.addEventListener(key.slice(2), value);
      else if (key === 'class') node.className = value;
      else if (key === 'value' || key === 'checked' || key === 'disabled' || key === 'selected') node[key] = value;
      else node.setAttribute(key, value === true ? '' : value);
    });
    for (var i = 2; i < arguments.length; i++) append(node, arguments[i]);
    return node;
  }
  function append(node, child) {
    if (child === null || child === undefined || child === false) return;
    if (Array.isArray(child)) child.forEach(function (c) { append(node, c); });
    else node.appendChild(typeof child === 'object' ? child : document.createTextNode(String(child)));
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  var NS = 'http://www.w3.org/2000/svg';
  function svgEl(name, attrs) {
    var n = document.createElementNS(NS, name);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    for (var i = 2; i < arguments.length; i++) if (arguments[i]) n.appendChild(arguments[i]);
    return n;
  }
  var ICONS = {
    dashboard: { d: ['M3 3h7v7H3z', 'M14 3h7v7h-7z', 'M14 14h7v7h-7z', 'M3 14h7v7H3z'] },
    library: { d: ['M4 19.5A2.5 2.5 0 0 1 6.5 17H20', 'M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z'] },
    progress: { d: ['M12 20V10', 'M18 20V4', 'M6 20v-4'] },
    lock: { d: ['M5 11h14v10H5z', 'M8 11V7a4 4 0 0 1 8 0v4'] },
    settings: { d: ['M4 6h9', 'M17 6h3', 'M4 12h3', 'M11 12h9', 'M4 18h11', 'M19 18h1'], c: [[15, 6, 2], [9, 12, 2], [17, 18, 2]] },
    transfer: { d: ['M12 3v12', 'M8 11l4 4 4-4', 'M4 21h16'] },
    search: { d: ['M21 21l-4.3-4.3'], c: [[11, 11, 7]] },
    bell: { d: ['M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9', 'M10.3 21a1.9 1.9 0 0 0 3.4 0'] },
    calendar: { d: ['M3 5h18v16H3z', 'M3 10h18', 'M8 3v4', 'M16 3v4'] },
    play: { d: ['M7 4l13 8-13 8z'] },
    arrow: { d: ['M5 12h14', 'M13 6l6 6-6 6'] },
    check: { d: ['M5 12l5 5L20 7'] },
    spark: { d: ['M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z'] },
    signout: { d: ['M9 21H5V3h4', 'M16 17l5-5-5-5', 'M21 12H9'] }
  };
  function icon(name) {
    var spec = ICONS[name] || { d: [] };
    var svg = svgEl('svg', { viewBox: '0 0 24 24', 'class': 'ico', 'aria-hidden': 'true' });
    spec.d.forEach(function (d) { svg.appendChild(svgEl('path', { d: d })); });
    (spec.c || []).forEach(function (c) { svg.appendChild(svgEl('circle', { cx: c[0], cy: c[1], r: c[2] })); });
    return svg;
  }
  var TINTS = ['#FDE7E1', '#E9E6FB', '#DFF3E3', '#FFF1C4', '#E1ECFB', '#FCE4EF', '#E2F4F1', '#F1ECDD'];
  function tint(i) { return TINTS[i % TINTS.length]; }

  function fmtDate(sec) {
    if (!sec) return '—';
    var d = new Date(sec * 1000);
    try { return d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); }
    catch (e) { return d.toLocaleString(); }
  }
  function fmtDuration(sec) {
    if (sec === null || sec === undefined) return '—';
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + 'm ' + (s < 10 ? '0' : '') + s + 's';
  }

  function toast(message, kind) {
    var box = document.getElementById('toasts');
    if (!box) { box = h('div', { id: 'toasts' }); document.body.appendChild(box); }
    var t = h('div', { class: 'toast' + (kind === 'error' ? ' error' : '') }, message);
    box.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, kind === 'error' ? 6000 : 3000);
  }

  function api(method, path, body) {
    var headers = {};
    var options = { method: method, headers: headers, credentials: 'same-origin' };
    if (body !== undefined) { headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(body); }
    if (method !== 'GET' && state.csrf) headers['X-CSRF-Token'] = state.csrf;
    return fetch(path, options).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (res.status === 401 && path.indexOf('/api/login') !== 0 && path.indexOf('/api/session') !== 0) {
          showLogin(); throw new Error('Please sign in again.');
        }
        if (!res.ok) throw new Error(data.error || ('Request failed (' + res.status + ')'));
        return data;
      });
    });
  }
  function fail(err) { toast(err.message || String(err), 'error'); }

  function modal(title, body, actions) {
    var overlay = h('div', { class: 'overlay' });
    function close() { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
    var footer = h('div', { class: 'footer' });
    (actions || []).forEach(function (a) {
      footer.appendChild(h('button', { class: 'btn' + (a.kind ? ' ' + a.kind : ''), onclick: function () { a.run(close); } }, a.label));
    });
    overlay.appendChild(h('div', { class: 'modal' }, h('h2', {}, title), body, footer));
    document.body.appendChild(overlay);
    return close;
  }
  function confirmDialog(message, confirmLabel) {
    return new Promise(function (resolve) {
      modal('Please confirm', h('p', {}, message), [
        { label: 'Cancel', run: function (close) { close(); resolve(false); } },
        { label: confirmLabel || 'Yes, continue', kind: 'danger', run: function (close) { close(); resolve(true); } }
      ]);
    });
  }

  // ---------------------------------------------------------------- login
  function showLogin() {
    state.csrf = null;
    api('GET', '/api/session').then(function (s) {
      var settingUp = !s.pin_set;
      var pin = h('input', { type: 'password', placeholder: settingUp ? 'Choose an admin PIN (4+ characters)' : 'Admin PIN', autocomplete: 'current-password' });
      var error = h('p', { class: 'small', style: 'color:#D64545;min-height:20px' });
      function submit() {
        api('POST', settingUp ? '/api/setup' : '/api/login', { pin: pin.value }).then(function (r) {
          state.csrf = r.csrf; start();
        }).catch(function (e) { error.textContent = e.message; pin.value = ''; });
      }
      pin.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
      clear(root);
      root.appendChild(h('div', { class: 'login' },
        h('img', { src: '/mascot.svg', alt: '' }),
        h('h1', { style: 'margin:6px 0 16px' }, 'Quillio'),
        h('div', { class: 'card' },
          h('h2', {}, settingUp ? 'Create your admin PIN' : 'Sign in'),
          h('p', { class: 'muted' }, settingUp
            ? 'This PIN protects the dashboard, the Exit button on the exam and the parent unlock.'
            : 'Enter the admin PIN to manage quizzes.'),
          pin, error,
          h('button', { class: 'btn primary', onclick: submit }, settingUp ? 'Save PIN and continue' : 'Sign in'))));
      pin.focus();
    }).catch(fail);
  }

  // ---------------------------------------------------------------- shell
  var NAV = [
    { title: 'Workspace' },
    { key: 'overview', icon: 'dashboard', label: 'Dashboard' },
    { key: 'questions', icon: 'library', label: 'Quiz Library' },
    { key: 'progress', icon: 'progress', label: 'Progress' },
    { key: 'applock', icon: 'lock', label: 'App Lock', count: true },
    { title: 'Manage' },
    { key: 'settings', icon: 'settings', label: 'Settings' },
    { key: 'transfer', icon: 'transfer', label: 'Import / Export' }
  ];
  var VIEW_KEYS = NAV.filter(function (n) { return n.key; }).map(function (n) { return n.key; });

  function goto(view) { state.view = view; location.hash = view; renderShell(); }

  function start() {
    var wanted = (location.hash || '').replace('#', '');
    if (VIEW_KEYS.indexOf(wanted) >= 0) state.view = wanted;
    if (!window.__ahKeys) {
      window.__ahKeys = true;
      document.addEventListener('keydown', function (e) {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
          var box = document.getElementById('global-search');
          if (box) { e.preventDefault(); box.focus(); box.select(); }
        }
      });
    }
    renderShell();
  }

  function openPreview() {
    api('POST', '/api/preview-quiz', {}).then(function (r) {
      toast(r.already_open ? 'The quiz window is already open.' : 'Quiz opened in a window on this Mac. Nothing is locked or unlocked.');
    }).catch(fail);
  }

  function alertsFor(o) {
    var list = [];
    if (!o.guard_enabled) list.push(['Protection is paused', 'Apps are not being closed. Switch protection on in App Lock.']);
    if (o.protected_apps === 0) list.push(['No apps are restricted', 'Add the apps you want to guard under App Lock.']);
    if (o.session_size === 0) list.push(['The quiz cannot start', 'There are no active questions. Add some in the Quiz Library.']);
    else if (o.session_size < o.configured_size) list.push(['Short quiz', 'Only ' + o.session_size + ' active questions are available, so exams have fewer than ' + o.configured_size + ' questions.']);
    return list;
  }

  function renderShell() {
    clear(root);
    var nav = h('div', { class: 'sidebar' },
      h('div', { class: 'brand' }, h('img', { src: '/mascot.svg', alt: '' }),
        h('div', { class: 'name' }, 'Quillio')));
    var countBadge = null;
    NAV.forEach(function (n) {
      if (n.title) { nav.appendChild(h('div', { class: 'nav-title' }, n.title)); return; }
      var badge = n.count ? h('span', { class: 'count', style: 'display:none' }) : null;
      if (badge) countBadge = badge;
      nav.appendChild(h('button', { class: 'nav' + (state.view === n.key ? ' active' : ''), onclick: function () { goto(n.key); } },
        icon(n.icon), n.label, badge));
    });
    nav.appendChild(h('div', { class: 'spacer' }));
    nav.appendChild(h('button', { class: 'nav', onclick: function () {
      api('POST', '/api/logout', {}).then(showLogin).catch(fail);
    } }, icon('signout'), 'Sign out'));

    var search = h('input', { type: 'text', id: 'global-search', placeholder: 'Search subjects, quizzes, questions…', value: state.search });
    search.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { state.search = search.value; state.subjectFilter = ''; goto('questions'); }
    });
    var bell = h('button', { class: 'icon-btn', title: 'Notifications', 'aria-label': 'Notifications' }, icon('bell'));
    var bellDot = h('span', { class: 'dot', style: 'display:none' });
    bell.appendChild(bellDot);
    var alerts = [];
    bell.addEventListener('click', function () {
      var body = alerts.length
        ? h('div', {}, alerts.map(function (a) { return h('div', { class: 'alert-row' }, h('span', { class: 'badge warn' }, '!'), h('div', {}, h('strong', {}, a[0]), h('div', { class: 'muted small' }, a[1]))); }))
        : h('p', { class: 'muted' }, 'Everything looks good. Nothing needs your attention.');
      modal('Notifications', body, [{ label: 'Close', run: function (c) { c(); } }]);
    });
    var topbar = h('div', { class: 'topbar' },
      h('div', { class: 'search' }, icon('search'), search, h('kbd', {}, '⌘ K')),
      h('div', { class: 'spacer' }),
      h('button', { class: 'btn dark', onclick: openPreview }, icon('play'), 'Preview quiz app'),
      bell,
      h('div', { class: 'chip' }, icon('calendar'), new Date().toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })));

    var page = h('div', { class: 'page' });
    root.appendChild(h('div', { class: 'shell' }, nav, h('div', { class: 'main' }, topbar, page)));
    var renderers = { overview: viewOverview, questions: viewQuestions, transfer: viewTransfer, progress: viewProgress, settings: viewSettings, applock: viewAppLock };
    renderers[state.view](page);

    // the App Lock count and the bell's red dot come from the overview numbers
    Promise.all([api('GET', '/api/overview'), api('GET', '/api/settings')]).then(function (r) {
      var o = r[0]; o.configured_size = r[1].questions_per_quiz;
      if (countBadge) { countBadge.textContent = String(o.protected_apps); countBadge.style.display = o.protected_apps ? '' : 'none'; }
      alerts = alertsFor(o);
      bellDot.style.display = alerts.length ? '' : 'none';
    }).catch(function () {});
  }

  function pageHeader(title, subtitle, extra) {
    return h('div', { class: 'pagehead' },
      h('div', {}, h('h1', {}, title), subtitle ? h('div', { class: 'sub' }, subtitle) : null),
      h('div', { class: 'spacer' }), extra || null);
  }

  function scoreBadge(a) {
    if (a.kind === 'admin_override') return h('span', { class: 'badge gray' }, 'Admin PIN');
    if (!a.finished_at) return h('span', { class: 'badge gray' }, 'Unfinished');
    return h('span', { class: 'badge ' + (a.passed ? 'good' : 'warn') }, a.score + '/100 · ' + (a.passed ? 'Passed' : 'Retry'));
  }

  function attemptsTable(items, onOpen) {
    if (!items.length) return h('div', { class: 'empty' }, 'No quiz attempts yet.');
    var body = h('tbody');
    items.forEach(function (a) {
      body.appendChild(h('tr', {},
        h('td', {}, fmtDate(a.started_at)),
        h('td', {}, a.target_name || '—'),
        h('td', {}, scoreBadge(a)),
        h('td', {}, a.kind === 'quiz' && a.finished_at ? a.correct + ' / ' + a.total : '—'),
        h('td', {}, fmtDuration(a.duration_seconds)),
        h('td', { class: 'actions' }, a.kind === 'quiz' && onOpen ? h('button', { class: 'btn small', onclick: function () { onOpen(a.id); } }, 'Details') : null)));
    });
    return h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['When', 'App', 'Result', 'Correct', 'Duration', ''].map(function (t) { return h('th', {}, t); }))), body));
  }

  function showAttempt(id) {
    api('GET', '/api/attempts/' + id).then(function (d) {
      var rows = h('tbody');
      d.answers.forEach(function (a) {
        rows.appendChild(h('tr', {},
          h('td', {}, a.is_correct ? '✅' : '❌'),
          h('td', {}, h('div', { class: 'small muted' }, a.subject), h('div', {}, a.question),
            a.is_correct ? null : h('div', { class: 'small' }, 'Chose: ' + a.chosen + '  ·  Correct: ' + a.correct_answer))));
      });
      modal('Attempt on ' + fmtDate(d.started_at), h('div', {},
        h('p', {}, scoreBadge(d), '  ', d.correct + ' of ' + d.total + ' correct'),
        h('div', { class: 'table-wrap', style: 'max-height:50vh;overflow-y:auto' }, h('table', {}, rows))),
        [{ label: 'Close', run: function (close) { close(); } }]);
    }).catch(fail);
  }

  // ---------------------------------------------------------------- dashboard
  function statIcon(name, bg) { return h('div', { class: 'stat-ico', style: 'background:' + bg }, icon(name)); }

  function ring(pct) {
    var C = 2 * Math.PI * 21;
    var svg = svgEl('svg', { viewBox: '0 0 56 56', width: '56', height: '56', 'class': 'ring', 'aria-hidden': 'true' },
      svgEl('circle', { cx: 28, cy: 28, r: 21, fill: 'none', stroke: '#E3EFE2', 'stroke-width': 6 }),
      svgEl('circle', { cx: 28, cy: 28, r: 21, fill: 'none', stroke: '#2E9E5B', 'stroke-width': 6, 'stroke-linecap': 'round',
        'stroke-dasharray': (C * pct / 100) + ' ' + C, transform: 'rotate(-90 28 28)' }));
    var t = svgEl('text', { x: 28, y: 32, 'text-anchor': 'middle', style: 'font-size:13px;font-weight:800;fill:#171715' });
    t.textContent = String(pct);
    svg.appendChild(t);
    return svg;
  }

  function dayKey(d) {
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  function weeklyCard(progressData) {
    var range = 7;
    var holder = h('div');
    var select = h('select', { class: 'mini' }, h('option', { value: '7' }, 'This week'), h('option', { value: '14' }, 'Last 14 days'));
    function draw() {
      var byDate = {};
      progressData.daily.forEach(function (d) { byDate[d.date] = d; });
      var days = [];
      for (var i = range - 1; i >= 0; i--) { var d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
      var rows = days.map(function (d) { return { d: d, e: byDate[dayKey(d)] || null }; });
      var attempts = 0, scoreSum = 0, best = -1, bestIdx = -1;
      rows.forEach(function (r, idx) {
        if (!r.e) return;
        attempts += r.e.attempts; scoreSum += r.e.avg_score * r.e.attempts;
        if (r.e.avg_score > best) { best = r.e.avg_score; bestIdx = idx; }
      });
      var bars = h('div', { class: 'bars' }), axis = h('div', { class: 'axis' });
      rows.forEach(function (r, idx) {
        var pct = r.e ? r.e.avg_score : 0;
        bars.appendChild(h('div', { class: 'col' + (idx === bestIdx ? ' best' : ''), title: r.e ? (r.e.attempts + ' attempt(s), average ' + r.e.avg_score + '%') : 'No attempts' },
          idx === bestIdx ? h('div', { class: 'pct' }, pct + '%') : null,
          h('div', { class: 'fill', style: 'height:' + Math.max(pct * 1.2, 3) + 'px' })));
        axis.appendChild(h('span', {}, range === 7 ? 'SMTWTFS'.charAt(r.d.getDay()) : String(r.d.getDate())));
      });
      clear(holder);
      holder.appendChild(h('div', { class: 'sums' },
        h('div', {}, h('b', {}, String(attempts)), h('span', {}, 'Attempts')),
        h('div', {}, h('b', {}, attempts ? Math.round(scoreSum / attempts) + '%' : '—'), h('span', {}, 'Avg. score'))));
      holder.appendChild(bars); holder.appendChild(axis);
      if (!attempts) holder.appendChild(h('p', { class: 'muted small', style: 'margin-top:12px' }, 'Bars appear here after the first quiz.'));
    }
    select.addEventListener('change', function () { range = Number(select.value); draw(); });
    draw();
    return h('div', { class: 'card week' },
      h('div', { class: 'row' }, h('div', {}, h('div', { class: 'eyebrow' }, 'Learning progress'), h('h2', { style: 'margin:4px 0 0' }, 'Weekly activity')), h('div', { class: 'spacer' }), select),
      holder);
  }

  function viewOverview(box) {
    Promise.all([api('GET', '/api/overview'), api('GET', '/api/settings'), api('GET', '/api/subjects'), api('GET', '/api/progress'), api('GET', '/api/apps')]).then(function (res) {
      var o = res[0], s = res[1], subjects = res[2], p = res[3], apps = res[4];
      clear(box);
      var hour = new Date().getHours();
      var greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
      if (s.learner_name) greeting += ', ' + s.learner_name;

      box.appendChild(h('div', { class: 'hero' },
        h('div', { class: 'eyebrow' }, icon('spark'), greeting),
        h('h2', {}, 'Ready for another learning adventure?'),
        h('p', {}, 'Your learners are making great progress. Keep the momentum going.'),
        h('button', { class: 'btn dark hero-btn', onclick: openPreview }, 'Start practice session', h('span', { class: 'arrow' }, icon('arrow'))),
        h('div', { class: 'float a' }, 'A+'), h('div', { class: 'float s' }, '★'),
        h('div', { class: 'bubble' }, h('strong', {}, 'Let’s learn!'), h('span', {}, o.session_size + ' questions · No time limit')),
        h('img', { class: 'art', src: '/mascot.svg', alt: '' })));

      if (o.session_size === 0) box.appendChild(h('div', { class: 'notice' }, 'There are no active questions, so the quiz cannot start. Add some in the Quiz Library.'));

      var switchInput = h('input', { type: 'checkbox', checked: o.guard_enabled, 'aria-label': 'Protection on or off' });
      switchInput.addEventListener('change', function () {
        api('PUT', '/api/settings', { guard_enabled: switchInput.checked ? 1 : 0 })
          .then(function () { toast(switchInput.checked ? 'Protection is on.' : 'Protection paused. No app will be closed.'); renderShell(); }).catch(fail);
      });
      var enabledApps = apps.filter(function (a) { return a.enabled; });
      var appColors = ['#3D7BF2', '#E5484D', '#8B5CF6', '#E8A317'];
      box.appendChild(h('div', { class: 'grid stats4' },
        h('div', { class: 'card stat-card' }, statIcon('library', '#FFF1B8'), h('div', { class: 'eyebrow' }, 'Quiz questions'),
          h('div', { class: 'value' }, String(o.questions)),
          h('div', { class: 'note' }, o.questions_added_30d ? h('b', {}, '+' + o.questions_added_30d) : String(o.questions_active), o.questions_added_30d ? ' added this month' : ' active')),
        h('div', { class: 'card stat-card' }, statIcon('progress', '#E6E1FB'), h('div', { class: 'eyebrow' }, 'Avg. score'),
          h('div', { class: 'value' }, o.attempts ? String(o.avg_score) : '—', o.attempts ? h('small', {}, '%') : null),
          h('div', { class: 'note' }, o.attempts ? 'Best score ' + o.best_score + '%' : 'No quizzes yet')),
        h('div', { class: 'card stat-card' }, statIcon('check', '#DDF2E1'), h('div', { class: 'eyebrow' }, 'Pass rate'),
          h('div', { class: 'value' }, o.attempts ? String(o.pass_rate) : '—', o.attempts ? h('small', {}, '%') : null),
          h('div', { class: 'note' }, 'Minimum score ', h('b', {}, o.passing_score + '%')), ring(o.passing_score)),
        h('div', { class: 'card stat-card dark-card' },
          h('label', { class: 'switch' }, switchInput, h('i')),
          h('div', { class: 'apps' }, enabledApps.slice(0, 4).map(function (a, i) { return h('span', { style: 'background:' + appColors[i % 4] }, (a.name || '?').charAt(0).toUpperCase()); })),
          h('div', { class: 'big' }, o.guard_enabled ? o.protected_apps + ' app' + (o.protected_apps === 1 ? '' : 's') + ' protected' : 'Protection paused'),
          h('div', { class: 'note' }, o.guard_enabled ? 'Quiz required to unlock' : 'No app is being closed'))));

      var byName = {};
      p.by_subject.forEach(function (x) { byName[x.subject] = x; });
      var tiles = h('div', { class: 'tiles' });
      subjects.slice(0, 8).forEach(function (sub, i) {
        var stat = byName[sub.name];
        tiles.appendChild(h('div', { class: 'tile' + (sub.enabled ? '' : ' off'), onclick: function () { state.subjectFilter = String(sub.id); goto('questions'); } },
          h('div', { class: 'glyph', style: 'background:' + tint(i) }, sub.icon),
          h('div', {}, h('div', { class: 't' }, sub.name), h('div', { class: 's' }, sub.question_count + ' questions')),
          h('div', { class: 'avg' }, stat ? stat.accuracy + '%' : '—', h('small', {}, 'avg.'))));
      });
      box.appendChild(h('div', { class: 'grid main-split mt' },
        h('div', { class: 'card' },
          h('div', { class: 'row', style: 'margin-bottom:14px' }, h('div', {}, h('div', { class: 'eyebrow' }, 'Curriculum'), h('h2', { style: 'margin:4px 0 0' }, 'Your subjects')),
            h('div', { class: 'spacer' }), h('button', { class: 'link', onclick: function () { state.subjectFilter = ''; goto('questions'); } }, 'View all', icon('arrow'))),
          subjects.length ? tiles : h('div', { class: 'empty' }, 'No subjects yet. Create one in the Quiz Library.')),
        weeklyCard(p)));
      box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'Recent attempts'), attemptsTable(o.recent, showAttempt)));
    }).catch(fail);
  }
  function viewRefresh() { renderShell(); }

  // ---------------------------------------------------------------- subjects & questions
  function viewQuestions(box) {
    Promise.all([api('GET', '/api/subjects'), api('GET', '/api/questions?subject_id=' + encodeURIComponent(state.subjectFilter) + '&q=' + encodeURIComponent(state.search))])
      .then(function (res) {
        var subjects = res[0], questions = res[1];
        clear(box);
        box.appendChild(pageHeader('Quiz Library', 'Add and edit subjects and questions. Each exam takes its questions evenly from the subjects that are switched on.',
          h('button', { class: 'btn primary', onclick: function () { editQuestion(null, subjects); } }, '＋ Add question')));

        var list = h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0' }, 'Subjects'), h('div', { class: 'spacer' }),
          h('button', { class: 'btn small', onclick: function () { editSubject(null); } }, '＋ New')));
        list.appendChild(h('div', { class: 'subject-item' + (state.subjectFilter === '' ? ' active' : ''), style: 'margin-top:10px', onclick: function () { state.subjectFilter = ''; renderShell(); } },
          h('span', { class: 'icon', style: 'background:#F1ECDD' }, '📚'), h('span', { class: 'name' }, 'All subjects')));
        subjects.forEach(function (s, idx) {
          list.appendChild(h('div', { class: 'subject-item' + (String(s.id) === state.subjectFilter ? ' active' : '') + (s.enabled ? '' : ' off'), onclick: function () { state.subjectFilter = String(s.id); renderShell(); } },
            h('span', { class: 'icon', style: 'background:' + tint(idx) }, s.icon), h('span', { class: 'name' }, s.name),
            h('span', { class: 'badge gray' }, s.active_count + '/' + s.question_count),
            h('button', { class: 'btn small', title: 'Edit subject', onclick: function (e) { e.stopPropagation(); editSubject(s); } }, '✎')));
        });

        var search = h('input', { type: 'text', placeholder: 'Filter questions…', value: state.search });
        var timer;
        search.addEventListener('input', function () {
          clearTimeout(timer);
          timer = setTimeout(function () { state.search = search.value; renderShell(); var again = document.querySelector('input[placeholder^="Filter"]'); if (again) { again.focus(); again.setSelectionRange(again.value.length, again.value.length); } }, 350);
        });
        var body = h('tbody');
        questions.forEach(function (q) {
          body.appendChild(h('tr', {},
            h('td', { class: 'clip' }, h('div', {}, q.text), h('div', { class: 'small muted' }, 'Answer: ' + q.choices[q.correct_index])),
            h('td', {}, h('span', { class: 'badge' }, q.subject_name)),
            h('td', {}, h('span', { class: 'badge ' + (q.active ? 'good' : 'gray') }, q.active ? 'Active' : 'Off')),
            h('td', { class: 'actions' },
              h('button', { class: 'btn small', onclick: function () { editQuestion(q, subjects); } }, 'Edit'), ' ',
              h('button', { class: 'btn small danger', onclick: function () {
                confirmDialog('Delete this question? Past results are kept.', 'Delete').then(function (yes) {
                  if (yes) api('DELETE', '/api/questions/' + q.id).then(function () { toast('Question deleted.'); renderShell(); }).catch(fail);
                });
              } }, 'Delete'))));
        });
        var table = questions.length
          ? h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Question', 'Subject', 'Status', ''].map(function (t) { return h('th', {}, t); }))), body))
          : h('div', { class: 'empty' }, 'No questions here yet.');
        box.appendChild(h('div', { class: 'split' }, list,
          h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0' }, questions.length + ' question' + (questions.length === 1 ? '' : 's')), h('div', { class: 'spacer' }), h('div', { style: 'width:260px' }, search)), h('div', { class: 'mt' }, table))));
      }).catch(fail);
  }

  function editSubject(subject) {
    var name = h('input', { type: 'text', value: subject ? subject.name : '', maxlength: 60 });
    var icon = h('input', { type: 'text', value: subject ? subject.icon : '📘', maxlength: 8, style: 'width:90px' });
    var enabled = h('input', { type: 'checkbox', checked: subject ? subject.enabled : true });
    var body = h('div', {},
      h('label', { class: 'field' }, 'Subject name', name),
      h('label', { class: 'field' }, 'Icon (an emoji)', icon),
      h('label', { class: 'check' }, enabled, 'Include this subject in quizzes'));
    var actions = [{ label: 'Cancel', run: function (c) { c(); } }];
    if (subject) actions.push({ label: 'Delete', kind: 'danger', run: function (close) {
      confirmDialog('Delete "' + subject.name + '" and its ' + subject.question_count + ' question(s)? Past results are kept.', 'Delete subject').then(function (yes) {
        if (!yes) return;
        api('DELETE', '/api/subjects/' + subject.id).then(function () { close(); state.subjectFilter = ''; toast('Subject deleted.'); renderShell(); }).catch(fail);
      });
    } });
    actions.push({ label: 'Save', kind: 'primary', run: function (close) {
      var payload = { name: name.value, icon: icon.value, enabled: enabled.checked };
      api(subject ? 'PUT' : 'POST', subject ? '/api/subjects/' + subject.id : '/api/subjects', payload)
        .then(function () { close(); toast('Subject saved.'); renderShell(); }).catch(fail);
    } });
    modal(subject ? 'Edit subject' : 'New subject', body, actions);
  }

  function editQuestion(q, subjects) {
    if (!subjects.length) { toast('Create a subject first.', 'error'); return; }
    var subjectSel = h('select', {}, subjects.map(function (s) {
      var pick = q ? q.subject_id === s.id : (state.subjectFilter ? String(s.id) === state.subjectFilter : false);
      return h('option', { value: String(s.id), selected: pick }, s.icon + ' ' + s.name);
    }));
    var text = h('textarea', { maxlength: 1000 }); text.value = q ? q.text : '';
    var explain = h('textarea', { maxlength: 1000 }); explain.value = q ? q.explanation : '';
    var active = h('input', { type: 'checkbox', checked: q ? q.active : true });
    var rows = h('div');
    var choices = q ? q.choices.slice() : ['', '', '', ''];
    var correct = q ? q.correct_index : 0;
    var LETTERS = 'ABCDEF';

    function drawChoices() {
      clear(rows);
      choices.forEach(function (c, i) {
        var input = h('input', { type: 'text', value: c, maxlength: 300, placeholder: 'Answer ' + LETTERS[i] });
        input.addEventListener('input', function () { choices[i] = input.value; });
        var radio = h('input', { type: 'radio', name: 'correct', checked: i === correct, title: 'Mark as the correct answer' });
        radio.addEventListener('change', function () { correct = i; });
        var remove = h('button', { class: 'btn small', disabled: choices.length <= 2, title: 'Remove', onclick: function () {
          choices.splice(i, 1); if (correct >= choices.length) correct = choices.length - 1; if (correct === i) correct = 0; drawChoices();
        } }, '✕');
        rows.appendChild(h('div', { class: 'choice-row' }, radio, h('strong', {}, LETTERS[i]), input, remove));
      });
    }
    drawChoices();
    var addBtn = h('button', { class: 'btn small', onclick: function () { if (choices.length < 6) { choices.push(''); drawChoices(); } } }, '＋ Add choice');
    var body = h('div', {},
      h('label', { class: 'field' }, 'Subject', subjectSel),
      h('label', { class: 'field' }, 'Question', text),
      h('div', { class: 'field' }, 'Answer choices (select the round button next to the correct one)', h('div', { style: 'margin-top:8px' }, rows), addBtn),
      h('label', { class: 'field' }, 'Explanation shown after answering', explain),
      h('label', { class: 'check' }, active, 'Active (can appear in quizzes)'));
    modal(q ? 'Edit question' : 'New question', body, [
      { label: 'Cancel', run: function (c) { c(); } },
      { label: 'Save', kind: 'primary', run: function (close) {
        var payload = { subject_id: Number(subjectSel.value), text: text.value, choices: choices, correct_index: correct, explanation: explain.value, active: active.checked };
        api(q ? 'PUT' : 'POST', q ? '/api/questions/' + q.id : '/api/questions', payload)
          .then(function () { close(); toast('Question saved.'); renderShell(); }).catch(fail);
      } }]);
  }

  // ---------------------------------------------------------------- import / export
  function viewTransfer(box) {
    clear(box);
    box.appendChild(pageHeader('Import / Export', 'Back up your quizzes, share them, or edit them in a spreadsheet.'));
    box.appendChild(h('div', { class: 'grid two' },
      h('div', { class: 'card' }, h('h2', {}, 'Export'),
        h('p', { class: 'muted' }, 'Download every subject and question. JSON keeps everything; CSV opens in Numbers or Excel.'),
        h('div', { class: 'row' },
          h('a', { class: 'btn primary', href: '/api/export?format=json', download: '' }, 'Download JSON'),
          h('a', { class: 'btn', href: '/api/export?format=csv', download: '' }, 'Download CSV'))),
      importCard()));
    box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'File formats'),
      h('p', { class: 'muted' }, 'JSON: a list of subjects, each with questions. correct_index counts from 0.'),
      h('pre', {}, '{\n  "subjects": [{\n    "name": "Science", "icon": "🔬",\n    "questions": [{\n      "text": "Which planet is closest to the Sun?",\n      "choices": ["Venus", "Earth", "Mercury", "Mars"],\n      "correct_index": 2,\n      "explanation": "Mercury is first from the Sun."\n    }]\n  }]\n}'),
      h('p', { class: 'muted' }, 'CSV columns: subject, question, choice_a … choice_f, correct (A-F), explanation, active (1 or 0).')));
  }

  function importCard() {
    var file = h('input', { type: 'file', accept: '.json,.csv,application/json,text/csv' });
    var mode = 'merge';
    function radio(value, label, hint) {
      var r = h('input', { type: 'radio', name: 'mode', checked: value === mode });
      r.addEventListener('change', function () { mode = value; });
      return h('label', { class: 'check', style: 'display:flex;margin-bottom:6px' }, r, h('span', {}, h('strong', {}, label), ' ', h('span', { class: 'muted small' }, hint)));
    }
    var result = h('div');
    var go = h('button', { class: 'btn primary', onclick: function () {
      var f = file.files && file.files[0];
      if (!f) { toast('Choose a file first.', 'error'); return; }
      var fmt = /\.csv$/i.test(f.name) ? 'csv' : 'json';
      function run() {
        f.text().then(function (content) {
          return api('POST', '/api/import', { format: fmt, mode: mode, content: content, confirm: mode === 'replace' });
        }).then(function (r) {
          clear(result);
          result.appendChild(h('div', { class: 'notice good mt' }, 'Imported: ' + r.subjects_added + ' new subject(s), ' + r.questions_added + ' new question(s), ' + r.questions_skipped + ' duplicate(s) skipped.'));
        }).catch(function (e) { clear(result); result.appendChild(h('div', { class: 'notice mt' }, e.message)); });
      }
      if (mode === 'replace') confirmDialog('This deletes ALL current subjects and questions first. Export a backup before continuing.', 'Replace everything').then(function (y) { if (y) run(); });
      else run();
    } }, 'Import file');
    return h('div', { class: 'card' }, h('h2', {}, 'Import'),
      h('div', { class: 'field' }, file),
      radio('merge', 'Add to my quizzes', '(skips questions that already exist)'),
      radio('replace', 'Replace my quizzes', '(deletes the current bank first)'),
      h('div', { class: 'mt' }, go), result);
  }

  // ---------------------------------------------------------------- progress
  function trendChart(trend, passing) {
    var W = 640, H = 210, L = 34, B = 24, T = 10, R = 10;
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.setAttribute('width', '100%'); svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Quiz scores over time');
    function el(name, attrs, text) {
      var n = document.createElementNS(NS, name);
      Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
      if (text !== undefined) n.textContent = text;
      svg.appendChild(n); return n;
    }
    function y(v) { return T + (H - T - B) * (1 - v / 100); }
    [0, 50, 100].forEach(function (v) { el('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), stroke: '#ECE9DF' }); el('text', { x: 4, y: y(v) + 4 }, String(v)); });
    el('line', { x1: L, x2: W - R, y1: y(passing), y2: y(passing), stroke: '#2E9E5B', 'stroke-dasharray': '5 4' });
    el('text', { x: W - R - 70, y: y(passing) - 5 }, 'pass ' + passing);
    var step = trend.length > 1 ? (W - L - R) / (trend.length - 1) : 0;
    var pts = trend.map(function (t, i) { return [trend.length > 1 ? L + step * i : (L + W - R) / 2, y(t.score), t]; });
    if (pts.length > 1) el('polyline', { points: pts.map(function (p) { return p[0] + ',' + p[1]; }).join(' '), fill: 'none', stroke: '#171715', 'stroke-width': 2 });
    pts.forEach(function (p) {
      var c = el('circle', { cx: p[0], cy: p[1], r: 4.5, fill: p[2].passed ? '#2E9E5B' : '#D9822B' });
      var tip = document.createElementNS(NS, 'title'); tip.textContent = p[2].score + '/100 · ' + fmtDate(p[2].started_at); c.appendChild(tip);
    });
    return svg;
  }

  function viewProgress(box) {
    Promise.all([api('GET', '/api/progress'), api('GET', '/api/attempts?limit=50'), api('GET', '/api/overview')]).then(function (res) {
      var p = res[0], attempts = res[1], o = res[2];
      clear(box);
      box.appendChild(pageHeader('Progress & Attempts', 'See how learning is going over time.'));
      var summary = [];
      if (p.failed_before_first_pass !== null) summary.push(h('span', { class: 'badge' }, p.failed_before_first_pass + ' retries before the first pass'));
      box.appendChild(h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0' }, 'Quiz scores'), h('div', { class: 'spacer' }), summary),
        p.trend.length ? h('div', { class: 'mt' }, trendChart(p.trend, o.passing_score)) : h('div', { class: 'empty' }, 'Scores will appear here after the first quiz.')));

      var subj = h('div');
      p.by_subject.forEach(function (s) {
        var cls = s.accuracy >= o.passing_score ? 'good' : 'low';
        subj.appendChild(h('div', { class: 'row', style: 'margin-bottom:10px' },
          h('div', { style: 'width:190px;font-weight:600' }, s.subject),
          h('div', { class: 'bar ' + cls, style: 'flex:1' }, h('i', { style: 'width:' + s.accuracy + '%' })),
          h('div', { style: 'width:110px;text-align:right' }, s.accuracy + '% (' + s.correct + '/' + s.answered + ')')));
      });
      var weak = h('tbody');
      p.weakest.forEach(function (w) {
        weak.appendChild(h('tr', {}, h('td', {}, h('div', { class: 'small muted' }, w.subject), h('div', {}, w.question)), h('td', {}, h('span', { class: 'badge warn' }, w.missed + ' of ' + w.asked + ' missed'))));
      });
      box.appendChild(h('div', { class: 'grid two mt' },
        h('div', { class: 'card' }, h('h2', {}, 'Accuracy by subject'), p.by_subject.length ? subj : h('div', { class: 'empty' }, 'No answers recorded yet.')),
        h('div', { class: 'card' }, h('h2', {}, 'Questions to practise'), p.weakest.length ? h('div', { class: 'table-wrap' }, h('table', {}, weak)) : h('div', { class: 'empty' }, 'Nothing missed yet.'))));
      box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'All attempts (' + attempts.total + ')'), attemptsTable(attempts.items, showAttempt)));
    }).catch(fail);
  }

  // ---------------------------------------------------------------- app lock
  function ruleSummary(a) {
    var e = a.effective, parts = [];
    parts.push(e.questions_per_quiz + ' questions');
    parts.push('pass ' + e.passing_score + '/100');
    if (e.exams_required > 1) parts.push(e.exams_required + ' exams in a row');
    parts.push(e.unlock_minutes > 0 ? 'unlocked ' + e.unlock_minutes + ' min' : 'unlocked until closed');
    parts.push(e.subject_ids ? e.subject_ids.length + ' subject(s)' : 'all subjects');
    return parts.join(' · ');
  }

  function appModal(a, defaults, subjects) {
    function numField(key, label, hint, min, max, dflt) {
      var input = h('input', { type: 'number', min: String(min), max: String(max), placeholder: 'Default (' + dflt + ')' });
      input.value = a[key] === null || a[key] === undefined ? '' : String(a[key]);
      return { key: key, input: input, node: h('label', { class: 'field' }, label, input, h('div', { class: 'muted small', style: 'font-weight:400;margin-top:3px' }, hint)) };
    }
    var nameIn = h('input', { type: 'text', maxlength: 80 }); nameIn.value = a.name;
    var bundleIn = h('input', { type: 'text', maxlength: 200 }); bundleIn.value = a.bundle_id;
    var fs = [
      numField('questions_per_quiz', 'Questions per exam', 'Leave empty to use the default.', 1, 100, defaults.questions_per_quiz),
      numField('passing_score', 'Passing score (out of 100)', 'Leave empty to use the default.', 1, 100, defaults.passing_score),
      numField('exams_required', 'Exams to pass in a row', '1 = one exam. 2 = the learner must pass two exams, one after the other.', 1, 5, 1),
      numField('unlock_minutes', 'Unlock length (minutes)', '0 = unlocked until the app is closed. Example: 30 = a new exam every 30 minutes.', 0, 1440, defaults.unlock_minutes)
    ];
    var chosen = a.subject_ids;
    var checks = subjects.map(function (sj) {
      var box = h('input', { type: 'checkbox', checked: !chosen || chosen.indexOf(sj.id) > -1 });
      return { id: sj.id, box: box, node: h('label', { class: 'check subject-pick' }, box, (sj.icon || '') + ' ' + sj.name + (sj.enabled ? '' : ' (off)')) };
    });
    var body = h('div', {},
      h('p', { class: 'muted small', style: 'margin:4px 0 14px' }, 'Empty boxes use the defaults from Settings, so changing a default later still applies here.'),
      h('div', { class: 'grid two' }, h('label', { class: 'field' }, 'App name', nameIn), h('label', { class: 'field' }, 'Bundle id or file name', bundleIn)),
      h('div', { class: 'grid two' }, fs.map(function (f) { return f.node; })),
      h('h3', {}, 'Subjects in this app\u2019s exam'),
      h('p', { class: 'muted small', style: 'margin:0 0 8px' }, 'Tick the subjects the exam may draw from. All ticked = every subject that is switched on.'),
      h('div', { class: 'subject-picks' }, checks.map(function (c) { return c.node; })));
    modal('Rules for ' + a.name, body, [
      { label: 'Cancel', run: function (close) { close(); } },
      { label: 'Use all defaults', run: function (close) {
          api('PUT', '/api/apps/' + a.id, { questions_per_quiz: null, passing_score: null, unlock_minutes: null, exams_required: null, subject_ids: [] })
            .then(function () { close(); toast('Back to the defaults.'); renderShell(); }).catch(fail);
        } },
      { label: 'Save rules', kind: 'lime', run: function (close) {
          var payload = { name: nameIn.value, bundle_id: bundleIn.value };
          fs.forEach(function (f) { payload[f.key] = f.input.value === '' ? null : Number(f.input.value); });
          var picked = checks.filter(function (c) { return c.box.checked; }).map(function (c) { return c.id; });
          payload.subject_ids = picked.length === checks.length ? [] : picked;
          if (!picked.length) { toast('Tick at least one subject.', 'error'); return; }
          api('PUT', '/api/apps/' + a.id, payload).then(function () { close(); toast('Rules saved.'); renderShell(); }).catch(fail);
        } }
    ]);
  }

  function viewAppLock(box) {
    Promise.all([api('GET', '/api/overview'), api('GET', '/api/apps'), api('GET', '/api/settings'),
                 api('GET', '/api/subjects'), api('GET', '/api/app-presets')]).then(function (res) {
      var o = res[0], apps = res[1], defaults = res[2], subjects = res[3], presets = res[4];
      clear(box);
      var lockBtn = h('button', { class: 'btn', onclick: function () {
        api('POST', '/api/lock-now', {}).then(function () { toast('All apps locked again.'); renderShell(); }).catch(fail);
      } }, icon('lock'), 'Lock all apps now');
      box.appendChild(pageHeader('App Lock', 'Choose which apps need a quiz, and set the exam rules for each one. Everything else opens normally.', lockBtn));

      var master = h('input', { type: 'checkbox', checked: o.guard_enabled, 'aria-label': 'Protection on or off' });
      master.addEventListener('change', function () {
        api('PUT', '/api/settings', { guard_enabled: master.checked ? 1 : 0 })
          .then(function () { toast(master.checked ? 'Protection is on.' : 'Protection paused. No app will be closed.'); renderShell(); }).catch(fail);
      });
      box.appendChild(h('div', { class: 'card dark-card' }, h('div', { class: 'lock-hero' },
        h('div', {}, h('div', { class: 'big', style: 'font-size:22px;font-weight:750' }, o.guard_enabled ? 'Protection is on' : 'Protection is paused'),
          h('div', { style: 'color:#A7A498' }, o.guard_enabled ? 'Restricted apps are closed and replaced by the exam until it is passed.' : 'Nothing is closed while this is off. Switch it on again to protect the apps.')),
        h('div', { class: 'spacer' }), h('label', { class: 'switch' }, master, h('i')))));

      var unlocked = o.unlocked.length
        ? h('div', {}, o.unlocked.map(function (u) {
            return h('div', { class: 'row', style: 'margin-bottom:6px' },
              h('span', { class: 'badge good' }, 'Unlocked'), h('strong', {}, u.app_name || u.bundle_id),
              h('span', { class: 'muted small' }, (u.reason === 'admin_override' ? 'by admin PIN' : 'quiz passed') +
                (u.expires_at ? ' · until ' + fmtDate(u.expires_at) : ' · until the app is closed')));
          }))
        : h('p', { class: 'muted', style: 'margin:0' }, 'Every restricted app is locked right now.');
      box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'Apps right now'), unlocked,
        o.admin_overrides ? h('p', { class: 'small muted', style: 'margin-top:8px' }, 'Admin PIN used ' + o.admin_overrides + ' time(s).') : null));

      var body = h('tbody');
      apps.forEach(function (a) {
        var on = h('input', { type: 'checkbox', checked: a.enabled });
        on.addEventListener('change', function () { api('PUT', '/api/apps/' + a.id, { enabled: on.checked }).then(function () { toast(on.checked ? 'Restriction on.' : 'Restriction off.'); renderShell(); }).catch(fail); });
        var custom = ['questions_per_quiz', 'passing_score', 'unlock_minutes', 'exams_required'].some(function (k) { return a[k] !== null; }) || !!a.subject_ids;
        body.appendChild(h('tr', {}, h('td', {}, on),
          h('td', {}, h('strong', {}, a.name), h('div', { class: 'muted small' }, a.bundle_id || 'matched by name')),
          h('td', { class: 'small' }, h('span', { class: 'badge' + (custom ? '' : ' plain') }, custom ? 'Own rules' : 'Default rules'), h('div', { class: 'muted small', style: 'margin-top:3px' }, ruleSummary(a))),
          h('td', { class: 'actions' }, h('button', { class: 'btn small', style: 'margin-right:6px', onclick: function () { appModal(a, defaults, subjects); } }, 'Edit rules'),
            h('button', { class: 'btn small danger', onclick: function () {
            confirmDialog('Stop restricting "' + a.name + '"?', 'Remove').then(function (y) { if (y) api('DELETE', '/api/apps/' + a.id).then(renderShell).catch(fail); });
          } }, 'Remove'))));
      });
      var picker = h('select', {}, h('option', { value: '' }, 'Pick from installed apps…'));
      var nameIn = h('input', { type: 'text', placeholder: 'App name, e.g. Minecraft', maxlength: 80 });
      var bundleIn = h('input', { type: 'text', placeholder: 'Bundle id or file name (optional)', maxlength: 200 });
      var presetRow = h('div', { class: 'preset-row' }, presets.map(function (pr) {
        var have = apps.some(function (a) { return a.name.toLowerCase() === pr.name.toLowerCase(); });
        return h('button', { class: 'chip-btn', disabled: have, title: have ? 'Already on the list' : 'Add ' + pr.name, onclick: function () {
          api('POST', '/api/apps', { name: pr.name, bundle_id: pr.bundle_id }).then(function () { toast(pr.name + ' added.'); renderShell(); }).catch(fail);
        } }, (have ? '✓ ' : '+ ') + pr.name);
      }));
      api('GET', '/api/installed-apps').then(function (list) {
        list.forEach(function (a) { picker.appendChild(h('option', { value: a.bundle_id + '|' + a.name }, a.name)); });
      }).catch(function () {});
      picker.addEventListener('change', function () {
        if (!picker.value) return; var parts = picker.value.split('|'); bundleIn.value = parts[0]; nameIn.value = parts.slice(1).join('|');
      });
      box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'Restricted apps'),
        h('p', { class: 'muted' }, 'These apps are closed and replaced by the exam until it is passed. Anything not on this list opens normally. Each app can have its own number of questions, passing score, unlock length, exams in a row and subjects (press Edit rules); apps without their own rules use the defaults under Settings. Names match from the start, so "Roblox" also covers "Roblox Studio". Untick a row to pause its restriction.'),
        apps.length ? h('div', { class: 'table-wrap' }, h('table', {}, body)) : h('div', { class: 'empty' }, 'No apps are restricted.'),
        h('h3', { class: 'mt' }, 'Add an app'),
        h('p', { class: 'muted small', style: 'margin:0 0 8px' }, 'Quick add:'), presetRow,
        h('div', { class: 'grid two', style: 'margin-top:12px' }, picker, nameIn, bundleIn,
          h('button', { class: 'btn primary', style: 'justify-content:center', onclick: function () {
            api('POST', '/api/apps', { name: nameIn.value, bundle_id: bundleIn.value }).then(function () { toast('App added.'); renderShell(); }).catch(fail);
          } }, 'Add to restricted list'))));
    }).catch(fail);
  }

  // ---------------------------------------------------------------- settings
  function viewSettings(box) {
    api('GET', '/api/settings').then(function (s) {
      clear(box);
      box.appendChild(pageHeader('Settings', 'Control the exam rules and text, the learner’s name and the admin PIN.'));

      var fields = {};
      function num(key, label, hint, min, max) {
        fields[key] = h('input', { type: 'number', min: String(min), max: String(max), value: String(s[key]) });
        return h('label', { class: 'field' }, label, fields[key], h('div', { class: 'muted small', style: 'font-weight:400;margin-top:3px' }, hint));
      }
      var texts = {};
      function txt(key, label, hint, max, multiline) {
        texts[key] = multiline
          ? h('textarea', { maxlength: String(max), rows: '3' })
          : h('input', { type: 'text', maxlength: String(max) });
        texts[key].value = s[key];
        return h('label', { class: 'field' }, label, texts[key], h('div', { class: 'muted small', style: 'font-weight:400;margin-top:3px' }, hint));
      }
      var shuffle = h('input', { type: 'checkbox', checked: !!s.shuffle_choices });
      var onTop = h('input', { type: 'checkbox', checked: !!s.exam_on_top });
      var need = h('p', { class: 'muted small mt' });
      function refreshNeed() {
        var n = Math.max(1, Number(fields.questions_per_quiz.value) || 1);
        var size = Math.min(n, s.active_questions_available);
        var pass = Math.max(1, Math.min(100, Number(fields.passing_score.value) || 1));
        var correct = Math.ceil(pass * size / 100);
        need.textContent = size < n
          ? 'Only ' + size + ' active questions are available, so the exam will have ' + size + ' questions (add more in the Quiz Library). '
          : '';
        need.textContent += 'To pass, a learner needs ' + correct + ' of ' + size + ' correct.';
      }
      var save = h('button', { class: 'btn primary', onclick: function () {
        var payload = { shuffle_choices: shuffle.checked ? 1 : 0, exam_on_top: onTop.checked ? 1 : 0 };
        Object.keys(fields).forEach(function (k) { payload[k] = Number(fields[k].value); });
        api('PUT', '/api/settings', payload).then(function () { toast('Settings saved.'); renderShell(); }).catch(fail);
      } }, 'Save settings');
      box.appendChild(h('div', { class: 'card' }, h('h2', {}, 'Default exam rules'),
        h('p', { class: 'muted' }, 'These apply to every app that has no rules of its own. Give one app different rules under App Lock, Edit rules.'),
        h('div', { class: 'grid two' },
          num('questions_per_quiz', 'Questions per exam', 'How many questions one exam has. Default 10, shared evenly between the subjects that are on.', 1, 100),
          num('passing_score', 'Passing score (out of 100)', 'Learners must reach this to unlock an app. Default 70.', 1, 100),
          num('unlock_minutes', 'Unlock length after passing (minutes)', '0 = stays unlocked until the app is closed. Example: 10 = the exam comes back every 10 minutes while the learner keeps playing.', 0, 1440),
          num('reopen_grace_seconds', 'Time to start the app after passing (seconds)', 'After passing, the app must be started within this time. Some apps (games, for example) start from a website, so give enough time to press Play. Once the app has been closed, the next open needs a new exam. Default 180.', 10, 3600),
          num('cover_delay_seconds', 'Seconds before the exam appears (exam-on-top mode)', 'Used only when "Show the exam on top of the app" is ticked below. After the app opens, or when the unlock time runs out, the exam appears after this many seconds. Default 5.', 0, 300),
          num('admin_unlock_minutes', 'Parent unlock length (minutes)', 'How long the "open without the quiz" PIN button unlocks the app. 0 = until the app is closed.', 0, 1440)),
        h('label', { class: 'check' }, shuffle, 'Shuffle the order of answer choices'),
        h('label', { class: 'check' }, onTop, 'Show the exam on top of the app instead of closing the app first'),
        h('p', { class: 'muted small' }, 'Off (default): the app is closed and the exam appears. On: the app keeps running behind the exam. Passing returns the learner to the app; leaving the exam with the Exit button closes it.'),
        need, save));
      refreshNeed();
      fields.questions_per_quiz.addEventListener('input', refreshNeed);
      fields.passing_score.addEventListener('input', refreshNeed);

      var saveText = h('button', { class: 'btn primary', onclick: function () {
        var payload = {};
        Object.keys(texts).forEach(function (k) { payload[k] = texts[k].value; });
        api('PUT', '/api/settings', payload).then(function () { toast('Saved.'); renderShell(); }).catch(fail);
      } }, 'Save names and text');
      box.appendChild(h('div', { class: 'card mt' }, h('h2', {}, 'Name and exam screen text'),
        h('p', { class: 'muted' }, 'The learner’s name appears in the dashboard greeting. The title and message are what the learner reads on the first screen of the exam: write {app} where the app name should appear. Leave the title or message empty to go back to the default.'),
        txt('learner_name', 'Learner’s name', 'Optional. Example: Jamie.', 40, false),
        txt('intro_title', 'Exam title', 'Example: Quiz time! Pass to open {app}.', 120, false),
        txt('intro_message', 'Exam message', 'Shown under the title.', 400, true), saveText));

      var cur = h('input', { type: 'password', placeholder: 'Current PIN', autocomplete: 'current-password' });
      var next = h('input', { type: 'password', placeholder: 'New PIN (4+ characters)', autocomplete: 'new-password' });
      box.appendChild(h('div', { class: 'grid two mt' },
        h('div', { class: 'card' }, h('h2', {}, 'Admin PIN'), h('p', { class: 'muted' }, 'Used to sign in here, to leave the exam with the Exit button, and for the parent unlock button.'),
          h('div', { class: 'field' }, cur), h('div', { class: 'field' }, next),
          h('button', { class: 'btn', onclick: function () {
            api('PUT', '/api/pin', { current_pin: cur.value, new_pin: next.value }).then(function () { toast('PIN changed.'); cur.value = ''; next.value = ''; }).catch(fail);
          } }, 'Change PIN')),
        h('div', { class: 'card' }, h('h2', {}, 'Reset progress'), h('p', { class: 'muted' }, 'Deletes all quiz attempts and learning history. Questions are kept.'),
          h('button', { class: 'btn danger', onclick: function () {
            confirmDialog('Delete all attempts and progress? This cannot be undone.', 'Delete history').then(function (y) {
              if (y) api('POST', '/api/attempts/clear', { confirm: true }).then(function () { toast('History cleared.'); }).catch(fail);
            });
          } }, 'Clear attempt history'))));
    }).catch(fail);
  }

  // ---------------------------------------------------------------- boot
  api('GET', '/api/session').then(function (s) {
    if (s.authenticated) { state.csrf = s.csrf; start(); } else showLogin();
  }).catch(function () { showLogin(); });
})();
