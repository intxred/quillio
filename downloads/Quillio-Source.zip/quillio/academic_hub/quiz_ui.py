"""Full-screen quiz window (PySide6).

Started by the monitor with:  python -m academic_hub.quiz_ui --target-name Safari --target-bundle com.apple.Safari
For testing without kiosk mode:  python -m academic_hub.quiz_ui --windowed
"""

from __future__ import annotations

import argparse
import sys

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from . import config, db, macos, quiz_engine, rules as rules_mod, security

LETTERS = "ABCDEF"

STYLE = """
QWidget#root, QWidget#cover { background: #FBF9F4; }
QWidget { font-family: "Avenir Next", "Helvetica Neue", Arial, sans-serif; color: #171715; font-size: 18px; }
QLabel#brand { font-size: 14px; font-weight: 800; color: #8B887D; letter-spacing: 3px; }
QLabel#title { font-size: 44px; font-weight: 800; }
QLabel#subtitle { font-size: 20px; color: #3C4210; }
QLabel#hint { font-size: 16px; color: #55534B; }
QLabel#chip { background: #DDF264; color: #171715; border: 2px solid #171715; border-radius: 14px;
              padding: 5px 14px; font-weight: 800; font-size: 15px; }
QLabel#question { font-size: 30px; font-weight: 800; }
QLabel#error { color: #D64545; font-size: 17px; }
QLabel#score { font-size: 72px; font-weight: 800; }
QLabel#score[passed="true"] { color: #2E9E5B; }
QLabel#score[passed="false"] { color: #D9822B; }
QLabel#feedback { font-size: 20px; font-weight: 800; }
QLabel#feedback[state="correct"] { color: #2E9E5B; }
QLabel#feedback[state="wrong"] { color: #D64545; }
QLabel#explain { font-size: 18px; color: #55534B; }
QLabel#bubble { background: white; border: 2px solid #171715; border-radius: 14px; padding: 8px 16px;
                font-size: 17px; font-weight: 800; }
QFrame#hero { background: #DDF264; border: 3px solid #171715; border-radius: 26px; }
QFrame#hero QLabel#brand { color: #4B5214; }
QFrame#card { background: white; border: 1px solid #E7E3D8; border-radius: 18px; }
QPushButton { font-size: 19px; font-weight: 700; border-radius: 12px; padding: 13px 24px;
              border: 1.5px solid #D6D1C2; background: white; }
QPushButton:hover { background: #F4F2EB; }
QPushButton#primary { background: #171715; color: white; border: none; padding: 14px 28px; }
QPushButton#primary:hover { background: #33332F; }
QPushButton#exit { font-size: 16px; font-weight: 700; padding: 8px 20px; border-radius: 12px;
                   color: #55534B; background: white; border: 1.5px solid #D6D1C2; }
QPushButton#exit:hover { background: #FDEBEA; color: #D64545; border-color: #F0C5C3; }
QPushButton#link { border: none; background: transparent; color: #55534B; font-size: 15px;
                   font-weight: 600; text-decoration: underline; padding: 6px; }
QFrame#hero QPushButton#link { color: #3C4210; }
QPushButton#choice { text-align: left; padding: 16px 22px; font-weight: 500; border: 1.5px solid #E1DDD0; }
QPushButton#choice:hover:enabled { background: #F1F8C8; border-color: #171715; }
QPushButton#choice[state="correct"] { background: #E3F5E8; border: 2px solid #2E9E5B; color: #14532D; }
QPushButton#choice[state="wrong"] { background: #FDEBEA; border: 2px solid #D64545; color: #7F1D1D; }
QPushButton#choice[state="dim"] { color: #A7A498; background: #F8F6F0; border-color: #ECE9DF; }
QProgressBar { background: #EAE7DD; border: none; border-radius: 6px; min-height: 12px; max-height: 12px; }
QProgressBar::chunk { background: #171715; border-radius: 6px; }
QProgressBar[tone="good"]::chunk { background: #2E9E5B; }
QProgressBar[tone="low"]::chunk { background: #D9822B; }
QLineEdit { border: 1.5px solid #D6D1C2; border-radius: 12px; padding: 12px 16px; font-size: 22px;
            background: white; }
QLineEdit:focus { border-color: #171715; }
QScrollArea { border: none; background: transparent; }
QScrollArea > QWidget > QWidget { background: transparent; }
"""


def label(text: str = "", name: str = "", wrap: bool = True) -> QLabel:
    widget = QLabel(text)
    if name:
        widget.setObjectName(name)
    widget.setWordWrap(wrap)
    return widget


def repolish(widget: QWidget) -> None:
    widget.style().unpolish(widget)
    widget.style().polish(widget)


def mascot(width: int, sad: bool = False) -> QWidget:
    """The hedgehog from static/mascot.svg, or static/mascot-sad.svg when sad (replace those files to use other artwork)."""
    try:
        from PySide6.QtSvgWidgets import QSvgWidget

        widget = QSvgWidget(str(config.STATIC_DIR / ("mascot-sad.svg" if sad else "mascot.svg")))
        widget.setFixedSize(width, round(width * 250 / 260))
        widget.setStyleSheet("background: transparent;")
        widget.setObjectName("mascot-sad" if sad else "mascot")
        return widget
    except Exception:  # QtSvg missing or file removed: the exam still works
        fallback = QLabel("🦔")
        fallback.setAlignment(Qt.AlignmentFlag.AlignCenter)
        fallback.setStyleSheet(f"font-size: {width // 2}px; background: transparent;")
        return fallback


def centered(inner: QWidget, max_width: int = 980) -> QWidget:
    page = QWidget()
    row = QHBoxLayout(page)
    row.setContentsMargins(40, 30, 40, 30)
    row.addStretch(1)
    inner.setMaximumWidth(max_width)
    row.addWidget(inner, 100)
    row.addStretch(1)
    return page


class CoverWindow(QWidget):
    """Plain light screen that covers secondary displays during the quiz."""

    def __init__(self, geometry) -> None:
        super().__init__()
        self.setObjectName("cover")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        message = label("Quiz in progress on your other screen", "subtitle")
        message.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(message)
        self.setGeometry(geometry)


class QuizWindow(QWidget):
    def __init__(self, conn, target_name: str, target_bundle: str, windowed: bool, test_mode: bool) -> None:
        super().__init__()
        self.conn = conn
        self.windowed = windowed
        self.test_mode = test_mode
        self.target_name = target_name or "your app"
        self.target_bundle = target_bundle
        self.target_key = target_bundle or target_name
        # Exam rules for this app: its own overrides, else the Settings defaults.
        self._reload_rules()
        self.passes = 0  # exams passed in a row (some apps need more than one)
        self._allow_close = False
        self.covers: list[CoverWindow] = []

        self.session: list[dict] = []
        self.index = 0
        self.attempt_id: int | None = None
        self.answered = False
        self.missed: list[tuple[dict, str]] = []

        self.setObjectName("root")
        self.setWindowTitle("Quillio")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        if not windowed:
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)

        self.stack = QStackedWidget()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Always-visible Exit button (asks for the admin PIN). Hidden on the PIN screen itself.
        self.top_bar = QWidget()
        top = QHBoxLayout(self.top_bar)
        top.setContentsMargins(24, 18, 28, 0)
        top.addStretch(1)
        self.exit_btn = QPushButton("✕  Exit")
        self.exit_btn.setObjectName("exit")
        self.exit_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exit_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.exit_btn.clicked.connect(self.show_exit)
        top.addWidget(self.exit_btn)
        outer.addWidget(self.top_bar)
        outer.addWidget(self.stack, 1)

        self.pin_mode = "exit"  # "exit" closes the exam; "unlock" opens the app without the quiz
        self._pin_return: QWidget | None = None

        self.page_intro = self._build_intro()
        self.page_question = self._build_question()
        self.page_admin = self._build_admin()
        self.page_result: QWidget | None = None
        for page in (self.page_intro, self.page_question, self.page_admin):
            self.stack.addWidget(page)
        self.stack.setCurrentWidget(self.page_intro)

        self.front_timer = QTimer(self)
        self.front_timer.timeout.connect(self._ensure_front)
        if not windowed:
            self.front_timer.start(1000)

    # ------------------------------------------------------------ presentation
    def present(self) -> None:
        if self.windowed:
            self.resize(1180, 800)
            self.show()
            return
        # Show the exam on the screen being used right now (where the mouse is), not always the main one.
        primary = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        self.setGeometry(primary.geometry())
        self.show()
        macos.enter_kiosk_mode()
        for screen in QApplication.screens():
            if screen is not primary:
                cover = CoverWindow(screen.geometry())
                cover.show()
                self.covers.append(cover)
        macos.activate_app()
        self.raise_()
        self.activateWindow()
        macos.elevate_all_windows()
        QTimer.singleShot(300, macos.elevate_all_windows)   # again once Qt has finished showing
        QTimer.singleShot(1200, macos.elevate_all_windows)
        QTimer.singleShot(2000, self._log_state)

    def _log_state(self) -> None:
        names = ", ".join(f"{s.name()} {s.geometry().width()}x{s.geometry().height()}" for s in QApplication.screens())
        print(f"[exam window] screens: {names}; {macos.describe_windows()}", file=sys.stderr, flush=True)

    def _ensure_front(self) -> None:
        """Runs every second while the exam is up: keeps it in front of the browser and every other app."""
        macos.activate_app()
        if self.isMinimized():
            self.showNormal()
        self.raise_()
        self.activateWindow()
        macos.elevate_all_windows()  # after Qt's raise, which can lower the level again
        macos.enter_kiosk_mode()     # only takes effect once the app is active, so it is retried

    def changeEvent(self, event) -> None:  # block minimising
        super().changeEvent(event)
        if not self.windowed and self.isMinimized():
            QTimer.singleShot(0, self.showNormal)

    def closeEvent(self, event) -> None:  # block Cmd+Q / Cmd+W until the quiz is done
        if self._allow_close or self.windowed:  # a preview window closes normally; the real exam does not
            event.accept()
        else:
            event.ignore()

    def finish_and_quit(self) -> None:
        self._allow_close = True
        for cover in self.covers:
            cover.close()
        QApplication.quit()

    def keyPressEvent(self, event) -> None:
        if self.stack.currentWidget() is self.page_question:
            text = event.text().lower()
            if text and text in "123456abcdef":
                idx = "123456".index(text) if text in "123456" else "abcdef".index(text)
                self.choose(idx)
                return
            if int(event.key()) in (int(Qt.Key.Key_Return), int(Qt.Key.Key_Enter), int(Qt.Key.Key_Space)):
                if self.answered:
                    self.next_question()
                return
        # Escape and everything else are swallowed on purpose.

    # ------------------------------------------------------------ intro page
    def _build_intro(self) -> QWidget:
        hero = QFrame()
        hero.setObjectName("hero")
        row = QHBoxLayout(hero)
        row.setContentsMargins(52, 44, 44, 40)
        row.setSpacing(24)

        col = QVBoxLayout()
        col.setSpacing(14)
        col.addWidget(label("✦  QUILLIO", "brand"))
        self.intro_title = label("", "title")
        col.addWidget(self.intro_title)
        self.intro_info = label("", "subtitle")
        col.addWidget(self.intro_info)
        self.intro_message = label("", "hint")
        col.addWidget(self.intro_message)
        self.intro_error = label("", "error")
        col.addWidget(self.intro_error)
        col.addSpacing(6)
        start = QPushButton("Start the quiz   →")
        start.setObjectName("primary")
        start.clicked.connect(self.start_quiz)
        start.setCursor(Qt.CursorShape.PointingHandCursor)
        col.addWidget(start, 0, Qt.AlignmentFlag.AlignLeft)
        admin = QPushButton("Parent: open without the quiz")
        admin.setObjectName("link")
        admin.clicked.connect(self.show_admin)
        admin.setCursor(Qt.CursorShape.PointingHandCursor)
        col.addWidget(admin, 0, Qt.AlignmentFlag.AlignLeft)
        row.addLayout(col, 3)

        art = QVBoxLayout()
        art.addStretch(1)
        bubble = label("Let's learn!", "bubble", wrap=False)
        art.addWidget(bubble, 0, Qt.AlignmentFlag.AlignRight)
        art.addWidget(mascot(250), 0, Qt.AlignmentFlag.AlignRight)
        art.addStretch(1)
        row.addLayout(art, 2)

        self._refresh_intro_info()
        return centered(hero, 1080)

    def _reload_rules(self) -> None:
        """Read the app's exam rules again, so a change made in the dashboard applies to the next exam."""
        if self.test_mode:
            self.rules = rules_mod.defaults(self.conn)
        else:
            self.rules = rules_mod.for_app(self.conn, self.target_name, self.target_bundle)

    def _text_setting(self, key: str) -> str:
        text = db.get_setting(self.conn, key, db.DEFAULT_TEXT_SETTINGS[key]).strip()
        return (text or db.DEFAULT_TEXT_SETTINGS[key]).replace("{app}", self.target_name)

    def _refresh_intro_info(self) -> None:
        self._reload_rules()
        passing = self.rules["passing_score"]
        self.intro_title.setText(self._text_setting("intro_title"))
        self.intro_message.setText(self._text_setting("intro_message"))
        info = f"{quiz_engine.session_size(self.conn, self.rules)} questions  ·  no time limit  ·  you need {passing}/100 to pass"
        required = self.rules["exams_required"]
        if required > 1:
            info += f"  ·  pass {required} exams in a row"
        self.intro_info.setText(info)

    # ------------------------------------------------------------ question page
    def _build_question(self) -> QWidget:
        inner = QWidget()
        col = QVBoxLayout(inner)
        col.setSpacing(14)
        col.addStretch(1)
        top = QHBoxLayout()
        self.q_progress_label = label("", "hint", wrap=False)
        self.q_chip = label("", "chip", wrap=False)
        top.addWidget(self.q_chip)
        top.addStretch(1)
        top.addWidget(self.q_progress_label)
        col.addLayout(top)
        self.q_bar = QProgressBar()
        self.q_bar.setTextVisible(False)
        col.addWidget(self.q_bar)
        col.addSpacing(8)
        self.q_text = label("", "question")
        col.addWidget(self.q_text)
        self.choice_buttons: list[QPushButton] = []
        for i in range(len(LETTERS)):
            btn = QPushButton()
            btn.setObjectName("choice")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _=False, idx=i: self.choose(idx))
            self.choice_buttons.append(btn)
            col.addWidget(btn)
        self.feedback_card = QFrame()
        self.feedback_card.setObjectName("card")
        fb = QVBoxLayout(self.feedback_card)
        self.feedback_title = label("", "feedback")
        self.feedback_text = label("", "explain")
        fb.addWidget(self.feedback_title)
        fb.addWidget(self.feedback_text)
        col.addWidget(self.feedback_card)
        self.next_btn = QPushButton("Next question")
        self.next_btn.setObjectName("primary")
        self.next_btn.clicked.connect(self.next_question)
        col.addWidget(self.next_btn, 0, Qt.AlignmentFlag.AlignRight)
        col.addStretch(1)
        return centered(inner, 980)

    def start_quiz(self) -> None:
        self._reload_rules()
        try:
            self.session = quiz_engine.build_session(self.conn, rules=self.rules)
        except quiz_engine.NoQuestionsError as exc:
            self.intro_error.setText(str(exc))
            return
        self.attempt_id = quiz_engine.start_attempt(
            self.conn,
            self.target_name if not self.test_mode else "(test)",
            self.target_key,
            self.rules["passing_score"],
        )
        self.index = 0
        self.missed = []
        self.show_question()
        self.stack.setCurrentWidget(self.page_question)

    def show_question(self) -> None:
        q = self.session[self.index]
        self.answered = False
        self.q_chip.setText(f"{q['subject_icon']}  {q['subject_name']}")
        self.q_progress_label.setText(f"Question {self.index + 1} of {len(self.session)}")
        self.q_bar.setRange(0, len(self.session))
        self.q_bar.setValue(self.index)
        self.q_text.setText(q["text"])
        for i, btn in enumerate(self.choice_buttons):
            if i < len(q["choices"]):
                btn.setText(f"{LETTERS[i]}.   {q['choices'][i]}")
                btn.setProperty("state", "")
                btn.setEnabled(True)
                btn.setVisible(True)
                repolish(btn)
            else:
                btn.setVisible(False)
        self.feedback_card.setVisible(False)
        self.next_btn.setVisible(False)

    def choose(self, idx: int) -> None:
        if self.answered or self.stack.currentWidget() is not self.page_question:
            return
        q = self.session[self.index]
        if idx >= len(q["choices"]):
            return
        self.answered = True
        correct = quiz_engine.record_answer(self.conn, self.attempt_id, q, idx)
        for i, btn in enumerate(self.choice_buttons[: len(q["choices"])]):
            if i == q["correct_index"]:
                btn.setProperty("state", "correct")
            elif i == idx:
                btn.setProperty("state", "wrong")
            else:
                btn.setProperty("state", "dim")
            btn.setEnabled(False)
            repolish(btn)
        if correct:
            self.feedback_title.setText("✅  Correct! Great job.")
            self.feedback_title.setProperty("state", "correct")
        else:
            self.missed.append((q, q["choices"][idx]))
            self.feedback_title.setText(
                f"❌  Not quite. The correct answer is {LETTERS[q['correct_index']]}. {q['choices'][q['correct_index']]}"
            )
            self.feedback_title.setProperty("state", "wrong")
        repolish(self.feedback_title)
        self.feedback_text.setText(q["explanation"] or "")
        self.feedback_text.setVisible(bool(q["explanation"]))
        self.feedback_card.setVisible(True)
        last = self.index == len(self.session) - 1
        self.next_btn.setText("See my score" if last else "Next question")
        self.next_btn.setVisible(True)

    def next_question(self) -> None:
        if not self.answered:
            return
        self.index += 1
        if self.index >= len(self.session):
            self.show_result()
        else:
            self.show_question()

    # ------------------------------------------------------------ result page
    def show_result(self) -> None:
        result = quiz_engine.finish_attempt(self.conn, self.attempt_id, len(self.session))
        required = self.rules["exams_required"]
        if result["passed"]:
            self.passes += 1
        else:
            self.passes = 0  # exams must be passed in a row
        unlocked = result["passed"] and self.passes >= required
        if unlocked:
            quiz_engine.grant_unlock(
                self.conn, self.target_key, self.target_name, self.attempt_id,
                minutes=self.rules["unlock_minutes"],
            )

        inner = QWidget()
        col = QVBoxLayout(inner)
        col.setSpacing(10)
        head = QHBoxLayout()
        head_text = QVBoxLayout()
        head_text.setSpacing(10)
        head_text.addWidget(label("QUILLIO", "brand"))
        score = label(f"{result['score']}/100", "score", wrap=False)
        score.setProperty("passed", "true" if result["passed"] else "false")
        head_text.addWidget(score)
        if unlocked:
            headline = f"You passed! {self.target_name} is unlocked."
        elif result["passed"]:
            left = required - self.passes
            headline = f"Exam {self.passes} of {required} passed. {left} more to go."
        else:
            headline = f"Not yet. You need {result['passing_score']}/100 to pass."
        head_text.addWidget(label(headline, "title"))
        head_text.addWidget(
            label(f"You got {result['correct']} of {result['total']} questions right.", "hint")
        )
        head.addLayout(head_text, 1)
        head.addWidget(mascot(150, sad=not result["passed"]), 0, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight)
        col.addLayout(head)

        grid = QGridLayout()
        grid.setHorizontalSpacing(36)
        grid.setVerticalSpacing(6)
        for n, (name, stats) in enumerate(result["by_subject"].items()):
            row = QHBoxLayout()
            row.setSpacing(12)
            name_label = label(name, wrap=False)
            name_label.setMinimumWidth(190)
            bar = QProgressBar()
            bar.setTextVisible(False)
            bar.setRange(0, stats["total"])
            bar.setValue(stats["correct"])
            pct = stats["correct"] * 100 // max(stats["total"], 1)
            bar.setProperty("tone", "good" if pct >= result["passing_score"] else "low")
            count = label(f"{stats['correct']}/{stats['total']}", wrap=False)
            count.setMinimumWidth(40)
            row.addWidget(name_label)
            row.addWidget(bar, 1)
            row.addWidget(count)
            grid.addLayout(row, n // 2, n % 2)
        col.addLayout(grid)

        if self.missed:
            col.addSpacing(6)
            col.addWidget(label("Let's review the ones to remember:", "hint"))
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setMinimumHeight(90)
            holder = QWidget()
            holder_col = QVBoxLayout(holder)
            for q, chosen in self.missed:
                card = QFrame()
                card.setObjectName("card")
                card_col = QVBoxLayout(card)
                card_col.addWidget(label(f"{q['subject_name']}: {q['text']}"))
                card_col.addWidget(
                    label(f"Your answer: {chosen}   ·   Correct: {q['choices'][q['correct_index']]}", "hint")
                )
                holder_col.addWidget(card)
            holder_col.addStretch(1)
            scroll.setWidget(holder)
            col.addWidget(scroll, 1)
        else:
            col.addStretch(1)

        if unlocked:
            grace = max(10, db.get_int(self.conn, "reopen_grace_seconds", 180))
            minutes = self.rules["unlock_minutes"]
            lasts = (
                f"It stays unlocked for {minutes} minute(s), then you need a new quiz."
                if minutes > 0
                else "Once you close it, the next time needs a new quiz."
            )
            col.addWidget(
                label(
                    f"If {self.target_name} does not start by itself, start it the way you normally do "
                    f"within {max(1, round(grace / 60))} minute(s). {lasts}",
                    "hint",
                )
            )
        buttons = QHBoxLayout()
        if result["passed"] and not unlocked:
            nxt = QPushButton(f"Start exam {self.passes + 1} of {required}   →")
            nxt.setObjectName("primary")
            nxt.clicked.connect(self.start_quiz)
            buttons.addWidget(nxt)
        elif unlocked:
            go = QPushButton(f"Open {self.target_name}")
            go.setObjectName("primary")
            go.clicked.connect(self.open_target)
            buttons.addWidget(go)
        else:
            retry = QPushButton("Try again with new questions")
            retry.setObjectName("primary")
            retry.clicked.connect(self.start_quiz)
            buttons.addWidget(retry)
        buttons.addStretch(1)
        col.addLayout(buttons)

        page = centered(inner, 1000)
        old = self.page_result
        self.page_result = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        if old is not None:
            self.stack.removeWidget(old)
            old.deleteLater()

    def open_target(self) -> None:
        if not self.test_mode:
            macos.launch_app(self.target_name, self.target_bundle)
        QTimer.singleShot(500, self.finish_and_quit)

    # ------------------------------------------------------------ PIN page (exit / parent unlock)
    def _build_admin(self) -> QWidget:
        inner = QWidget()
        col = QVBoxLayout(inner)
        col.setSpacing(16)
        col.addStretch(2)
        col.addWidget(label("QUILLIO", "brand"))
        self.pin_title = label("", "title")
        col.addWidget(self.pin_title)
        self.pin_subtitle = label("", "subtitle")
        col.addWidget(self.pin_subtitle)
        self.pin_input = QLineEdit()
        self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.pin_input.setPlaceholderText("PIN")
        self.pin_input.setMaximumWidth(360)
        self.pin_input.returnPressed.connect(self.submit_pin)
        col.addWidget(self.pin_input)
        self.pin_error = label("", "error")
        col.addWidget(self.pin_error)
        row = QHBoxLayout()
        self.pin_ok = QPushButton("")
        self.pin_ok.setObjectName("primary")
        self.pin_ok.clicked.connect(self.submit_pin)
        back = QPushButton("Back")
        back.clicked.connect(self.hide_admin)
        row.addWidget(self.pin_ok)
        row.addWidget(back)
        row.addStretch(1)
        col.addLayout(row)
        col.addStretch(3)
        return centered(inner, 860)

    def _open_pin_page(self, mode: str) -> None:
        current = self.stack.currentWidget()
        if current is not self.page_admin:
            self._pin_return = current
        self.pin_mode = mode
        if mode == "exit":
            self.pin_title.setText("Exit the exam")
            self.pin_subtitle.setText(
                f"Enter the PIN to close the exam. {self.target_name} stays closed until the quiz is passed."
            )
            self.pin_ok.setText("Exit exam")
        else:
            self.pin_title.setText("Parent access")
            self.pin_subtitle.setText(f"Enter the admin PIN to open {self.target_name} without the quiz.")
            self.pin_ok.setText("Unlock")
        self.pin_input.clear()
        self.pin_error.clear()
        self.top_bar.setVisible(False)
        self.stack.setCurrentWidget(self.page_admin)
        self.pin_input.setFocus()

    def show_exit(self) -> None:
        self._open_pin_page("exit")

    def show_admin(self) -> None:
        self._open_pin_page("unlock")

    def hide_admin(self) -> None:
        """Back from the PIN page to wherever the learner was (question, result or start)."""
        self.pin_input.clear()
        self.top_bar.setVisible(True)
        self._refresh_intro_info()
        target = self._pin_return or self.page_intro
        if self.stack.indexOf(target) < 0:  # the result page may have been replaced meanwhile
            target = self.page_result or self.page_intro
        self.stack.setCurrentWidget(target)

    def submit_pin(self) -> None:
        ok, message = security.check_pin(self.conn, self.pin_input.text())
        self.pin_input.clear()
        if not ok:
            self.pin_error.setText(message)
            return
        if self.pin_mode == "exit":
            self.finish_and_quit()  # nothing is unlocked; an unfinished attempt stays "Unfinished"
            return
        quiz_engine.record_admin_override(self.conn, self.target_name, self.target_key)
        self.open_target()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Quillio full-screen quiz")
    parser.add_argument("--target-name", default="")
    parser.add_argument("--target-bundle", default="")
    parser.add_argument("--windowed", action="store_true", help="normal window, no kiosk mode (testing)")
    args = parser.parse_args(argv)

    conn = db.connect()
    db.init_db(conn)

    app = QApplication(sys.argv[:1])
    app.setQuitOnLastWindowClosed(False)
    app.setStyleSheet(STYLE)
    if not args.windowed:
        macos.use_overlay_policy()  # lets the exam cover a full-screen browser
        print("[exam window] starting (front-fix 3)", file=sys.stderr, flush=True)

    test_mode = not args.target_name
    window = QuizWindow(conn, args.target_name or "a test app", args.target_bundle, args.windowed, test_mode)
    window.present()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
