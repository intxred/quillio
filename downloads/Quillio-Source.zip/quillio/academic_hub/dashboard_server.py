"""Local admin dashboard: a tiny JSON API plus static files, on 127.0.0.1 only.

Run with:  python -m academic_hub.dashboard_server
Open:      http://127.0.0.1:8765  (works in Safari, Chrome, Firefox...)

Security model
  * Listens on loopback only, and rejects any Host header that is not 127.0.0.1/localhost
    (blocks DNS-rebinding).
  * Every API call except login needs a session cookie (HttpOnly, SameSite=Strict) created by
    entering the admin PIN. Changing data also needs the per-session CSRF header.
  * Bodies must be JSON, so cross-site <form> posts are rejected.
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import re
import secrets
import sqlite3
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import bank_io, config, db, macos, progress, quiz_engine, security
from . import rules as rules_mod

log = logging.getLogger("academic_hub.dashboard")

COOKIE = "ah_session"
SESSION_TTL = 8 * 3600
MAX_BODY = 6 * 1024 * 1024
SESSIONS: dict[str, dict] = {}

STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/app.css": ("app.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "application/javascript; charset=utf-8"),
    "/mascot.svg": ("mascot.svg", "image/svg+xml"),
}

SETTING_LIMITS = {
    "passing_score": (1, 100),
    "questions_per_quiz": (1, 100),
    "unlock_minutes": (0, 1440),
    "admin_unlock_minutes": (0, 1440),
    "reopen_grace_seconds": (10, 3600),
    "exam_on_top": (0, 1),
    "cover_delay_seconds": (0, 300),
    "shuffle_choices": (0, 1),
    "guard_enabled": (0, 1),
}


class ApiError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


class Download:
    def __init__(self, body: bytes, content_type: str, filename: str) -> None:
        self.body, self.content_type, self.filename = body, content_type, filename


class Ctx:
    def __init__(self, conn, params, query, body, session) -> None:
        self.conn = conn
        self.params = params
        self.query = query
        self.body = body
        self.session = session
        self.new_session: dict | None = None
        self.clear_session = False


ROUTES: list = []


def route(method: str, pattern: str, public: bool = False):
    regex = re.compile("^" + pattern + "$")

    def decorator(fn):
        ROUTES.append((method, regex, fn, public))
        return fn

    return decorator


def bad(message: str, status: int = 400):
    raise ApiError(status, message)


def int_param(ctx: Ctx, name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(ctx.query.get(name, [default])[0])
    except (TypeError, ValueError):
        return default
    return max(low, min(high, value))


# ================================================================== session

@route("GET", r"/api/session", public=True)
def api_session(ctx: Ctx):
    return {
        "authenticated": bool(ctx.session),
        "pin_set": security.pin_is_set(ctx.conn),
        "csrf": ctx.session["csrf"] if ctx.session else None,
    }


def _open_session(ctx: Ctx) -> dict:
    session = {"token": secrets.token_urlsafe(32), "csrf": secrets.token_urlsafe(24),
               "expires": time.time() + SESSION_TTL}
    SESSIONS[session["token"]] = session
    ctx.new_session = session
    return {"ok": True, "csrf": session["csrf"]}


@route("POST", r"/api/login", public=True)
def api_login(ctx: Ctx):
    ok, message = security.check_pin(ctx.conn, str(ctx.body.get("pin", "")))
    if not ok:
        bad(message, 401)
    return _open_session(ctx)


@route("POST", r"/api/setup", public=True)
def api_setup(ctx: Ctx):
    if security.pin_is_set(ctx.conn):
        bad("An admin PIN already exists.", 409)
    try:
        security.set_pin(ctx.conn, str(ctx.body.get("pin", "")))
    except ValueError as exc:
        bad(str(exc))
    return _open_session(ctx)


@route("POST", r"/api/logout")
def api_logout(ctx: Ctx):
    SESSIONS.pop(ctx.session["token"], None)
    ctx.clear_session = True
    return {"ok": True}


@route("PUT", r"/api/pin")
def api_change_pin(ctx: Ctx):
    ok, message = security.check_pin(ctx.conn, str(ctx.body.get("current_pin", "")))
    if not ok:
        bad(message, 403)
    try:
        security.set_pin(ctx.conn, str(ctx.body.get("new_pin", "")))
    except ValueError as exc:
        bad(str(exc))
    return {"ok": True}


# ================================================================== overview / progress

@route("GET", r"/api/overview")
def api_overview(ctx: Ctx):
    return progress.overview(ctx.conn)


@route("GET", r"/api/progress")
def api_progress(ctx: Ctx):
    return progress.learning_progress(ctx.conn)


@route("GET", r"/api/attempts")
def api_attempts(ctx: Ctx):
    return progress.list_attempts(
        ctx.conn, int_param(ctx, "limit", 50, 1, 200), int_param(ctx, "offset", 0, 0, 10**9)
    )


@route("GET", r"/api/attempts/(?P<id>\d+)")
def api_attempt(ctx: Ctx):
    detail = progress.attempt_detail(ctx.conn, int(ctx.params["id"]))
    if detail is None:
        bad("Attempt not found.", 404)
    return detail


@route("POST", r"/api/attempts/clear")
def api_clear_attempts(ctx: Ctx):
    if ctx.body.get("confirm") is not True:
        bad("Confirmation required.")
    ctx.conn.execute("DELETE FROM attempt_answers")
    ctx.conn.execute("DELETE FROM attempts")
    return {"ok": True}


_preview: dict = {"proc": None}


def _spawn_preview():
    """Open the exam in a normal window (no restrictions, nothing is closed or unlocked)."""
    import os
    import subprocess

    env = os.environ.copy()
    env["PYTHONPATH"] = str(config.APP_DIR)
    out = open(config.log_dir() / "quiz.log", "ab")
    return subprocess.Popen(
        [sys.executable, "-m", "academic_hub.quiz_ui", "--windowed"],
        cwd=str(config.APP_DIR), env=env, stdout=out, stderr=out, **config.detached_popen_kwargs(),
    )


@route("POST", r"/api/preview-quiz")
def api_preview_quiz(ctx: Ctx):
    proc = _preview["proc"]
    if proc is not None and proc.poll() is None:
        return {"ok": True, "already_open": True}
    try:
        _preview["proc"] = _spawn_preview()
    except OSError as exc:
        bad(f"Could not open the quiz window: {exc}", 500)
    return {"ok": True, "already_open": False}


@route("POST", r"/api/lock-now")
def api_lock_now(ctx: Ctx):
    """Revoke every unlock; the monitor closes the apps within a second."""
    ctx.conn.execute("UPDATE unlocks SET active = 0 WHERE active = 1")
    return {"ok": True}


# ================================================================== subjects

def _subject_json(row) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "icon": row["icon"],
        "position": row["position"],
        "enabled": bool(row["enabled"]),
        "question_count": row["question_count"],
        "active_count": row["active_count"],
    }


_SUBJECT_SELECT = (
    "SELECT s.*, (SELECT COUNT(*) FROM questions q WHERE q.subject_id = s.id) AS question_count, "
    "(SELECT COUNT(*) FROM questions q WHERE q.subject_id = s.id AND q.active = 1) AS active_count "
    "FROM subjects s"
)


def _clean_subject_name(value) -> str:
    name = str(value or "").strip()
    if not name or len(name) > 60:
        bad("A subject name needs 1 to 60 characters.")
    return name


@route("GET", r"/api/subjects")
def api_subjects(ctx: Ctx):
    return [_subject_json(r) for r in ctx.conn.execute(_SUBJECT_SELECT + " ORDER BY s.position, s.id")]


@route("POST", r"/api/subjects")
def api_subject_create(ctx: Ctx):
    name = _clean_subject_name(ctx.body.get("name"))
    icon = (str(ctx.body.get("icon") or "📘").strip() or "📘")[:8]
    position = ctx.conn.execute("SELECT COALESCE(MAX(position), -1) + 1 AS p FROM subjects").fetchone()["p"]
    try:
        cur = ctx.conn.execute(
            "INSERT INTO subjects(name, icon, position, enabled) VALUES (?, ?, ?, ?)",
            (name, icon, position, 1 if ctx.body.get("enabled", True) else 0),
        )
    except sqlite3.IntegrityError:
        bad("A subject with that name already exists.", 409)
    return _subject_json(ctx.conn.execute(_SUBJECT_SELECT + " WHERE s.id = ?", (cur.lastrowid,)).fetchone())


@route("PUT", r"/api/subjects/(?P<id>\d+)")
def api_subject_update(ctx: Ctx):
    sid = int(ctx.params["id"])
    row = ctx.conn.execute("SELECT * FROM subjects WHERE id = ?", (sid,)).fetchone()
    if row is None:
        bad("Subject not found.", 404)
    name = _clean_subject_name(ctx.body.get("name", row["name"]))
    icon = (str(ctx.body.get("icon", row["icon"]) or "📘").strip() or "📘")[:8]
    enabled = 1 if ctx.body.get("enabled", bool(row["enabled"])) else 0
    position = int(ctx.body.get("position", row["position"]))
    try:
        ctx.conn.execute(
            "UPDATE subjects SET name = ?, icon = ?, enabled = ?, position = ? WHERE id = ?",
            (name, icon, enabled, position, sid),
        )
    except sqlite3.IntegrityError:
        bad("A subject with that name already exists.", 409)
    return _subject_json(ctx.conn.execute(_SUBJECT_SELECT + " WHERE s.id = ?", (sid,)).fetchone())


@route("DELETE", r"/api/subjects/(?P<id>\d+)")
def api_subject_delete(ctx: Ctx):
    cur = ctx.conn.execute("DELETE FROM subjects WHERE id = ?", (int(ctx.params["id"]),))
    if cur.rowcount == 0:
        bad("Subject not found.", 404)
    return {"ok": True}


# ================================================================== questions

def _question_json(row) -> dict:
    data = db.question_row_to_dict(row)
    data["subject_name"] = row["subject_name"]
    return data


_QUESTION_SELECT = (
    "SELECT q.*, s.name AS subject_name FROM questions q JOIN subjects s ON s.id = q.subject_id"
)


@route("GET", r"/api/questions")
def api_questions(ctx: Ctx):
    sql, args = _QUESTION_SELECT + " WHERE 1 = 1", []
    subject = ctx.query.get("subject_id", [""])[0]
    if subject.isdigit():
        sql += " AND q.subject_id = ?"
        args.append(int(subject))
    search = ctx.query.get("q", [""])[0].strip()
    if search:
        sql += " AND (q.text LIKE ? ESCAPE '\\' OR q.choices LIKE ? ESCAPE '\\')"
        like = "%" + search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        args += [like, like]
    sql += " ORDER BY s.position, q.id LIMIT 3000"
    return [_question_json(r) for r in ctx.conn.execute(sql, args)]


def _require_subject(ctx: Ctx, value) -> int:
    try:
        sid = int(value)
    except (TypeError, ValueError):
        bad("Choose a subject.")
    if ctx.conn.execute("SELECT 1 FROM subjects WHERE id = ?", (sid,)).fetchone() is None:
        bad("That subject does not exist.", 404)
    return sid


def _clean(ctx: Ctx) -> dict:
    try:
        return bank_io.clean_question(ctx.body)
    except ValueError as exc:
        bad(str(exc))


@route("POST", r"/api/questions")
def api_question_create(ctx: Ctx):
    sid = _require_subject(ctx, ctx.body.get("subject_id"))
    q = _clean(ctx)
    now = db.now()
    cur = ctx.conn.execute(
        "INSERT INTO questions(subject_id, text, choices, correct_index, explanation, active, created_at, "
        "updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (sid, q["text"], json.dumps(q["choices"], ensure_ascii=False), q["correct_index"],
         q["explanation"], 1 if q["active"] else 0, now, now),
    )
    return _question_json(ctx.conn.execute(_QUESTION_SELECT + " WHERE q.id = ?", (cur.lastrowid,)).fetchone())


@route("PUT", r"/api/questions/(?P<id>\d+)")
def api_question_update(ctx: Ctx):
    qid = int(ctx.params["id"])
    if ctx.conn.execute("SELECT 1 FROM questions WHERE id = ?", (qid,)).fetchone() is None:
        bad("Question not found.", 404)
    sid = _require_subject(ctx, ctx.body.get("subject_id"))
    q = _clean(ctx)
    ctx.conn.execute(
        "UPDATE questions SET subject_id = ?, text = ?, choices = ?, correct_index = ?, explanation = ?, "
        "active = ?, updated_at = ? WHERE id = ?",
        (sid, q["text"], json.dumps(q["choices"], ensure_ascii=False), q["correct_index"],
         q["explanation"], 1 if q["active"] else 0, db.now(), qid),
    )
    return _question_json(ctx.conn.execute(_QUESTION_SELECT + " WHERE q.id = ?", (qid,)).fetchone())


@route("DELETE", r"/api/questions/(?P<id>\d+)")
def api_question_delete(ctx: Ctx):
    cur = ctx.conn.execute("DELETE FROM questions WHERE id = ?", (int(ctx.params["id"]),))
    if cur.rowcount == 0:
        bad("Question not found.", 404)
    return {"ok": True}


# ================================================================== import / export

@route("GET", r"/api/export")
def api_export(ctx: Ctx):
    fmt = ctx.query.get("format", ["json"])[0]
    bank = bank_io.export_bank(ctx.conn)
    stamp = time.strftime("%Y%m%d")
    if fmt == "csv":
        return Download(bank_io.bank_to_csv(bank).encode("utf-8-sig"), "text/csv; charset=utf-8",
                        f"quillio-quizzes-{stamp}.csv")
    return Download(json.dumps(bank, ensure_ascii=False, indent=2).encode("utf-8"),
                    "application/json; charset=utf-8", f"quillio-quizzes-{stamp}.json")


@route("POST", r"/api/import")
def api_import(ctx: Ctx):
    fmt = str(ctx.body.get("format", "json")).lower()
    mode = str(ctx.body.get("mode", "merge")).lower()
    content = ctx.body.get("content")
    if fmt not in ("json", "csv") or not isinstance(content, str) or not content.strip():
        bad("Choose a JSON or CSV file to import.")
    if mode == "replace" and ctx.body.get("confirm") is not True:
        bad("Replacing the quiz bank needs confirmation.")
    try:
        return bank_io.import_bank(ctx.conn, bank_io.parse_payload(fmt, content), mode)
    except ValueError as exc:
        bad(str(exc))


# ================================================================== settings

def _settings_json(conn) -> dict:
    data = {key: db.get_int(conn, key, int(db.DEFAULT_SETTINGS[key])) for key in SETTING_LIMITS}
    for key, default in db.DEFAULT_TEXT_SETTINGS.items():
        data[key] = db.get_setting(conn, key, default)
    data["session_size"] = progress.session_size(conn)
    data["active_questions_available"] = quiz_engine.available_questions(conn)
    data["pin_set"] = security.pin_is_set(conn)
    return data


@route("GET", r"/api/settings")
def api_settings(ctx: Ctx):
    return _settings_json(ctx.conn)


@route("PUT", r"/api/settings")
def api_settings_update(ctx: Ctx):
    updates = {}
    for key, (low, high) in SETTING_LIMITS.items():
        if key in ctx.body:
            try:
                value = int(ctx.body[key])
            except (TypeError, ValueError):
                bad(f"{key.replace('_', ' ')} must be a number.")
            if not low <= value <= high:
                bad(f"{key.replace('_', ' ')} must be between {low} and {high}.")
            updates[key] = value
    for key, limit in db.TEXT_SETTING_LIMITS.items():
        if key in ctx.body:
            text = str(ctx.body[key]).strip()
            if len(text) > limit:
                bad(f"{key.replace('_', ' ')} can be at most {limit} characters.")
            updates[key] = text or db.DEFAULT_TEXT_SETTINGS[key]  # empty = back to the default
    for key, value in updates.items():
        db.set_setting(ctx.conn, key, value)
    return _settings_json(ctx.conn)


# ================================================================== restricted apps

_BUNDLE_RE = re.compile(r"^[A-Za-z0-9._-]{0,200}$")


def _app_json(row, conn=None) -> dict:
    data = {
        "id": row["id"], "name": row["name"], "bundle_id": row["bundle_id"], "enabled": bool(row["enabled"]),
        # the app's own exam rules; null means "use the Settings default"
        "questions_per_quiz": row["questions_per_quiz"],
        "passing_score": row["passing_score"],
        "unlock_minutes": row["unlock_minutes"],
        "exams_required": row["exams_required"],
        "subject_ids": rules_mod._subject_ids(row["subject_ids"]),
    }
    if conn is not None:
        data["effective"] = rules_mod.effective(conn, row)
    return data


def _clean_rules(conn, body: dict, current=None) -> dict:
    """Validate the per-app exam rule fields present in `body`. Returns {column: value-or-None}."""
    out: dict = {}
    for column, (_, _, (low, high)) in rules_mod.OVERRIDES.items():
        if column not in body:
            continue
        raw = body[column]
        if raw is None or raw == "":
            out[column] = None  # back to the default
            continue
        try:
            value = int(raw)
        except (TypeError, ValueError):
            bad(f"{column.replace('_', ' ')} must be a number.")
        if not low <= value <= high:
            bad(f"{column.replace('_', ' ')} must be between {low} and {high}.")
        out[column] = value
    if "subject_ids" in body:
        raw = body["subject_ids"]
        if not raw:
            out["subject_ids"] = None  # every enabled subject
        else:
            if not isinstance(raw, list):
                bad("subject_ids must be a list.")
            try:
                ids = sorted({int(x) for x in raw})
            except (TypeError, ValueError):
                bad("subject_ids must be numbers.")
            known = {r["id"] for r in conn.execute("SELECT id FROM subjects")}
            if any(i not in known for i in ids):
                bad("One of the chosen subjects does not exist.")
            out["subject_ids"] = json.dumps(ids)
    return out


def _clean_app(body: dict) -> tuple[str, str]:
    name = str(body.get("name", "")).strip()
    bundle = str(body.get("bundle_id", "")).strip()
    if not name and not bundle:
        bad("Enter an app name or a bundle id.")
    if len(name) > 80:
        bad("The app name is too long.")
    if not _BUNDLE_RE.match(bundle):
        bad("A bundle id may only contain letters, numbers, dots, dashes and underscores.")
    if name and len(name) < 4 and not bundle:
        bad("Names shorter than 4 letters need a bundle id too (names are matched as prefixes).")
    return name or bundle.rsplit(".", 1)[-1], bundle


@route("GET", r"/api/apps")
def api_apps(ctx: Ctx):
    return [_app_json(r, ctx.conn) for r in ctx.conn.execute("SELECT * FROM restricted_apps ORDER BY name")]


# Popular apps to add with one click. The name is matched as a prefix, the id/file name is exact.
_PRESETS_MAC = [
    ("Roblox", "com.roblox.RobloxPlayer"), ("Minecraft", "com.mojang.minecraftlauncher"),
    ("Fortnite", ""), ("Steam", "com.valvesoftware.steam"), ("Discord", "com.hnc.Discord"),
    ("Epic Games Launcher", "com.epicgames.EpicGamesLauncher"), ("Spotify", "com.spotify.client"),
    ("Google Chrome", "com.google.Chrome"), ("Safari", "com.apple.Safari"), ("Netflix", ""),
]
_PRESETS_WIN = [
    ("Roblox", "RobloxPlayerBeta.exe"), ("Minecraft Launcher", "MinecraftLauncher.exe"),
    ("Fortnite", "FortniteClient-Win64-Shipping.exe"), ("Steam", "steam.exe"), ("Discord", "Discord.exe"),
    ("Epic Games Launcher", "EpicGamesLauncher.exe"), ("Spotify", "Spotify.exe"),
    ("Google Chrome", "chrome.exe"), ("Microsoft Edge", "msedge.exe"), ("Netflix", "Netflix.exe"),
]


@route("GET", r"/api/app-presets")
def api_app_presets(ctx: Ctx):
    presets = _PRESETS_WIN if sys.platform == "win32" else _PRESETS_MAC
    return [{"name": n, "bundle_id": b} for n, b in presets]


@route("GET", r"/api/installed-apps")
def api_installed_apps(ctx: Ctx):
    return macos.installed_apps()


@route("POST", r"/api/apps")
def api_app_create(ctx: Ctx):
    name, bundle = _clean_app(ctx.body)
    extra = _clean_rules(ctx.conn, ctx.body)
    try:
        cur = ctx.conn.execute(
            "INSERT INTO restricted_apps(name, bundle_id, enabled) VALUES (?, ?, 1)", (name, bundle)
        )
    except sqlite3.IntegrityError:
        bad("That app is already on the list.", 409)
    for column, value in extra.items():
        ctx.conn.execute(f"UPDATE restricted_apps SET {column} = ? WHERE id = ?", (value, cur.lastrowid))
    return _app_json(
        ctx.conn.execute("SELECT * FROM restricted_apps WHERE id = ?", (cur.lastrowid,)).fetchone(), ctx.conn
    )


@route("PUT", r"/api/apps/(?P<id>\d+)")
def api_app_update(ctx: Ctx):
    aid = int(ctx.params["id"])
    row = ctx.conn.execute("SELECT * FROM restricted_apps WHERE id = ?", (aid,)).fetchone()
    if row is None:
        bad("App not found.", 404)
    name, bundle = _clean_app({"name": ctx.body.get("name", row["name"]),
                               "bundle_id": ctx.body.get("bundle_id", row["bundle_id"])})
    enabled = 1 if ctx.body.get("enabled", bool(row["enabled"])) else 0
    extra = _clean_rules(ctx.conn, ctx.body, row)
    try:
        ctx.conn.execute(
            "UPDATE restricted_apps SET name = ?, bundle_id = ?, enabled = ? WHERE id = ?",
            (name, bundle, enabled, aid),
        )
    except sqlite3.IntegrityError:
        bad("That app is already on the list.", 409)
    for column, value in extra.items():
        ctx.conn.execute(f"UPDATE restricted_apps SET {column} = ? WHERE id = ?", (value, aid))
    return _app_json(ctx.conn.execute("SELECT * FROM restricted_apps WHERE id = ?", (aid,)).fetchone(), ctx.conn)


@route("DELETE", r"/api/apps/(?P<id>\d+)")
def api_app_delete(ctx: Ctx):
    cur = ctx.conn.execute("DELETE FROM restricted_apps WHERE id = ?", (int(ctx.params["id"]),))
    if cur.rowcount == 0:
        bad("App not found.", 404)
    return {"ok": True}


# ================================================================== HTTP plumbing

class Handler(BaseHTTPRequestHandler):
    server_version = "AcademicHub/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # route access logs to the log file at DEBUG
        log.debug("%s %s", self.address_string(), fmt % args)

    # ---- helpers
    def _allowed_hosts(self) -> set[str]:
        port = config.DASHBOARD_PORT
        return {f"127.0.0.1:{port}", f"localhost:{port}"}

    def _send(self, status: int, body: bytes, content_type: str, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
        )
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data, status: int = 200, extra: dict | None = None) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", extra)

    def _session(self) -> dict | None:
        now = time.time()
        for token in [t for t, s in SESSIONS.items() if s["expires"] < now]:
            SESSIONS.pop(token, None)
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get(COOKIE)
        return SESSIONS.get(morsel.value) if morsel else None

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ApiError(413, "That file is too large (6 MB max).")
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        if not self.headers.get("Content-Type", "").lower().startswith("application/json"):
            raise ApiError(415, "Requests must be JSON.")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            raise ApiError(400, "Malformed JSON.") from None
        if not isinstance(data, dict):
            raise ApiError(400, "Expected a JSON object.")
        return data

    # ---- dispatch
    def _handle(self) -> None:
        method = self.command if self.command != "HEAD" else "GET"
        try:
            if self.headers.get("Host", "") not in self._allowed_hosts():
                raise ApiError(403, "Forbidden host.")
            parsed = urlparse(self.path)
            path = parsed.path
            if not path.startswith("/api/"):
                return self._static(path, method)
            origin = self.headers.get("Origin")
            if method != "GET" and origin and origin not in {f"http://{h}" for h in self._allowed_hosts()}:
                raise ApiError(403, "Cross-site request blocked.")
            for route_method, regex, fn, public in ROUTES:
                match = regex.match(path)
                if match and route_method == method:
                    return self._call(fn, public, match.groupdict(), parse_qs(parsed.query), method)
            if any(r[1].match(path) for r in ROUTES):
                raise ApiError(405, "Method not allowed.")
            raise ApiError(404, "Not found.")
        except ApiError as exc:
            # The request body may be unread; never reuse the connection for another request.
            self.close_connection = True
            self._json({"error": exc.message}, exc.status, {"Connection": "close"})
        except Exception:
            log.exception("unhandled error for %s %s", self.command, self.path)
            self.close_connection = True
            self._json({"error": "Something went wrong on the server."}, 500, {"Connection": "close"})

    def _call(self, fn, public: bool, params: dict, query: dict, method: str) -> None:
        session = self._session()
        if not public:
            if session is None:
                raise ApiError(401, "Please sign in.")
            if method != "GET" and self.headers.get("X-CSRF-Token") != session["csrf"]:
                raise ApiError(403, "Missing or invalid CSRF token.")
        body = self._read_body() if method in ("POST", "PUT", "DELETE") else {}
        conn = db.connect()
        try:
            ctx = Ctx(conn, params, query, body, session)
            result = fn(ctx)
        finally:
            conn.close()
        extra = {}
        if ctx.new_session:
            extra["Set-Cookie"] = (
                f"{COOKIE}={ctx.new_session['token']}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_TTL}"
            )
        if ctx.clear_session:
            extra["Set-Cookie"] = f"{COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
        if isinstance(result, Download):
            extra["Content-Disposition"] = f'attachment; filename="{result.filename}"'
            return self._send(200, result.body, result.content_type, extra)
        self._json(result, 200, extra)

    def _static(self, path: str, method: str) -> None:
        entry = STATIC.get(path)
        if entry is None or method != "GET":
            raise ApiError(404, "Not found.")
        filename, content_type = entry
        try:
            body = (config.STATIC_DIR / filename).read_bytes()
        except OSError:
            raise ApiError(404, "Not found.") from None
        self._send(200, body, content_type)

    do_GET = do_POST = do_PUT = do_DELETE = do_HEAD = _handle


def make_server(host: str = config.DASHBOARD_HOST, port: int = config.DASHBOARD_PORT) -> ThreadingHTTPServer:
    if host not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("The dashboard only listens on the loopback interface.")
    ThreadingHTTPServer.daemon_threads = True
    ThreadingHTTPServer.allow_reuse_address = True
    return ThreadingHTTPServer((host, port), Handler)


def main() -> None:
    handler = logging.handlers.RotatingFileHandler(
        config.log_dir() / "dashboard.log", maxBytes=512_000, backupCount=3
    )
    logging.basicConfig(level=logging.INFO, handlers=[handler, logging.StreamHandler()],
                        format="%(asctime)s %(levelname)s %(message)s")
    conn = db.connect()
    db.init_db(conn)
    conn.close()
    try:
        server = make_server()
    except OSError as exc:
        log.error("cannot listen on %s:%s: %s", config.DASHBOARD_HOST, config.DASHBOARD_PORT, exc)
        sys.exit(1)
    log.info("dashboard ready at %s", config.DASHBOARD_URL)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
