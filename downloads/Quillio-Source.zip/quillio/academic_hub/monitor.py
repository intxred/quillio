"""Background monitor: closes restricted apps until the quiz has been passed.

Runs as a LaunchAgent in the logged-in user's session (on Windows it is started by the supervisor). Every ~0.4 s it lists the
running applications. A restricted app (any app on the App Lock list; Roblox by default) that has no active
unlock is quit immediately and the full-screen quiz is started for it. The quiz
writes an unlock row to SQLite once the learner passes (or a parent enters the
admin PIN); the monitor then leaves that app alone until it is closed.

Fail-closed: if the quiz cannot start, restricted apps simply stay closed.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import signal
import subprocess
import sys
import time

from . import config, db, macos, quiz_engine
from .rules import MIN_NAME_LENGTH, find_rule  # noqa: F401 - find_rule is re-exported for tests

POLL_SECONDS = 0.4
DEFAULT_COVER_DELAY = 5       # seconds before the exam appears over a running app (exam-on-top mode)
DEFAULT_REOPEN_GRACE = 180    # seconds; the real value is the "reopen_grace_seconds" setting
CLOSE_DEBOUNCE = 8.0          # an unlocked app that has been gone this long counts as closed
QUIZ_RESTART_COOLDOWN = 2.0   # avoid a launch storm if the quiz crashes at start-up

log = logging.getLogger("academic_hub.monitor")


class Monitor:
    def __init__(self) -> None:
        self.conn = db.connect()
        db.init_db(self.conn)
        self.quiz: subprocess.Popen | None = None
        self.quiz_ended_at = 0.0
        self.last_quiz_start = 0.0
        self.last_seen: dict[str, float] = {}
        self.blocked_since: dict[str, float] = {}   # exam-on-top mode: when a locked app was first seen
        self.covering: set[str] = set()              # exam-on-top mode: apps the exam is currently covering
        self.stop = False

    # -------------------------------------------------------------- quiz process
    def quiz_running(self) -> bool:
        if self.quiz is None:
            return False
        if self.quiz.poll() is None:
            return True
        log.info("quiz process exited with code %s", self.quiz.returncode)
        self.quiz = None
        self.quiz_ended_at = time.time()
        return False

    def start_quiz(self, name: str, bundle_id: str) -> None:
        if self.quiz_running() or time.time() - self.last_quiz_start < QUIZ_RESTART_COOLDOWN:
            return
        self.last_quiz_start = time.time()
        env = os.environ.copy()
        env["PYTHONPATH"] = str(config.APP_DIR)
        out = open(config.log_dir() / "quiz.log", "ab")
        cmd = [sys.executable, "-m", "academic_hub.quiz_ui", "--target-name", name, "--target-bundle", bundle_id]
        log.info("starting quiz for %s (%s)", name, bundle_id or "no bundle id")
        self.quiz = subprocess.Popen(
            cmd, cwd=str(config.APP_DIR), env=env, stdout=out, stderr=out, **config.detached_popen_kwargs()
        )

    # -------------------------------------------------------------- main tick
    def tick(self) -> None:
        now = time.time()
        rules = self.conn.execute("SELECT * FROM restricted_apps WHERE enabled = 1").fetchall()
        if db.get_int(self.conn, "guard_enabled", 1) == 0:
            rules = []  # protection paused from the dashboard: nothing is closed
        running_keys: set[str] = set()
        exam_on_top = db.get_int(self.conn, "exam_on_top", 0) == 1

        for app in macos.running_apps():
            rule = find_rule(rules, app.name, app.bundle_id)
            if rule is None:
                continue
            key = app.bundle_id or app.name
            running_keys.add(key)
            if quiz_engine.active_unlock(self.conn, key):
                self.last_seen[key] = now
                self.covering.discard(key)
                self.blocked_since.pop(key, None)
                continue
            if exam_on_top:
                self._cover(app, rule, key, now)
                continue
            log.info("blocking %s (%s): no active unlock", app.name, key)
            app.terminate()
            self.start_quiz(app.name or rule["name"], app.bundle_id)

        # forget apps that are gone (exam-on-top bookkeeping)
        for key in list(self.blocked_since):
            if key not in running_keys:
                del self.blocked_since[key]
        self.covering &= running_keys

        self._housekeeping(now, running_keys)

    def _cover(self, app, rule, key: str, now: float) -> None:
        """Exam-on-top mode: leave the app running and put the exam in front of it.

        The exam starts "cover_delay_seconds" after the app is first seen without a pass. If the exam
        window is closed without a pass (the Exit button, or a crash) the app is closed, so a learner
        cannot skip the exam by leaving it.
        """
        if key in self.covering:
            if self.quiz_running():
                return                      # exam is on screen: nothing to do
            log.info("exam closed without a pass: closing %s", app.name)
            self.covering.discard(key)
            self.blocked_since.pop(key, None)
            app.terminate()
            return
        first_seen = self.blocked_since.setdefault(key, now)
        delay = max(0, db.get_int(self.conn, "cover_delay_seconds", DEFAULT_COVER_DELAY))
        if now - first_seen < delay:
            return
        log.info("showing the exam over %s (%s): no active unlock", app.name, key)
        self.start_quiz(app.name or rule["name"], app.bundle_id)
        if self.quiz_running():
            self.covering.add(key)

    def _housekeeping(self, now: float, running_keys: set[str]) -> None:
        self.conn.execute(
            "UPDATE unlocks SET active = 0 WHERE active = 1 AND expires_at IS NOT NULL AND expires_at <= ?",
            (int(now),),
        )
        if self.quiz_running():
            return  # keep fresh unlocks alive while the quiz window is still open
        # Two cases for an unlock whose app is not running right now:
        #  * the app ran after the pass and has now been closed: lock again after a few seconds, so
        #    the next time it is opened the exam comes back;
        #  * the app has not started yet (Roblox is usually started from its website, so after a pass
        #    the child needs a moment to press Play): keep the unlock for "reopen_grace_seconds".
        grace = max(10, db.get_int(self.conn, "reopen_grace_seconds", DEFAULT_REOPEN_GRACE))
        rows = self.conn.execute(
            "SELECT bundle_id, MAX(granted_at) AS granted FROM unlocks WHERE active = 1 GROUP BY bundle_id"
        ).fetchall()
        for row in rows:
            key = row["bundle_id"]
            if key in running_keys:
                continue
            granted = float(row["granted"])
            seen = self.last_seen.get(key, 0.0)
            if seen >= granted:
                expired = now - seen > CLOSE_DEBOUNCE
            else:
                expired = now - max(granted, self.quiz_ended_at) > grace
            if expired:
                log.info("%s was closed or never started; unlock revoked", key)
                quiz_engine.revoke_unlocks(self.conn, key)

    def run(self) -> None:
        log.info("monitor started (pid %s)", os.getpid())
        while not self.stop:
            try:
                self.tick()
            except Exception:  # keep guarding no matter what
                log.exception("tick failed")
            macos.pump(POLL_SECONDS)
        log.info("monitor stopped")


def _single_instance_lock():
    handle = open(config.data_dir() / "monitor.lock", "w")
    try:
        if sys.platform == "win32":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("Quillio monitor is already running.", file=sys.stderr)
        sys.exit(0)
    return handle


def main() -> None:
    handler = logging.handlers.RotatingFileHandler(
        config.log_dir() / "monitor.log", maxBytes=512_000, backupCount=3
    )
    logging.basicConfig(
        level=logging.INFO,
        handlers=[handler, logging.StreamHandler()],
        format="%(asctime)s %(levelname)s %(message)s",
    )
    lock = _single_instance_lock()  # noqa: F841 - held for the life of the process
    monitor = Monitor()

    def _stop(*_):
        monitor.stop = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    monitor.run()


if __name__ == "__main__":
    main()
