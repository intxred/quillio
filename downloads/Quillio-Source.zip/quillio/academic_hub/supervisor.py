"""Windows background helper: the counterpart of macOS launchd for Quillio.

    pythonw -m academic_hub.supervisor

It starts the monitor and the dashboard server for the protected account and starts them again if
they stop. It is started when that account signs in (a "Run" entry written by the installer) or by
the app window (`ensure_running`). On macOS and Linux nothing here does anything.

The installer writes <install folder>\\config.json:  {"user": "<windows account to protect>", "port": 8765}
"""

from __future__ import annotations

import getpass
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from . import config

IS_WIN = sys.platform == "win32"
RESTART_DELAY = 5.0   # seconds to wait before starting a helper that stopped
CHECK_EVERY = 2.0
MUTEX_NAME = "Local\\AcademicHubSupervisor"   # "Local" = one per signed-in user
SERVICES = ("academic_hub.monitor", "academic_hub.dashboard_server")


def config_file() -> Path:
    return config.APP_DIR.parent / "config.json"


def load_settings() -> dict:
    try:
        return json.loads(config_file().read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}


def protected_here(settings: dict | None = None) -> bool:
    """True if the signed-in account is the one Quillio protects (empty = every account)."""
    settings = load_settings() if settings is None else settings
    user = str(settings.get("user", "")).strip()
    return not user or user.casefold() == getpass.getuser().casefold()


def _kernel32():
    import ctypes

    return ctypes.windll.kernel32


def supervisor_running() -> bool:
    """Is a supervisor already running for this account? (a named mutex tells us)"""
    if not IS_WIN:
        return False
    SYNCHRONIZE = 0x00100000
    handle = _kernel32().OpenMutexW(SYNCHRONIZE, False, MUTEX_NAME)
    if handle:
        _kernel32().CloseHandle(handle)
        return True
    return False


def _take_mutex():
    handle = _kernel32().CreateMutexW(None, False, MUTEX_NAME)
    if not handle or _kernel32().GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        return None
    return handle


def ensure_running() -> bool:
    """Start the supervisor in the background if this is the protected account and it is not running."""
    if not IS_WIN or not protected_here() or supervisor_running():
        return False
    subprocess.Popen(
        [sys.executable, "-m", "academic_hub.supervisor"],
        cwd=str(config.APP_DIR),
        env={**os.environ, "PYTHONPATH": str(config.APP_DIR)},
        close_fds=True,
        **config.detached_popen_kwargs(),
    )
    return True


class Supervisor:
    """Keeps one child process per service alive. `popen` and `clock` are replaceable for tests."""

    def __init__(self, env: dict, popen=subprocess.Popen, clock=time.time) -> None:
        self.env = env
        self.popen = popen
        self.clock = clock
        self.children: dict[str, object] = {}
        self.started_at: dict[str, float] = {}
        self.restarts = 0

    def _start(self, module: str) -> None:
        with open(config.log_dir() / f"{module.rsplit('.', 1)[-1]}.out.log", "ab") as log:
            self.children[module] = self.popen(
                [sys.executable, "-m", module], cwd=str(config.APP_DIR), env=self.env,
                stdout=log, stderr=log, **config.detached_popen_kwargs(),
            )
        self.started_at[module] = self.clock()

    def step(self) -> None:
        """Start any service that is not running (waiting RESTART_DELAY after the last start)."""
        for module in SERVICES:
            child = self.children.get(module)
            if child is not None and child.poll() is None:
                continue
            if child is not None and self.clock() - self.started_at[module] < RESTART_DELAY:
                continue
            if child is not None:
                self.restarts += 1
            self._start(module)

    def stop_all(self) -> None:
        for child in self.children.values():
            if child.poll() is None:
                child.terminate()


def main() -> int:
    if not IS_WIN:
        print("The supervisor is only used on Windows (macOS uses launchd).", file=sys.stderr)
        return 0
    settings = load_settings()
    if not protected_here(settings):
        return 0  # another account is signed in: nothing to guard
    mutex = _take_mutex()  # noqa: F841 - kept for the life of the process
    if mutex is None:
        return 0  # already running
    env = {**os.environ, "PYTHONPATH": str(config.APP_DIR), "ACADEMIC_HUB_PORT": str(settings.get("port", 8765))}
    sup = Supervisor(env)
    try:
        while True:
            sup.step()
            time.sleep(CHECK_EVERY)
    finally:
        sup.stop_all()


if __name__ == "__main__":
    sys.exit(main())
