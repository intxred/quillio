"""Windows versions of the operating-system helpers in macos.py.

Only used when sys.platform == "win32". Every function is import-safe elsewhere (psutil and ctypes.windll
are loaded lazily), so the unit tests can exercise them with fakes on any computer.
"""

from __future__ import annotations

import os
import sys

# Friendly names for programs a person would recognise. Anything else is shown by its file name.
FRIENDLY_NAMES = {
    "robloxplayerbeta.exe": "Roblox",
    "robloxstudiobeta.exe": "Roblox Studio",
}

_mine_cache: dict[int, bool] = {}   # pid -> started by the account this helper runs as


def _is_mine(proc) -> bool:
    """True if the process belongs to the account we run as (never touch another user's programs)."""
    pid = proc.pid
    if pid in _mine_cache:
        return _mine_cache[pid]
    try:
        import getpass

        owner = (proc.username() or "").split("\\")[-1].casefold()
        mine = owner == getpass.getuser().casefold()
    except Exception:
        mine = False
    _mine_cache[pid] = mine
    return mine


def running_apps(factory) -> list:
    """Every program started by this account. `factory` builds a macos.RunningApp."""
    import psutil

    apps = []
    alive = set()
    for proc in psutil.process_iter(["pid", "name"]):
        exe = (proc.info.get("name") or "").strip()
        if not exe:
            continue
        alive.add(proc.pid)
        if not _is_mine(proc):
            continue
        stem = exe[:-4] if exe.lower().endswith(".exe") else exe
        apps.append(
            factory(pid=int(proc.pid), name=FRIENDLY_NAMES.get(exe.lower(), stem), bundle_id=exe, _ref=proc)
        )
    for pid in [p for p in _mine_cache if p not in alive]:  # forget finished processes
        del _mine_cache[pid]
    return apps


def terminate(proc) -> None:
    """Close a program immediately (no 'save changes?' question can stall it)."""
    import psutil

    try:
        proc.kill()
    except psutil.NoSuchProcess:
        pass
    except psutil.AccessDenied:
        print(f"could not close process {getattr(proc, 'pid', '?')}: access denied", file=sys.stderr)


def installed_apps() -> list[dict]:
    """For the dashboard's picker: programs running right now (Windows has no simple list of installed apps)."""
    import psutil

    found: dict[str, dict] = {}
    windir = (os.environ.get("SystemRoot") or "C:\\Windows").casefold()
    for proc in psutil.process_iter(["name", "exe"]):
        exe = (proc.info.get("name") or "").strip()
        path = (proc.info.get("exe") or "").casefold()
        if not exe or not path or path.startswith(windir):
            continue
        stem = exe[:-4] if exe.lower().endswith(".exe") else exe
        found.setdefault(exe.lower(), {"name": FRIENDLY_NAMES.get(exe.lower(), stem), "bundle_id": exe})
    return sorted(found.values(), key=lambda a: a["name"].casefold())


# ------------------------------------------------------------------ keeping the exam on top

def _user32():
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    return user32, wintypes


def _visible_hwnds() -> list[int]:
    try:
        from PySide6.QtWidgets import QApplication

        return [int(w.winId()) for w in QApplication.topLevelWidgets() if w.isVisible()]
    except Exception:
        return []


def elevate_all_windows() -> bool:
    """Make every visible window of this process topmost (above the browser, the game and the taskbar)."""
    hwnds = _visible_hwnds()
    if not hwnds:
        return False
    user32, wintypes = _user32()
    HWND_TOPMOST = wintypes.HWND(-1)
    flags = 0x0001 | 0x0002 | 0x0040  # SWP_NOSIZE | SWP_NOMOVE | SWP_SHOWWINDOW
    for hwnd in hwnds:
        user32.SetWindowPos(wintypes.HWND(hwnd), HWND_TOPMOST, 0, 0, 0, 0, flags)
    return True


def activate_app() -> None:
    """Give the exam the keyboard focus. Windows refuses focus changes from a background program, but it
    allows one right after a key press, so a harmless Alt tap is sent first."""
    hwnds = _visible_hwnds()
    if not hwnds:
        return
    user32, wintypes = _user32()
    user32.keybd_event(0x12, 0, 0, 0)       # Alt down
    user32.keybd_event(0x12, 0, 0x0002, 0)  # Alt up
    for hwnd in hwnds:
        user32.BringWindowToTop(wintypes.HWND(hwnd))
        user32.SetForegroundWindow(wintypes.HWND(hwnd))


def describe_windows() -> str:
    return f"windows: {len(_visible_hwnds())} visible window(s)"
