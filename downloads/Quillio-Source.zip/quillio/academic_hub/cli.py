"""Command-line helper used by the installer and for maintenance.

    python -m academic_hub.cli init        create the database and seed the starter question bank
    python -m academic_hub.cli set-pin     set or change the admin PIN (prompts securely)
    python -m academic_hub.cli status      show settings, counts and recent attempts
"""

from __future__ import annotations

import argparse
import getpass
import sys

from . import config, db, security


def cmd_init(_args) -> int:
    conn = db.connect()
    db.init_db(conn)
    count = conn.execute("SELECT COUNT(*) AS n FROM questions").fetchone()["n"]
    print(f"Database ready at {config.db_path()} ({count} questions).")
    return 0


def cmd_set_pin(args) -> int:
    conn = db.connect()
    db.init_db(conn)
    pin = args.pin
    if pin is None:
        pin = getpass.getpass("New admin PIN (4-32 characters): ")
        if pin != getpass.getpass("Repeat the PIN: "):
            print("The PINs did not match.", file=sys.stderr)
            return 1
    try:
        security.set_pin(conn, pin)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    print("Admin PIN saved.")
    return 0


def cmd_status(_args) -> int:
    conn = db.connect()
    db.init_db(conn)
    print(f"Database : {config.db_path()}")
    print(f"PIN set  : {'yes' if security.pin_is_set(conn) else 'NO - run set-pin'}")
    print(f"Passing  : {db.get_int(conn, 'passing_score', 70)}/100")
    print(f"Exam size: {db.get_int(conn, 'questions_per_quiz', 10)} questions")
    for row in conn.execute("SELECT name, bundle_id, enabled FROM restricted_apps ORDER BY name"):
        print(f"Restrict : {row['name']} ({row['bundle_id'] or 'name match'}) {'on' if row['enabled'] else 'off'}")
    print("Recent attempts:")
    for row in conn.execute(
        "SELECT kind, target_name, score, passed, started_at FROM attempts ORDER BY id DESC LIMIT 5"
    ):
        when = __import__("time").strftime("%Y-%m-%d %H:%M", __import__("time").localtime(row["started_at"]))
        print(f"  {when}  {row['kind']:<15} {row['target_name']:<12} score={row['score']} passed={bool(row['passed'])}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="academic_hub.cli")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init").set_defaults(func=cmd_init)
    pin = sub.add_parser("set-pin")
    pin.add_argument("--pin", help="non-interactive (used by tests)")
    pin.set_defaults(func=cmd_set_pin)
    sub.add_parser("status").set_defaults(func=cmd_status)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
