"""Admin PIN hashing and brute-force lockout.

The PIN protects the dashboard and the quiz screen's "Parent / admin access"
button. It is stored only as a salted PBKDF2 hash in the SQLite settings table.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import sqlite3

from . import db

ITERATIONS = 200_000
MIN_PIN_LENGTH = 4
MAX_PIN_LENGTH = 32
MAX_FAILURES = 5
LOCK_SECONDS = 300


def hash_pin(pin: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_pin_hash(pin: str, stored: str) -> bool:
    try:
        scheme, iterations, salt_hex, digest_hex = stored.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", pin.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations)
        )
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def validate_pin_format(pin: str) -> str | None:
    """Return an error message, or None if the PIN is acceptable."""
    if not isinstance(pin, str) or not (MIN_PIN_LENGTH <= len(pin) <= MAX_PIN_LENGTH):
        return f"The PIN must be {MIN_PIN_LENGTH} to {MAX_PIN_LENGTH} characters long."
    if pin.strip() != pin or not pin:
        return "The PIN cannot start or end with a space."
    return None


def pin_is_set(conn: sqlite3.Connection) -> bool:
    return bool(db.get_setting(conn, "admin_pin_hash"))


def set_pin(conn: sqlite3.Connection, pin: str) -> None:
    error = validate_pin_format(pin)
    if error:
        raise ValueError(error)
    db.set_setting(conn, "admin_pin_hash", hash_pin(pin))
    db.set_setting(conn, "pin_failures", 0)
    db.set_setting(conn, "pin_locked_until", 0)


def lock_remaining(conn: sqlite3.Connection) -> int:
    return max(0, db.get_int(conn, "pin_locked_until") - db.now())


def check_pin(conn: sqlite3.Connection, pin: str) -> tuple[bool, str]:
    """Verify a PIN attempt. Returns (ok, message). Applies lockout after repeated failures."""
    if not pin_is_set(conn):
        return False, "No admin PIN has been set yet. Open the dashboard (http://127.0.0.1:8765) to create one."
    remaining = lock_remaining(conn)
    if remaining:
        return False, f"Too many wrong attempts. Try again in {remaining // 60 + 1} minute(s)."
    if verify_pin_hash(pin or "", db.get_setting(conn, "admin_pin_hash")):
        db.set_setting(conn, "pin_failures", 0)
        return True, "ok"
    failures = db.get_int(conn, "pin_failures") + 1
    if failures >= MAX_FAILURES:
        db.set_setting(conn, "pin_failures", 0)
        db.set_setting(conn, "pin_locked_until", db.now() + LOCK_SECONDS)
        return False, "Too many wrong attempts. Locked for 5 minutes."
    db.set_setting(conn, "pin_failures", failures)
    return False, f"Wrong PIN. {MAX_FAILURES - failures} attempt(s) left."
