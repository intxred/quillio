"""Question validation plus JSON/CSV import and export of the whole quiz bank."""

from __future__ import annotations

import csv
import io
import json
import sqlite3
import time

from . import db

MAX_CHOICES = 6
MAX_SUBJECTS = 200
MAX_QUESTIONS = 20_000
LETTERS = "abcdef"
CSV_FIELDS = (
    ["subject", "question"]
    + [f"choice_{c}" for c in LETTERS]
    + ["correct", "explanation", "active"]
)


def clean_question(data: dict) -> dict:
    """Validate and normalise one question. Raises ValueError with a readable message."""
    text = str(data.get("text", "")).strip()
    if not text:
        raise ValueError("The question text cannot be empty.")
    if len(text) > 1000:
        raise ValueError("The question text is too long (1000 characters max).")
    raw_choices = data.get("choices")
    if not isinstance(raw_choices, list):
        raise ValueError("Choices must be a list.")
    choices = [str(c).strip() for c in raw_choices]
    if not 2 <= len(choices) <= MAX_CHOICES:
        raise ValueError(f"A question needs 2 to {MAX_CHOICES} answer choices.")
    if any(not c for c in choices):
        raise ValueError("Answer choices cannot be blank.")
    if any(len(c) > 300 for c in choices):
        raise ValueError("An answer choice is too long (300 characters max).")
    if len({c.casefold() for c in choices}) != len(choices):
        raise ValueError("Answer choices must all be different.")
    try:
        correct = int(data.get("correct_index"))
    except (TypeError, ValueError):
        raise ValueError("Choose which answer is correct.") from None
    if not 0 <= correct < len(choices):
        raise ValueError("The correct answer must be one of the choices.")
    explanation = str(data.get("explanation", "") or "").strip()
    if len(explanation) > 1000:
        raise ValueError("The explanation is too long (1000 characters max).")
    return {
        "text": text,
        "choices": choices,
        "correct_index": correct,
        "explanation": explanation,
        "active": bool(data.get("active", True)),
    }


# ------------------------------------------------------------------ export

def export_bank(conn: sqlite3.Connection) -> dict:
    subjects = []
    for s in conn.execute("SELECT * FROM subjects ORDER BY position, id"):
        questions = [
            {
                "text": q["text"],
                "choices": json.loads(q["choices"]),
                "correct_index": q["correct_index"],
                "explanation": q["explanation"],
                "active": bool(q["active"]),
            }
            for q in conn.execute("SELECT * FROM questions WHERE subject_id = ? ORDER BY id", (s["id"],))
        ]
        subjects.append(
            {"name": s["name"], "icon": s["icon"], "enabled": bool(s["enabled"]), "questions": questions}
        )
    return {
        "app": "academic-hub",
        "version": 1,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "subjects": subjects,
    }


def bank_to_csv(bank: dict) -> str:
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=CSV_FIELDS)
    writer.writeheader()
    for subject in bank["subjects"]:
        for q in subject["questions"]:
            row = {"subject": subject["name"], "question": q["text"]}
            for i, letter in enumerate(LETTERS):
                row[f"choice_{letter}"] = q["choices"][i] if i < len(q["choices"]) else ""
            row["correct"] = LETTERS[q["correct_index"]].upper()
            row["explanation"] = q["explanation"]
            row["active"] = "1" if q["active"] else "0"
            writer.writerow(row)
    return out.getvalue()


# ------------------------------------------------------------------ import

def parse_csv(text: str) -> dict:
    """Turn CSV text into the same structure as the JSON export."""
    text = text.lstrip("﻿")
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise ValueError("The CSV file is empty.")
    fields = {(name or "").strip().lower(): name for name in reader.fieldnames}
    for needed in ("subject", "question", "correct"):
        if needed not in fields:
            raise ValueError(f"The CSV is missing the '{needed}' column.")

    def cell(row: dict, name: str) -> str:
        key = fields.get(name)
        return (row.get(key) or "").strip() if key else ""

    subjects: dict[str, dict] = {}
    for line_no, row in enumerate(reader, start=2):
        if not any((v or "").strip() for v in row.values() if isinstance(v, str)):
            continue
        subject_name = cell(row, "subject")
        if not subject_name:
            raise ValueError(f"CSV line {line_no}: the subject is empty.")
        columns = []
        for letter in LETTERS:
            value = cell(row, f"choice_{letter}") or cell(row, letter)
            columns.append(value)
        correct_raw = cell(row, "correct").lower()
        if correct_raw in LETTERS:
            correct_col = LETTERS.index(correct_raw)
        elif correct_raw.isdigit() and 1 <= int(correct_raw) <= MAX_CHOICES:
            correct_col = int(correct_raw) - 1
        else:
            raise ValueError(f"CSV line {line_no}: 'correct' must be a letter A-F or a number 1-6.")
        if not columns[correct_col]:
            raise ValueError(f"CSV line {line_no}: the correct answer column is blank.")
        kept = [(i, c) for i, c in enumerate(columns) if c]
        choices = [c for _, c in kept]
        correct_index = [i for i, _ in kept].index(correct_col)
        active_raw = cell(row, "active").lower()
        entry = subjects.setdefault(subject_name, {"name": subject_name, "questions": []})
        entry["questions"].append(
            {
                "text": cell(row, "question"),
                "choices": choices,
                "correct_index": correct_index,
                "explanation": cell(row, "explanation"),
                "active": active_raw not in ("0", "false", "no", "off"),
            }
        )
    return {"subjects": list(subjects.values())}


def parse_payload(fmt: str, content: str) -> dict:
    if fmt == "csv":
        return parse_csv(content)
    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"That is not valid JSON: {exc.msg} (line {exc.lineno}).") from None
    if isinstance(data, list):  # allow a bare list of subjects
        data = {"subjects": data}
    return data


def validate_payload(payload: dict) -> list[dict]:
    """Return a cleaned list of subjects, or raise ValueError describing the first problem."""
    subjects = payload.get("subjects") if isinstance(payload, dict) else None
    if not isinstance(subjects, list) or not subjects:
        raise ValueError("No subjects were found in the file.")
    if len(subjects) > MAX_SUBJECTS:
        raise ValueError(f"Too many subjects (maximum {MAX_SUBJECTS}).")
    cleaned: list[dict] = []
    total_questions = 0
    for s in subjects:
        name = str(s.get("name", "")).strip() if isinstance(s, dict) else ""
        if not name or len(name) > 60:
            raise ValueError("Every subject needs a name of 1 to 60 characters.")
        icon = str(s.get("icon") or "📘").strip()[:8] or "📘"
        questions = []
        for n, q in enumerate(s.get("questions") or [], start=1):
            try:
                questions.append(clean_question(q if isinstance(q, dict) else {}))
            except ValueError as exc:
                raise ValueError(f"Subject '{name}', question {n}: {exc}") from None
        total_questions += len(questions)
        if total_questions > MAX_QUESTIONS:
            raise ValueError(f"Too many questions (maximum {MAX_QUESTIONS}).")
        cleaned.append(
            {"name": name, "icon": icon, "enabled": bool(s.get("enabled", True)), "questions": questions}
        )
    return cleaned


def import_bank(conn: sqlite3.Connection, payload: dict, mode: str = "merge") -> dict:
    """Import validated data. mode='merge' adds missing items; mode='replace' wipes the bank first."""
    if mode not in ("merge", "replace"):
        raise ValueError("Import mode must be 'merge' or 'replace'.")
    subjects = validate_payload(payload)
    now = db.now()
    stats = {"subjects_added": 0, "questions_added": 0, "questions_skipped": 0}
    conn.execute("BEGIN IMMEDIATE")
    try:
        if mode == "replace":
            conn.execute("DELETE FROM questions")
            conn.execute("DELETE FROM subjects")
        for s in subjects:
            row = conn.execute("SELECT id FROM subjects WHERE name = ?", (s["name"],)).fetchone()
            if row is None:
                position = conn.execute("SELECT COALESCE(MAX(position), -1) + 1 AS p FROM subjects").fetchone()["p"]
                cur = conn.execute(
                    "INSERT INTO subjects(name, icon, position, enabled) VALUES (?, ?, ?, ?)",
                    (s["name"], s["icon"], position, 1 if s["enabled"] else 0),
                )
                subject_id = cur.lastrowid
                stats["subjects_added"] += 1
            else:
                subject_id = row["id"]
            for q in s["questions"]:
                if conn.execute(
                    "SELECT 1 FROM questions WHERE subject_id = ? AND text = ?", (subject_id, q["text"])
                ).fetchone():
                    stats["questions_skipped"] += 1
                    continue
                conn.execute(
                    "INSERT INTO questions(subject_id, text, choices, correct_index, explanation, active, "
                    "created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        subject_id,
                        q["text"],
                        json.dumps(q["choices"], ensure_ascii=False),
                        q["correct_index"],
                        q["explanation"],
                        1 if q["active"] else 0,
                        now,
                        now,
                    ),
                )
                stats["questions_added"] += 1
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    return stats
