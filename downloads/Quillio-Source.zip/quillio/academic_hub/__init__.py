"""Quillio - local, customizable quiz and assessment app (with an optional app gate)."""

__version__ = "1.0.0"
