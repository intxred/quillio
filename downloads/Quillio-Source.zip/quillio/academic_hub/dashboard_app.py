"""The dashboard in its own app window instead of a browser tab.

    python -m academic_hub.dashboard_app            open the window
    python -m academic_hub.dashboard_app --browser  open it in the default browser instead

The dashboard server keeps running in the background (LaunchAgent on macOS, the supervisor on
Windows); this window only shows it. It uses Qt WebEngine (PySide6-Addons). If that is missing,
or the window cannot start, the page opens in the normal browser so the dashboard is never out of reach.
"""

from __future__ import annotations

import os
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

from . import config

URL = config.DASHBOARD_URL
LOADING_HTML = """<html><body style="font-family:-apple-system,Segoe UI,sans-serif;background:#FBF9F4;color:#171715;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><div style="text-align:center">
<div style="font-size:54px">&#129428;</div><h2>Starting Quillio&hellip;</h2>
<p style="color:#6b6b66">This takes a few seconds.</p></div></body></html>"""
ERROR_HTML = """<html><body style="font-family:-apple-system,Segoe UI,sans-serif;background:#FBF9F4;color:#171715;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><div style="text-align:center;max-width:520px">
<div style="font-size:54px">&#129428;</div><h2>The dashboard is not running</h2>
<p style="color:#6b6b66">Quillio could not reach its dashboard. Sign out and in again, or restart the computer,
then open Quillio again. If it keeps happening, check the log files in the Quillio logs folder.</p></div></body></html>"""


def server_is_up(timeout: float = 1.0) -> bool:
    try:
        with urllib.request.urlopen(URL + "/", timeout=timeout):
            return True
    except urllib.error.HTTPError:
        return True  # it answered, even if with an error page
    except (urllib.error.URLError, OSError):
        return False


def open_in_browser() -> None:
    webbrowser.open(URL)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--browser" in argv:
        open_in_browser()
        return 0
    screenshot = argv[argv.index("--screenshot") + 1] if "--screenshot" in argv else None

    if sys.platform == "darwin":
        # A dashboard does not need the graphics chip. On some Macs the GPU process left the window blank.
        flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
        if "--disable-gpu" not in flags:
            os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (flags + " --disable-gpu").strip()

    try:
        from PySide6.QtCore import QLockFile, QTimer, QUrl
        from PySide6.QtGui import QDesktopServices, QIcon
        from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox
    except ImportError as exc:  # WebEngine not installed: fall back to the browser
        print("Qt WebEngine is not available, using the browser:", exc, file=sys.stderr)
        open_in_browser()
        return 0

    from . import supervisor

    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("Quillio")
    icon_file = config.STATIC_DIR / "app-icon.png"
    if icon_file.exists():
        app.setWindowIcon(QIcon(str(icon_file)))

    lock = QLockFile(str(Path(os.environ.get("TMPDIR") or os.environ.get("TEMP") or "/tmp") / "academic-hub-window.lock"))
    lock.setStaleLockTime(5000)
    if not lock.tryLock(100):
        print("The Quillio window is already open.", file=sys.stderr)
        return 0

    supervisor.ensure_running()  # Windows: starts the background helpers if they are not running; no-op elsewhere

    class Page(QWebEnginePage):
        def acceptNavigationRequest(self, url, nav_type, is_main_frame):  # noqa: N802 (Qt name)
            if url.scheme() in ("http", "https") and url.host() not in ("127.0.0.1", "localhost"):
                QDesktopServices.openUrl(url)  # links to other websites open in the normal browser
                return False
            return super().acceptNavigationRequest(url, nav_type, is_main_frame)

    class Window(QMainWindow):
        def __init__(self) -> None:
            super().__init__()
            self.setWindowTitle("Quillio")
            self.resize(1280, 860)
            self.setMinimumSize(900, 600)
            self.view = QWebEngineView(self)
            self.page = Page(QWebEngineProfile.defaultProfile(), self.view)
            self.view.setPage(self.page)
            self.setCentralWidget(self.view)
            self.view.setHtml(LOADING_HTML)
            self.tries = 0
            self.real_load = False   # True once the real dashboard (not the "starting" page) is being loaded
            self.fell_back = False
            self.view.loadFinished.connect(self.on_load_finished)
            self.page.renderProcessTerminated.connect(self.on_render_terminated)
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.try_load)
            self.timer.start(700)
            QWebEngineProfile.defaultProfile().downloadRequested.connect(self.on_download)

        def try_load(self) -> None:
            self.tries += 1
            if server_is_up():
                self.timer.stop()
                self.real_load = True
                self.view.load(QUrl(URL))
            elif self.tries >= 45:  # about 30 seconds
                self.timer.stop()
                self.view.setHtml(ERROR_HTML)

        def fall_back(self, reason: str) -> None:
            """The window is blank or broken: show the dashboard in the normal browser instead."""
            if self.fell_back or screenshot:
                return
            self.fell_back = True
            print("The app window is not showing the dashboard (" + reason + "); using the browser.", file=sys.stderr)
            open_in_browser()
            QTimer.singleShot(0, self.close)

        def on_load_finished(self, ok: bool) -> None:
            if not self.real_load:
                return
            if not ok:
                self.fall_back("the page did not load")
                return
            QTimer.singleShot(4000, self.check_not_blank)

        def check_not_blank(self) -> None:
            if self.fell_back:
                return
            self.page.runJavaScript(
                "(document.body && document.body.innerText || '').trim().length",
                lambda n: self.fall_back("the page is blank") if not n else None)

        def on_render_terminated(self, status, code) -> None:
            self.fall_back("the page process stopped")

        def on_download(self, download) -> None:  # "Export" buttons in the dashboard
            start = str(Path.home() / "Downloads" / download.downloadFileName())
            path, _ = QFileDialog.getSaveFileName(self, "Save file", start)
            if not path:
                download.cancel()
                return
            target = Path(path)
            download.setDownloadDirectory(str(target.parent))
            download.setDownloadFileName(target.name)
            download.accept()

    try:
        window = Window()
        window.show()
        window.raise_()
        window.activateWindow()
    except Exception as exc:  # pragma: no cover - never leave the person without a dashboard
        print("Could not open the app window, using the browser:", exc, file=sys.stderr)
        open_in_browser()
        return 0

    if screenshot:  # used by the build checks: save a picture once the page has loaded, then quit
        def shoot() -> None:
            window.grab().save(screenshot)
            app.quit()
        window.view.loadFinished.connect(lambda ok: QTimer.singleShot(2500, shoot))
        QTimer.singleShot(40000, app.quit)
    code = app.exec()
    lock.unlock()
    return code


if __name__ == "__main__":
    sys.exit(main())
