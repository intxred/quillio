"""SQLite schema, settings helpers and first-run seeding."""

from __future__ import annotations

import json
import sqlite3
import sys
import time
from pathlib import Path

from . import config

SCHEMA_VERSION = 2

SCHEMA = """
CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  icon TEXT NOT NULL DEFAULT '📘',
  position INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  choices TEXT NOT NULL,              -- JSON array of 2-6 strings
  correct_index INTEGER NOT NULL,
  explanation TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_questions_subject ON questions(subject_id);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS restricted_apps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,                 -- matched case-insensitively as a name prefix
  bundle_id TEXT NOT NULL DEFAULT '', -- matched exactly when set
  enabled INTEGER NOT NULL DEFAULT 1,
  questions_per_quiz INTEGER,         -- per-app exam rules; NULL = use the Settings default
  passing_score INTEGER,
  unlock_minutes INTEGER,
  exams_required INTEGER,             -- exams that must be passed in a row (default 1)
  subject_ids TEXT,                   -- JSON array of subject ids; NULL = every enabled subject
  UNIQUE (name, bundle_id)
);

CREATE TABLE IF NOT EXISTS attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'quiz',  -- quiz | admin_override
  target_name TEXT NOT NULL DEFAULT '',
  target_bundle_id TEXT NOT NULL DEFAULT '',
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  total INTEGER NOT NULL DEFAULT 0,
  correct INTEGER NOT NULL DEFAULT 0,
  score INTEGER NOT NULL DEFAULT 0,
  passing_score INTEGER NOT NULL DEFAULT 70,
  passed INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS attempt_answers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attempt_id INTEGER NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,
  question_id INTEGER,                -- no FK: history survives question deletion
  subject_id INTEGER,
  subject_name TEXT NOT NULL,
  question_text TEXT NOT NULL,
  chosen_text TEXT NOT NULL,
  correct_text TEXT NOT NULL,
  is_correct INTEGER NOT NULL,
  answered_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_answers_attempt ON attempt_answers(attempt_id);
CREATE INDEX IF NOT EXISTS idx_answers_question ON attempt_answers(question_id);

CREATE TABLE IF NOT EXISTS unlocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bundle_id TEXT NOT NULL,
  app_name TEXT NOT NULL DEFAULT '',
  granted_at INTEGER NOT NULL,
  expires_at INTEGER,                 -- NULL = valid until the app is closed
  reason TEXT NOT NULL DEFAULT 'passed',
  attempt_id INTEGER,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_unlocks_bundle ON unlocks(bundle_id, active);
"""

DEFAULT_SETTINGS = {
    "passing_score": "70",          # percent, 1-100
    "questions_per_quiz": "10",     # total questions in one exam, spread across the subjects
    "unlock_minutes": "0",          # 0 = unlocked until the app is closed
    "exam_on_top": "0",             # 1 = when a pass is needed, show the exam over the running app instead
                                    # of closing it first (closed only if the exam is left without a pass)
    "cover_delay_seconds": "5",     # exam-on-top mode: seconds between the app opening and the exam appearing
    "admin_unlock_minutes": "30",   # length of a parent/admin override
    "reopen_grace_seconds": "180",  # after a pass (or after the app closes) the app can start again
                                    # without a new exam for this long
    "shuffle_choices": "1",
    "guard_enabled": "1",           # master switch: 0 pauses all app blocking
    "admin_pin_hash": "",           # empty until setup sets the PIN
    "pin_failures": "0",
    "pin_locked_until": "0",
}

# Texts shown on the exam's first screen. {app} is replaced with the app's name.
DEFAULT_TEXT_SETTINGS = {
    "learner_name": "",             # shown in the dashboard greeting; empty = no name
    "intro_title": "Quiz time! Pass to open {app}.",
    "intro_message": (
        "Pick the best answer for each question. You will see right away whether you were right "
        "and why. There is no timer, so take your time."
    ),
}
TEXT_SETTING_LIMITS = {"learner_name": 40, "intro_title": 120, "intro_message": 400}

# The starter rule guards Roblox. Add or remove apps in the dashboard (App Lock).
# Everything not on the list stays free to use.
# On Windows the "bundle id" column holds the program's file name.
if sys.platform == "win32":
    DEFAULT_RESTRICTED_APPS = [
        ("Roblox", "RobloxPlayerBeta.exe"),
        ("Roblox Studio", "RobloxStudioBeta.exe"),
    ]
else:
    DEFAULT_RESTRICTED_APPS = [
        ("Roblox", "com.roblox.RobloxPlayer"),
        ("Roblox Studio", "com.roblox.RobloxStudio"),
    ]


def now() -> int:
    return int(time.time())


def connect(path: str | Path | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or config.db_path()), timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 8000")
    try:
        conn.execute("PRAGMA journal_mode = WAL")
    except sqlite3.DatabaseError:
        pass
    return conn


def init_db(conn: sqlite3.Connection, seed: bool = True) -> None:
    """Create tables, default settings/apps and (once) the Grade 5 question bank."""
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    for key, value in {**DEFAULT_SETTINGS, **DEFAULT_TEXT_SETTINGS}.items():
        conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (key, value))
    if conn.execute("SELECT value FROM settings WHERE key='apps_seeded'").fetchone() is None:
        for name, bundle in DEFAULT_RESTRICTED_APPS:
            conn.execute(
                "INSERT OR IGNORE INTO restricted_apps(name, bundle_id) VALUES (?, ?)",
                (name, bundle),
            )
        conn.execute("INSERT INTO settings(key, value) VALUES ('apps_seeded', '1')")
    # One-time: older installs also guarded Safari. Switch that default rule off (not deleted, so a
    # parent can tick it on again in the dashboard). Runs once, so a later choice is never undone.
    if conn.execute("SELECT value FROM settings WHERE key='roblox_only_v1'").fetchone() is None:
        conn.execute(
            "UPDATE restricted_apps SET enabled = 0 WHERE name = 'Safari' AND bundle_id = 'com.apple.Safari'"
        )
        conn.execute("INSERT INTO settings(key, value) VALUES ('roblox_only_v1', '1')")
    if seed and conn.execute("SELECT value FROM settings WHERE key='bank_seeded'").fetchone() is None:
        from .seed_data import seed_defaults

        seed_defaults(conn)
        conn.execute("INSERT INTO settings(key, value) VALUES ('bank_seeded', '1')")


def _migrate(conn: sqlite3.Connection) -> None:
    """Add the per-app rule columns to a database created by an older version."""
    have = {row["name"] for row in conn.execute("PRAGMA table_info(restricted_apps)")}
    for column, kind in (
        ("questions_per_quiz", "INTEGER"),
        ("passing_score", "INTEGER"),
        ("unlock_minutes", "INTEGER"),
        ("exams_required", "INTEGER"),
        ("subject_ids", "TEXT"),
    ):
        if column not in have:
            conn.execute(f"ALTER TABLE restricted_apps ADD COLUMN {column} {kind}")


# ---------------------------------------------------------------- settings

def get_setting(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def get_int(conn: sqlite3.Connection, key: str, default: int = 0) -> int:
    try:
        return int(get_setting(conn, key, str(default)))
    except ValueError:
        return default


def set_setting(conn: sqlite3.Connection, key: str, value) -> None:
    conn.execute(
        "INSERT INTO settings(key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )


# ---------------------------------------------------------------- helpers

def question_row_to_dict(row: sqlite3.Row, include_answer: bool = True) -> dict:
    data = {
        "id": row["id"],
        "subject_id": row["subject_id"],
        "text": row["text"],
        "choices": json.loads(row["choices"]),
        "active": bool(row["active"]),
    }
    if include_answer:
        data["correct_index"] = row["correct_index"]
        data["explanation"] = row["explanation"]
    return data
