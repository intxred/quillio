"""Which restricted-app rule applies to a running app, and the exam rules that rule sets.

Every rule can override the global defaults (Settings page) for its own app:
questions per exam, passing score, how long a pass lasts, how many exams in a row are needed,
and which subjects the exam draws from. A NULL column means "use the default".
"""

from __future__ import annotations

import json
import sqlite3

from . import db

MIN_NAME_LENGTH = 4  # name-prefix rules shorter than this are ignored

# Columns a rule may override, with the global setting each one falls back to and its allowed range.
OVERRIDES = {
    "questions_per_quiz": ("questions_per_quiz", 10, (1, 100)),
    "passing_score": ("passing_score", 70, (1, 100)),
    "unlock_minutes": ("unlock_minutes", 0, (0, 1440)),
    "exams_required": (None, 1, (1, 5)),
}


def find_rule(rules, name: str, bundle_id: str):
    """Return the restricted-app rule that matches a running app, else None.

    A rule matches when its bundle id equals the app's (checked first, over all rules), or when
    the app's display name starts with the rule's name (case-insensitive; the longest name wins),
    so "Roblox" also covers "Roblox Studio" unless Studio has a rule of its own.
    """
    app_name = (name or "").strip().casefold()
    bundle = (bundle_id or "").strip().casefold()
    if bundle:
        for rule in rules:
            if (rule["bundle_id"] or "").strip().casefold() == bundle:
                return rule
    best = None
    best_len = 0
    for rule in rules:
        rule_name = (rule["name"] or "").strip().casefold()
        if len(rule_name) >= MIN_NAME_LENGTH and app_name.startswith(rule_name) and len(rule_name) > best_len:
            best, best_len = rule, len(rule_name)
    return best


def _subject_ids(raw) -> list[int] | None:
    if not raw:
        return None
    try:
        ids = [int(x) for x in json.loads(raw)]
    except (ValueError, TypeError):
        return None
    return ids or None


def defaults(conn: sqlite3.Connection) -> dict:
    """The exam rules used for an app that has no overrides."""
    return {
        "questions_per_quiz": max(1, db.get_int(conn, "questions_per_quiz", 10)),
        "passing_score": db.get_int(conn, "passing_score", 70),
        "unlock_minutes": db.get_int(conn, "unlock_minutes", 0),
        "exams_required": 1,
        "subject_ids": None,
    }


def effective(conn: sqlite3.Connection, rule) -> dict:
    """Exam rules for one app: the rule's own values, falling back to the global defaults."""
    out = defaults(conn)
    if rule is None:
        return out
    keys = rule.keys()
    for column in OVERRIDES:
        if column in keys and rule[column] is not None:
            out[column] = int(rule[column])
    if "subject_ids" in keys:
        out["subject_ids"] = _subject_ids(rule["subject_ids"])
    return out


def for_app(conn: sqlite3.Connection, name: str, bundle_id: str) -> dict:
    """Effective exam rules for a running app (defaults when no rule matches, e.g. in preview)."""
    rows = conn.execute("SELECT * FROM restricted_apps").fetchall()
    return effective(conn, find_rule(rows, name, bundle_id))
