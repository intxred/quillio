"""Quiz sessions, grading, attempt tracking and application unlock grants.

No GUI code lives here so the logic can be unit-tested anywhere.
"""

from __future__ import annotations

import json
import random
import sqlite3
from typing import Optional

from . import db, rules as rules_mod


class NoQuestionsError(RuntimeError):
    """Raised when no enabled subject has an active question."""


# ------------------------------------------------------------------ sessions

def quiz_size_setting(conn: sqlite3.Connection, rules: Optional[dict] = None) -> int:
    if rules is not None:
        return max(1, int(rules["questions_per_quiz"]))
    return max(1, db.get_int(conn, "questions_per_quiz", 10))


def available_questions(conn: sqlite3.Connection, subject_ids: Optional[list[int]] = None) -> int:
    """Active questions in subjects that are switched on (limited to `subject_ids` when given)."""
    sql = (
        "SELECT COUNT(*) AS n FROM questions q JOIN subjects s ON s.id = q.subject_id "
        "WHERE q.active = 1 AND s.enabled = 1"
    )
    args: list = []
    if subject_ids:
        sql += " AND s.id IN (%s)" % ",".join("?" * len(subject_ids))
        args = list(subject_ids)
    return conn.execute(sql, args).fetchone()["n"]


def session_size(conn: sqlite3.Connection, rules: Optional[dict] = None) -> int:
    """How many questions the next exam will have (the setting, or fewer if the bank is small)."""
    ids = rules["subject_ids"] if rules else None
    return min(quiz_size_setting(conn, rules), available_questions(conn, ids))


def build_session(
    conn: sqlite3.Connection, rng: Optional[random.Random] = None, rules: Optional[dict] = None
) -> list[dict]:
    """Pick `questions_per_quiz` questions, spread as evenly as possible over the enabled subjects.

    Each round gives one question to every subject that still has some (subjects in random order,
    so with 10 questions and 8 subjects a different pair of subjects gets a second question each
    time). Within a subject, questions the learner has seen least are preferred (ties broken
    randomly), so repeated attempts rotate through the bank. Choices are shuffled per question.
    The exam is shown in subject order.
    """
    rng = rng or random.Random()
    wanted = quiz_size_setting(conn, rules)
    only_subjects = set(rules["subject_ids"]) if rules and rules.get("subject_ids") else None
    shuffle_choices = db.get_int(conn, "shuffle_choices", 1) == 1

    seen = {
        row["question_id"]: row["n"]
        for row in conn.execute(
            "SELECT question_id, COUNT(*) AS n FROM attempt_answers "
            "WHERE question_id IS NOT NULL GROUP BY question_id"
        )
    }

    subjects = conn.execute(
        "SELECT * FROM subjects WHERE enabled = 1 ORDER BY position, id"
    ).fetchall()
    pools: list[tuple[sqlite3.Row, list[sqlite3.Row]]] = []
    for subject in subjects:
        if only_subjects is not None and subject["id"] not in only_subjects:
            continue
        rows = conn.execute(
            "SELECT * FROM questions WHERE subject_id = ? AND active = 1", (subject["id"],)
        ).fetchall()
        if rows:
            rows = sorted(rows, key=lambda r: (seen.get(r["id"], 0), rng.random()))
            pools.append((subject, rows))

    picked: list[tuple[int, sqlite3.Row, sqlite3.Row]] = []  # (subject order, subject, question)
    taken = [0] * len(pools)
    while len(picked) < wanted and any(taken[i] < len(pools[i][1]) for i in range(len(pools))):
        order = list(range(len(pools)))
        rng.shuffle(order)
        for i in order:
            if len(picked) >= wanted:
                break
            if taken[i] < len(pools[i][1]):
                picked.append((i, pools[i][0], pools[i][1][taken[i]]))
                taken[i] += 1
    picked.sort(key=lambda item: item[0])  # keep subjects grouped; within one subject the order is kept

    session: list[dict] = []
    for _, subject, row in picked:
        choices = json.loads(row["choices"])
        order = list(range(len(choices)))
        if shuffle_choices:
            rng.shuffle(order)
        session.append(
            {
                "question_id": row["id"],
                "subject_id": subject["id"],
                "subject_name": subject["name"],
                "subject_icon": subject["icon"],
                "text": row["text"],
                "choices": [choices[i] for i in order],
                "correct_index": order.index(row["correct_index"]),
                "explanation": row["explanation"],
            }
        )
    if not session:
        raise NoQuestionsError(
            "There are no active questions. Add questions in the dashboard (http://127.0.0.1:8765)."
        )
    return session


# ------------------------------------------------------------------ attempts

def start_attempt(
    conn: sqlite3.Connection,
    target_name: str = "",
    target_bundle_id: str = "",
    passing_score: Optional[int] = None,
) -> int:
    if passing_score is None:
        passing_score = db.get_int(conn, "passing_score", 70)
    cur = conn.execute(
        "INSERT INTO attempts(kind, target_name, target_bundle_id, started_at, passing_score) "
        "VALUES ('quiz', ?, ?, ?, ?)",
        (target_name, target_bundle_id, db.now(), passing_score),
    )
    return int(cur.lastrowid)


def record_answer(conn: sqlite3.Connection, attempt_id: int, question: dict, chosen_index: int) -> bool:
    correct = chosen_index == question["correct_index"]
    conn.execute(
        "INSERT INTO attempt_answers(attempt_id, question_id, subject_id, subject_name, "
        "question_text, chosen_text, correct_text, is_correct, answered_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            attempt_id,
            question["question_id"],
            question["subject_id"],
            question["subject_name"],
            question["text"],
            question["choices"][chosen_index],
            question["choices"][question["correct_index"]],
            1 if correct else 0,
            db.now(),
        ),
    )
    return correct


def finish_attempt(conn: sqlite3.Connection, attempt_id: int, total_questions: int) -> dict:
    """Close the attempt and return its result.

    The score is a whole percent rounded *down*, so 69.5% never displays as a pass.
    """
    rows = conn.execute(
        "SELECT subject_name, is_correct FROM attempt_answers WHERE attempt_id = ?", (attempt_id,)
    ).fetchall()
    correct = sum(r["is_correct"] for r in rows)
    total = max(total_questions, 1)
    score = (correct * 100) // total
    passing = db.get_int(conn, "passing_score", 70)
    # The passing mark stored with the attempt is the one that applied when it started.
    started_with = conn.execute(
        "SELECT passing_score FROM attempts WHERE id = ?", (attempt_id,)
    ).fetchone()
    if started_with:
        passing = started_with["passing_score"]
    passed = score >= passing
    conn.execute(
        "UPDATE attempts SET finished_at = ?, total = ?, correct = ?, score = ?, passed = ? WHERE id = ?",
        (db.now(), total_questions, correct, score, 1 if passed else 0, attempt_id),
    )
    by_subject: dict[str, dict] = {}
    for r in rows:
        entry = by_subject.setdefault(r["subject_name"], {"correct": 0, "total": 0})
        entry["total"] += 1
        entry["correct"] += r["is_correct"]
    return {
        "attempt_id": attempt_id,
        "total": total_questions,
        "correct": correct,
        "score": score,
        "passing_score": passing,
        "passed": passed,
        "by_subject": by_subject,
    }


# ------------------------------------------------------------------ unlocks

def grant_unlock(
    conn: sqlite3.Connection,
    bundle_id: str,
    app_name: str = "",
    attempt_id: Optional[int] = None,
    reason: str = "passed",
    minutes: Optional[int] = None,
) -> int:
    """Unlock an app. `minutes` (the app's own rule) overrides the global length for a normal pass."""
    if reason == "admin_override":
        minutes = db.get_int(conn, "admin_unlock_minutes", 0)
    elif minutes is None:
        minutes = db.get_int(conn, "unlock_minutes", 0)
    expires = db.now() + minutes * 60 if minutes > 0 else None
    revoke_unlocks(conn, bundle_id)  # one live unlock per app; the newest grant wins
    cur = conn.execute(
        "INSERT INTO unlocks(bundle_id, app_name, granted_at, expires_at, reason, attempt_id) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (bundle_id, app_name, db.now(), expires, reason, attempt_id),
    )
    return int(cur.lastrowid)


def active_unlock(conn: sqlite3.Connection, bundle_id: str) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM unlocks WHERE bundle_id = ? AND active = 1 "
        "AND (expires_at IS NULL OR expires_at > ?) ORDER BY id DESC LIMIT 1",
        (bundle_id, db.now()),
    ).fetchone()


def revoke_unlocks(conn: sqlite3.Connection, bundle_id: str) -> None:
    conn.execute("UPDATE unlocks SET active = 0 WHERE bundle_id = ? AND active = 1", (bundle_id,))


def record_admin_override(conn: sqlite3.Connection, target_name: str, target_bundle_id: str) -> int:
    """Log a parent/admin PIN override as its own attempt row and grant the unlock."""
    cur = conn.execute(
        "INSERT INTO attempts(kind, target_name, target_bundle_id, started_at, finished_at, passed, "
        "passing_score) VALUES ('admin_override', ?, ?, ?, ?, 1, ?)",
        (target_name, target_bundle_id, db.now(), db.now(), db.get_int(conn, "passing_score", 70)),
    )
    attempt_id = int(cur.lastrowid)
    grant_unlock(conn, target_bundle_id, target_name, attempt_id, "admin_override")
    return attempt_id
