"""Paths and constants shared by every Quillio process."""

from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "Quillio"
APP_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = Path(__file__).resolve().parent / "static"

DASHBOARD_HOST = "127.0.0.1"  # never listen on anything but loopback
DASHBOARD_PORT = int(os.environ.get("ACADEMIC_HUB_PORT", "8765"))
DASHBOARD_URL = f"http://{DASHBOARD_HOST}:{DASHBOARD_PORT}"

LAUNCHD_PREFIX = "com.academichub"


def _windows_base() -> Path:
    return Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "AcademicHub"


def data_dir() -> Path:
    """Folder that holds the SQLite database (override with ACADEMIC_HUB_DATA)."""
    env = os.environ.get("ACADEMIC_HUB_DATA")
    if env:
        path = Path(env).expanduser()
    elif sys.platform == "win32":
        path = _windows_base() / "data"
    else:
        path = Path.home() / "Library" / "Application Support" / "AcademicHub" / "data"
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    return data_dir() / "academic_hub.db"


def log_dir() -> Path:
    env = os.environ.get("ACADEMIC_HUB_LOGS")
    if env:
        path = Path(env).expanduser()
    elif sys.platform == "win32":
        path = _windows_base() / "logs"
    else:
        path = Path.home() / "Library" / "Logs" / "AcademicHub"
    path.mkdir(parents=True, exist_ok=True)
    return path


def detached_popen_kwargs() -> dict:
    """Popen options that start a child process on its own (no console window on Windows)."""
    if sys.platform == "win32":
        import subprocess

        return {"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}
