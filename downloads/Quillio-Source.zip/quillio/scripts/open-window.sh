#!/bin/bash
# Opens the Quillio dashboard window. Used by Quillio.app (Applications) and safe to run in Terminal too.
#
# The window is started by launchd inside the signed-in user's own desktop session (a "window" LaunchAgent
# that only runs on request) instead of being started straight from Finder. Started straight from Finder the
# Qt WebEngine window could come up blank on some Macs; started this way it is the same process that works
# when run from Terminal. The graphics chip is not used for the page (it is not needed for a dashboard).
HERE="$(cd "$(dirname "$0")" && pwd)"
CFG="$HERE/../config.env"
[ -f "$CFG" ] || CFG="/Library/Application Support/AcademicHub/config.env"
if [ ! -f "$CFG" ]; then
  /usr/bin/osascript -e 'display dialog "Quillio is not set up on this Mac. Run the Quillio installer again." buttons {"OK"} default button "OK" with icon caution'
  exit 0
fi
# shellcheck disable=SC1090
. "$CFG"
PORT="${AH_PORT:-8765}"
LOG_DIR="${AH_LOGS:-$HOME/Library/Logs/AcademicHub}"
/bin/mkdir -p "$LOG_DIR"
exec >>"$LOG_DIR/window-launch.log" 2>&1
echo "===== open window: $(/bin/date) (user $(/usr/bin/id -un)) ====="

if [ -n "${AH_USER:-}" ] && [ "$(/usr/bin/id -un)" != "$AH_USER" ]; then
  /usr/bin/osascript -e "display dialog \"Quillio protects the account '$AH_USER'. Open the dashboard while logged in to that account.\" buttons {\"OK\"} default button \"OK\""
  exit 0
fi

UID_NUM="$(/usr/bin/id -u)"
DOMAIN="gui/$UID_NUM"

# Make sure the two background helpers are running.
for s in monitor dashboard; do
  if ! /bin/launchctl print "$DOMAIN/com.academichub.$s" >/dev/null 2>&1; then
    for dir in /Library/LaunchAgents "$HOME/Library/LaunchAgents"; do
      [ -f "$dir/com.academichub.$s.plist" ] && /bin/launchctl bootstrap "$DOMAIN" "$dir/com.academichub.$s.plist" >/dev/null 2>&1 && break
    done
  fi
done
for _ in $(seq 1 30); do
  /usr/bin/curl -s -o /dev/null "http://127.0.0.1:$PORT/" && break
  /bin/sleep 0.5
done

PYBIN="${AH_HOME:-/Library/Application Support/AcademicHub}/venv/bin/python"
APP_CODE="${AH_HOME:-/Library/Application Support/AcademicHub}/app"
if [ ! -x "$PYBIN" ]; then
  echo "No Python found at $PYBIN, opening the browser instead."
  /usr/bin/open "http://127.0.0.1:$PORT"
  exit 0
fi

# Describe the window job (runs only when asked: RunAtLoad is off).
LABEL="com.academichub.window"
AGENT_DIR="$HOME/Library/LaunchAgents"
PLIST="$AGENT_DIR/$LABEL.plist"
/bin/mkdir -p "$AGENT_DIR"
"$PYBIN" - "$PLIST" "$PYBIN" "$APP_CODE" "$PORT" "${AH_DATA:-}" "$LOG_DIR" <<'PY'
import plistlib, sys
plist_path, pybin, app_code, port, data, logs = sys.argv[1:]
env = {
    "PYTHONPATH": app_code,
    "ACADEMIC_HUB_PORT": port,
    "ACADEMIC_HUB_LOGS": logs,
    "QTWEBENGINE_CHROMIUM_FLAGS": "--disable-gpu",
    "PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",
}
if data:
    env["ACADEMIC_HUB_DATA"] = data
obj = {
    "Label": "com.academichub.window",
    "ProgramArguments": [pybin, "-u", "-m", "academic_hub.dashboard_app"],
    "WorkingDirectory": app_code,
    "RunAtLoad": False,
    "KeepAlive": False,
    "ProcessType": "Interactive",
    "EnvironmentVariables": env,
    "StandardOutPath": logs + "/window.stdout.log",
    "StandardErrorPath": logs + "/window.stderr.log",
}
with open(plist_path, "wb") as f:
    plistlib.dump(obj, f, sort_keys=True)
PY
/bin/chmod 644 "$PLIST"

# (Re)load the job so that a changed description is used, unless the window is open right now.
if /bin/launchctl print "$DOMAIN/$LABEL" 2>/dev/null | /usr/bin/grep -q "state = running"; then
  echo "The window is already running."
else
  /bin/launchctl bootout "$DOMAIN/$LABEL" >/dev/null 2>&1 || true
  if /bin/launchctl bootstrap "$DOMAIN" "$PLIST"; then
    /bin/launchctl kickstart "$DOMAIN/$LABEL" && echo "Window requested."
  else
    echo "launchd could not start the window; starting it directly."
    export PYTHONPATH="$APP_CODE" ACADEMIC_HUB_PORT="$PORT" ACADEMIC_HUB_LOGS="$LOG_DIR" QTWEBENGINE_CHROMIUM_FLAGS="--disable-gpu"
    [ -n "${AH_DATA:-}" ] && export ACADEMIC_HUB_DATA="$AH_DATA"
    exec "$PYBIN" -m academic_hub.dashboard_app
  fi
fi
