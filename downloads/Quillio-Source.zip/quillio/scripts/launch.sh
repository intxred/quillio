#!/bin/bash
# Starts one Quillio service. Called by launchd:  launch.sh monitor|dashboard
HERE="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
. "$HERE/../config.env"

if [ -n "${AH_USER:-}" ] && [ "$(id -un)" != "$AH_USER" ]; then
  # Installed system-wide for one account: stay idle for every other account.
  exec /bin/sleep 2147483647
fi

export ACADEMIC_HUB_DATA="$AH_DATA"
export ACADEMIC_HUB_LOGS="$AH_LOGS"
export ACADEMIC_HUB_PORT="$AH_PORT"
export PYTHONPATH="$AH_HOME/app"

case "${1:-}" in
  monitor)   MODULE="academic_hub.monitor" ;;
  dashboard) MODULE="academic_hub.dashboard_server" ;;
  *) echo "usage: launch.sh monitor|dashboard" >&2; exit 2 ;;
esac

exec "$AH_HOME/venv/bin/python" -m "$MODULE"
