#!/bin/bash
# Quillio installer for macOS (MacBook Air M1 or any Mac on macOS 12+).
#
# Run it in Terminal, from inside the quillio folder:
#   ./install.sh                           normal install for the account you are logged in to
#   sudo ./install.sh --system --user kid  hardened install for the account named "kid"
#
# Options:  --skip-pin   do not ask for an admin PIN now
#           --port N     dashboard port (default 8765)
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
MODE="user"
TARGET_USER=""
SKIP_PIN=0
PORT="${ACADEMIC_HUB_PORT:-8765}"

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
die() { printf '\n\033[31mError:\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
  sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'
}

while [ $# -gt 0 ]; do
  case "$1" in
    --system)   MODE="system" ;;
    --user)     [ $# -ge 2 ] || die "--user needs an account name"; TARGET_USER="$2"; shift ;;
    --skip-pin) SKIP_PIN=1 ;;
    --port)     [ $# -ge 2 ] || die "--port needs a number"; PORT="$2"; shift ;;
    -h|--help)  usage; exit 0 ;;
    *)          usage; die "Unknown option: $1" ;;
  esac
  shift
done

# ------------------------------------------------------------------ checks
[ "$(uname -s)" = "Darwin" ] || die "Quillio only runs on macOS."
MACOS_MAJOR="$(sw_vers -productVersion | cut -d. -f1)"
[ "$MACOS_MAJOR" -ge 12 ] || die "macOS 12 (Monterey) or newer is required (this Mac has $(sw_vers -productVersion))."
case "$PORT" in ''|*[!0-9]*) die "The port must be a number." ;; esac
[ -f "$SRC_DIR/academic_hub/monitor.py" ] || die "Run this script from inside the quillio folder."

if [ "$MODE" = "system" ]; then
  [ "$(id -u)" -eq 0 ] || die "System mode needs admin rights. Run: sudo ./install.sh --system --user <account>"
  TARGET_USER="${TARGET_USER:-${SUDO_USER:-}}"
  { [ -n "$TARGET_USER" ] && [ "$TARGET_USER" != "root" ]; } || die "Say which account to protect: sudo ./install.sh --system --user <account>"
  id "$TARGET_USER" >/dev/null 2>&1 || die "There is no account called '$TARGET_USER'."
  TARGET_UID="$(id -u "$TARGET_USER")"
  TARGET_HOME="$(dscl . -read "/Users/$TARGET_USER" NFSHomeDirectory | sed 's/^NFSHomeDirectory: //')"
  APP_HOME="/Library/Application Support/AcademicHub"
  DATA_DIR="$TARGET_HOME/Library/Application Support/AcademicHub/data"
  LOG_DIR="$TARGET_HOME/Library/Logs/AcademicHub"
  PLIST_DIR="/Library/LaunchAgents"
  CONFIG_USER="$TARGET_USER"
else
  [ "$(id -u)" -ne 0 ] || die "Do not use sudo for the normal install. Run ./install.sh as yourself."
  TARGET_USER="$(id -un)"
  TARGET_UID="$(id -u)"
  TARGET_HOME="$HOME"
  APP_HOME="$HOME/Library/Application Support/AcademicHub"
  DATA_DIR="$APP_HOME/data"
  LOG_DIR="$HOME/Library/Logs/AcademicHub"
  PLIST_DIR="$HOME/Library/LaunchAgents"
  CONFIG_USER=""
fi
VENV="$APP_HOME/venv"
DOMAIN="gui/$TARGET_UID"

as_user() {  # run a command as the protected account
  if [ "$MODE" = "system" ]; then sudo -u "$TARGET_USER" -H "$@"; else "$@"; fi
}

say "Quillio installer"
note "Mode:        $MODE install for account '$TARGET_USER'"
note "Program in:  $APP_HOME"
note "Data in:     $DATA_DIR"
note "Dashboard:   http://127.0.0.1:$PORT"

# ------------------------------------------------------------------ stop an older install
stop_services() {
  for s in monitor dashboard window; do
    launchctl bootout "$DOMAIN/com.academichub.$s" >/dev/null 2>&1 || true
  done
  pkill -u "$TARGET_UID" -f 'academic_hub\.(quiz_ui|dashboard_app)' >/dev/null 2>&1 || true
}
stop_services

# ------------------------------------------------------------------ Python
python_ok() {
  "$1" -c 'import sys, venv, ensurepip; sys.exit(0 if (3, 9) <= sys.version_info[:2] <= (3, 13) else 1)' >/dev/null 2>&1
}

find_python() {
  local c
  for c in \
    /opt/homebrew/opt/python@3.13/bin/python3.13 /opt/homebrew/opt/python@3.12/bin/python3.12 \
    /opt/homebrew/opt/python@3.11/bin/python3.11 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
    /Library/Frameworks/Python.framework/Versions/3.{13,12,11,10}/bin/python3; do
    if [ -x "$c" ] && python_ok "$c"; then echo "$c"; return 0; fi
  done
  # Apple's own python3 only if the Command Line Tools exist (running it otherwise opens an install dialog).
  if xcode-select -p >/dev/null 2>&1 && [ -x /usr/bin/python3 ] && python_ok /usr/bin/python3; then
    echo /usr/bin/python3; return 0
  fi
  return 1
}

say "Looking for Python 3"
PY="$(find_python || true)"
if [ -z "$PY" ]; then
  BREW=""
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && BREW="$b" && break; done
  if [ -n "$BREW" ]; then
    note "Python 3 was not found. Installing it with Homebrew..."
    as_user "$BREW" install python@3.12
    PY="$(find_python || true)"
  fi
fi
if [ -z "$PY" ] && [ "${AH_ALLOW_PYTHON_DOWNLOAD:-0}" = "1" ] && [ "$(id -u)" -eq 0 ]; then
  # Used by the double-click installer (.pkg): fetch the official Python from python.org.
  PY_PKG_URL="https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"
  PY_PKG="$(mktemp -d)/python.pkg"
  note "Python 3 was not found. Downloading the official Python from python.org (about 45 MB)..."
  if curl -fL --retry 3 -o "$PY_PKG" "$PY_PKG_URL"; then
    # Only install it if it is signed by the Python Software Foundation.
    if pkgutil --check-signature "$PY_PKG" 2>&1 | grep -q "BMM5U3QVKW"; then
      installer -pkg "$PY_PKG" -target / && PY="$(find_python || true)"
    else
      note "The downloaded Python package was not signed by the Python Software Foundation. Skipped."
    fi
  else
    note "Could not download Python (no internet?)."
  fi
  rm -f "$PY_PKG"
fi
[ -n "$PY" ] || die "Python 3.9 to 3.13 is needed.
    On your Mac, install it from https://www.python.org/downloads/macos/ (the macOS 64-bit universal2 installer),
    or run 'xcode-select --install' in Terminal, then run this installer again."
note "Using $PY ($("$PY" --version 2>&1))"

# ------------------------------------------------------------------ copy files
say "Copying program files"
mkdir -p "$APP_HOME/app" "$APP_HOME/bin"
rsync -a --delete --exclude '__pycache__' --exclude '*.pyc' "$SRC_DIR/academic_hub/" "$APP_HOME/app/academic_hub/"
cp "$SRC_DIR/requirements.txt" "$APP_HOME/app/requirements.txt"
cp "$SRC_DIR/scripts/launch.sh" "$APP_HOME/bin/launch.sh"
cp "$SRC_DIR/scripts/open-window.sh" "$APP_HOME/bin/open-window.sh"
cp "$SRC_DIR/scripts/quillio" "$APP_HOME/bin/quillio"
cp "$SRC_DIR/uninstall.sh" "$APP_HOME/bin/uninstall.sh"
chmod 755 "$APP_HOME/bin/launch.sh" "$APP_HOME/bin/open-window.sh" "$APP_HOME/bin/quillio" "$APP_HOME/bin/uninstall.sh"

cat > "$APP_HOME/config.env" <<EOF
AH_HOME="$APP_HOME"
AH_USER="$CONFIG_USER"
AH_DATA="$DATA_DIR"
AH_LOGS="$LOG_DIR"
AH_PORT="$PORT"
EOF
chmod 644 "$APP_HOME/config.env"

as_user mkdir -p "$DATA_DIR" "$LOG_DIR"

# ------------------------------------------------------------------ virtual environment
say "Setting up Python packages (needs internet once; about 450 MB)"
if [ ! -x "$VENV/bin/python" ]; then
  "$PY" -m venv "$VENV"
fi
if [ -n "${AH_WHEELS:-}" ] && [ -d "$AH_WHEELS" ] \
   && "$VENV/bin/python" -m pip install --quiet --no-index --find-links "$AH_WHEELS" -r "$APP_HOME/app/requirements.txt"; then
  note "Installed from the packages bundled with the installer (no download needed)."
else
  "$VENV/bin/python" -m pip install --quiet --upgrade pip || true
  "$VENV/bin/python" -m pip install --upgrade -r "$APP_HOME/app/requirements.txt"
fi
PYTHONPATH="$APP_HOME/app" "$VENV/bin/python" -c "import PySide6.QtWidgets, AppKit, sqlite3; print('    Packages OK')" \
  || die "The Python packages did not install correctly. Scroll up for the error."
"$VENV/bin/python" -c "from PySide6.QtWebEngineWidgets import QWebEngineView" >/dev/null 2>&1 \
  || note "Note: the app window needs Qt WebEngine, which is missing. The dashboard will open in the browser instead."
"$VENV/bin/python" -m compileall -q "$APP_HOME/app" || true

if [ "$MODE" = "system" ]; then
  chown -R root:wheel "$APP_HOME"
  chmod -R go-w "$APP_HOME"
fi

# ------------------------------------------------------------------ database and PIN
say "Preparing the database"
run_py() {
  as_user env ACADEMIC_HUB_DATA="$DATA_DIR" ACADEMIC_HUB_LOGS="$LOG_DIR" ACADEMIC_HUB_PORT="$PORT" \
    PYTHONPATH="$APP_HOME/app" PYTHONDONTWRITEBYTECODE=1 "$VENV/bin/python" "$@"
}
run_py -m academic_hub.cli init

if [ "$SKIP_PIN" -eq 0 ]; then
  PIN_SET="$(run_py -c 'from academic_hub import db, security; c = db.connect(); db.init_db(c); print(1 if security.pin_is_set(c) else 0)')"
  if [ "$PIN_SET" != "1" ]; then
    say "Choose an admin PIN"
    note "The PIN unlocks the dashboard, the Exit button on the exam and the parent unlock button."
    tries=0
    until run_py -m academic_hub.cli set-pin; do
      tries=$((tries + 1))
      [ "$tries" -lt 3 ] || die "No PIN was saved. Run this installer again."
    done
  else
    note "An admin PIN already exists; keeping it."
  fi
fi

# ------------------------------------------------------------------ LaunchAgents
say "Setting up start at login"
mkdir -p "$PLIST_DIR"
write_plist() {
  local name="$1" file="$PLIST_DIR/com.academichub.$1.plist"
  cat > "$file" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.academichub.$name</string>
  <key>ProgramArguments</key>
  <array>
    <string>$APP_HOME/bin/launch.sh</string>
    <string>$name</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>5</integer>
  <key>ProcessType</key><string>Interactive</string>
  <key>LimitLoadToSessionType</key><string>Aqua</string>
  <key>StandardOutPath</key><string>$LOG_DIR/$name.out.log</string>
  <key>StandardErrorPath</key><string>$LOG_DIR/$name.err.log</string>
</dict>
</plist>
EOF
  if [ "$MODE" = "system" ]; then
    chown root:wheel "$file"
    chmod 644 "$file"
  fi
  plutil -lint "$file" >/dev/null || die "Could not write a valid $file"
}
write_plist monitor
write_plist dashboard

for s in monitor dashboard; do
  label="com.academichub.$s"
  if launchctl bootstrap "$DOMAIN" "$PLIST_DIR/$label.plist" >/dev/null 2>&1; then
    launchctl kickstart -k "$DOMAIN/$label" >/dev/null 2>&1 || true
    note "started $label"
  else
    note "$label will start the next time '$TARGET_USER' logs in."
  fi
done

# ------------------------------------------------------------------ done
say "Quillio is installed"
cat <<EOF

    Dashboard : http://127.0.0.1:$PORT   (sign in with your admin PIN)
    Control   : "$APP_HOME/bin/quillio" status | restart | test-quiz | logs
    Uninstall : $( [ "$MODE" = "system" ] && echo "sudo " )./uninstall.sh

    Next, on this Mac: open a guarded app (Roblox to start with). It should close and the full-screen exam should appear.
    Only the apps on your list are guarded; Safari and every other app open normally. The Exit button on
    the exam asks for your admin PIN. Add or change quizzes, the number of questions and
    the restricted apps in the dashboard.
    Read README.md ("Limitations") to see what macOS does and does not allow.
EOF
