#!/bin/bash
# Quillio uninstaller. Run it in Terminal, from inside the quillio folder:
#   ./uninstall.sh                normal install:   asks before deleting your quiz data
#   sudo ./uninstall.sh           hardened install: same, for the protected account
# Options:  --purge        also delete the database and logs without asking
#           --keep-data    keep the database and logs without asking
set -uo pipefail

PURGE="ask"
for arg in "$@"; do
  case "$arg" in
    --purge)     PURGE="yes" ;;
    --keep-data) PURGE="no" ;;
    -h|--help)   sed -n '2,7p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 1 ;;
  esac
done

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }

[ "$(uname -s)" = "Darwin" ] || { echo "This uninstaller is for macOS." >&2; exit 1; }

safe_rm() {  # only ever delete paths that belong to Quillio
  case "$1" in
    *AcademicHub*) rm -rf "$1" ;;
    *) echo "Refusing to delete unexpected path: $1" >&2 ;;
  esac
}

stop_for_uid() {  # $1 = uid
  for s in monitor dashboard window; do
    launchctl bootout "gui/$1/com.academichub.$s" >/dev/null 2>&1 || true
  done
  pkill -u "$1" -f 'academic_hub\.(monitor|dashboard_server|dashboard_app|quiz_ui)' >/dev/null 2>&1 || true
}

ask_purge() {  # $1 = data dir, $2 = log dir
  local data="$1" logs="$2" answer="n"
  if [ "$PURGE" = "yes" ]; then answer="y"
  elif [ "$PURGE" = "ask" ]; then
    read -r -p "Delete the quiz database, attempt history and logs? [y/N] " answer
  fi
  case "$answer" in
    y|Y|yes|YES)
      [ -n "$data" ] && safe_rm "$data" && note "Deleted $data"
      [ -n "$logs" ] && safe_rm "$logs" && note "Deleted $logs"
      # remove the now-empty parent (…/AcademicHub) if nothing else is in it
      [ -n "$data" ] && rmdir "$(dirname "$data")" >/dev/null 2>&1 || true
      ;;
    *) note "Kept your data in $data" ;;
  esac
}

FOUND=0

# ------------------------------------------------------------------ hardened (system-wide) install
SYS_HOME="/Library/Application Support/AcademicHub"
if ls /Library/LaunchAgents/com.academichub.*.plist >/dev/null 2>&1 || [ -d "$SYS_HOME" ]; then
  FOUND=1
  if [ "$(id -u)" -ne 0 ]; then
    echo "A hardened (system-wide) install was found. Run:  sudo ./uninstall.sh" >&2
    exit 1
  fi
  say "Removing the hardened install"
  AH_USER=""; AH_DATA=""; AH_LOGS=""
  # shellcheck disable=SC1091
  [ -f "$SYS_HOME/config.env" ] && . "$SYS_HOME/config.env"
  if [ -n "$AH_USER" ] && id "$AH_USER" >/dev/null 2>&1; then
    stop_for_uid "$(id -u "$AH_USER")"
    AH_USER_HOME="$(eval echo "~$AH_USER")"
    rm -f "$AH_USER_HOME/Library/LaunchAgents/com.academichub.window.plist"
  fi
  rm -f /Library/LaunchAgents/com.academichub.monitor.plist /Library/LaunchAgents/com.academichub.dashboard.plist
  safe_rm "$SYS_HOME"
  note "Removed program files and start-at-login items."
  ask_purge "$AH_DATA" "$AH_LOGS"
fi

# ------------------------------------------------------------------ normal (per-user) install
USER_HOME_DIR="$HOME/Library/Application Support/AcademicHub"
if [ "$(id -u)" -ne 0 ] && { ls "$HOME"/Library/LaunchAgents/com.academichub.*.plist >/dev/null 2>&1 || [ -d "$USER_HOME_DIR" ]; }; then
  FOUND=1
  say "Removing the installation for $(id -un)"
  stop_for_uid "$(id -u)"
  rm -f "$HOME/Library/LaunchAgents/com.academichub.monitor.plist" "$HOME/Library/LaunchAgents/com.academichub.dashboard.plist" "$HOME/Library/LaunchAgents/com.academichub.window.plist"
  for item in app venv bin config.env; do safe_rm "$USER_HOME_DIR/$item"; done
  note "Removed program files and start-at-login items."
  ask_purge "$USER_HOME_DIR/data" "$HOME/Library/Logs/AcademicHub"
  rmdir "$USER_HOME_DIR" >/dev/null 2>&1 || true
fi

if [ "$FOUND" -eq 0 ]; then
  echo "No Quillio installation was found for this account."
  exit 0
fi

say "Quillio has been removed"
note "Every app works normally again. Nothing else on your Mac was changed."
