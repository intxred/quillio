# Quillio

**Learn Your Way In.** Quillio is a local, offline quiz and assessment app for a Mac (and Windows 10/11 — see 2-W) that you customize completely: your own subjects, questions, number of questions per exam and passing score. It comes with 80 starter Grade 5 questions in 8 subjects that you can edit, delete or replace with anything (any grade, language, training or topic). Its optional app gate puts a quiz in front of apps you choose: when a guarded app is opened, Quillio closes it and shows a full-screen exam. The app can be used only after the learner passes (**70/100 or more** by default). **You choose which apps are guarded** (Roblox is the starter app; add Minecraft, Fortnite, Steam, Discord, a browser or any other app), and **each app can have its own exam rules**: number of questions, passing score, how long a pass lasts, how many exams in a row, and which subjects. Everything not on the list (Safari, Chrome, school apps and so on) works normally. An **Exit** button on the exam closes it after the admin PIN is entered. Parents manage everything in the **Quillio app window** (a lime, black and off-white dashboard; it falls back to the browser if the window cannot start). The exam window uses the same look, and the hedgehog is sad when the exam is not passed.

Everything runs on the Mac itself. No cloud, no accounts, no paid services.

| Part | What it is |
|---|---|
| **Quiz** | PySide6 full-screen window. 10 questions per exam (shared evenly between the subjects; you can change the number), multiple choice, instant feedback with an explanation, no timer, **Exit** button protected by the PIN. |
| **Monitor** | Background service that closes restricted apps until the quiz is passed. |
| **Dashboard** | Opens in its own app window (it is the page `http://127.0.0.1:8765` shown inside the app). Create, edit, delete, import and export questions. Change the pass mark and restricted apps. See attempts and progress. |
| **Storage** | One SQLite file on the Mac. |
| **Start at login** | Two macOS LaunchAgents (`monitor` and `dashboard`). |

Subjects: Mathematics, Science, English, Filipino, Araling Panlipunan, MAPEH, Computer Studies, General Knowledge. Each has 10 starter questions, so retries rotate through different questions. Add as many as you like.

---

## 1. Before you start

On your **MacBook Air M1**:

- macOS 12 (Monterey) or newer.
- An internet connection for the install only (about 450 MB of Python packages, including the Qt web view used by the app window). After that it works offline.
- Python 3.9 to 3.13. The installer looks for one and uses Homebrew if you have it. If it finds none, install Python from <https://www.python.org/downloads/macos/> (the universal2 installer), then run the installer again.

**Recommended layout for a child's Mac:** keep your own **Administrator** account for yourself, and let the child use a **Standard** account (System Settings, Users & Groups). Install Quillio for the child's account as shown in section 2B. A child using an Administrator account can switch the guard off in seconds. See "Limitations" below.

## 2. Install

### 2-0. Double-click installer (easiest)

Use **Quillio Installer.pkg**. On your **Mac, logged in as the account that uses the guarded apps**:

1. Double-click the file. macOS blocks it the first time because it is not signed with an Apple developer certificate. Click **Done**, open System Settings, **Privacy & Security**, scroll to Security and click **Open Anyway** (macOS 15 and newer no longer allow right-click, Open). Alternative in Terminal: `xattr -d com.apple.quarantine ~/Downloads/"Quillio Installer.pkg"`.
2. Click through Welcome, Read Me, **License** (click **Agree**) and **Install**, and enter your Mac administrator password.
3. The Quillio window opens. Create the admin PIN right away.

It installs **Quillio** and **Uninstall Quillio** in Applications. To remove it later, open **Uninstall Quillio**.
It needs the internet once: it downloads the program's packages (about 450 MB) and, if Python is missing, the official Python from python.org. Installing takes a few minutes, so wait for the Finish screen.
Log: `/var/log/AcademicHub-install.log`. To rebuild it yourself: `python3 installer/build_pkg.py`. Add `--wheels <folder>` to bundle the packages for an offline installer.

### 2-W. Windows 10 / 11 (new, not yet tested on a real PC)

Use **Quillio Setup.exe**. On the **Windows PC, signed in as an administrator** (it asks for UAC permission):

1. Double-click it. Windows SmartScreen says "Windows protected your PC" because the file is not signed: click **More info**, then **Run anyway**.
2. Next, tick **I accept** on the License page, type the **Windows user name of the account that uses the guarded apps** (other accounts, such as yours, are not affected), then Install. It downloads a private copy of Python and the packages (about 300 MB), so it needs the internet and takes several minutes.
3. On the Finish page leave **Open Quillio now** ticked and create the admin PIN in the window.

What it does: installs to `C:\Program Files\Quillio` (only administrators can change it), adds Start menu and Desktop shortcuts, and starts a small background helper whenever the protected account signs in. The helper watches for the apps on your list (Roblox by default, `RobloxPlayerBeta.exe`), closes them until the exam is passed, and restarts the monitor and dashboard if they stop. Quiz data is in that account's `%LOCALAPPDATA%\AcademicHub`. Logs: `%LOCALAPPDATA%\AcademicHub\logs`.
To remove it: Settings, Apps, **Quillio**, Uninstall (it asks whether to keep the quiz data). To rebuild the installer on any computer with NSIS: `python3 installer/build_windows.py`.

Windows limits to know: Microsoft Store apps (for example the Store version of Roblox) use a different program name (add it in App Lock using the picker while it runs); a Standard account can still end a program in Task Manager, so keep the PC's real protection on the account type and on the PIN; Windows does not let a program block Alt+Tab or the Windows key, so the exam is a full-screen topmost window that is re-raised every second.

### 2A. Quick install (one account)

On your **Mac, in Terminal** (Spotlight: press Command + Space, type "Terminal", press Return), logged in as the account you want to protect:

```bash
cd ~/Downloads/quillio      # wherever you unzipped the folder
./install.sh
```

The installer will:

1. check macOS and find Python 3,
2. copy the program to `~/Library/Application Support/AcademicHub`,
3. create a private Python environment and install PySide6,
4. create the SQLite database and load the 80 starter questions,
5. ask you to choose an **admin PIN** (4 to 32 characters),
6. register the two LaunchAgents so Quillio **starts every time that account logs in**, and start them now.

If Terminal says "permission denied", run `chmod +x install.sh uninstall.sh` once and try again.

### 2B. Hardened install (recommended when a child uses a Standard account)

On your **Mac, in Terminal, logged in as the Administrator**:

```bash
cd ~/Downloads/quillio
sudo ./install.sh --system --user CHILDACCOUNT
```

Replace `CHILDACCOUNT` with the child's short account name (shown in System Settings, Users & Groups, or run `ls /Users`). This version:

- puts the program files and LaunchAgents in `/Library`, owned by root, so a Standard account cannot edit or delete them,
- keeps the database and logs in the child's own Library folder,
- stays idle for every other account on the Mac, so your Administrator account is not affected.

Because the Standard account cannot delete the program, the guard survives casual attempts to remove it. It is still not unbreakable. Read "Limitations".

### 2C. Check it works

On your **Mac, logged in as the protected account**:

1. Open a guarded app (Roblox by default, or press Play on the Roblox website). It should close at once and the full-screen exam should appear. Opening Safari or any other app does nothing special.
2. Click **Start the quiz**. After each answer you see whether you were right and why.
3. Pass with 70/100 or more (7 of 10), then click **Open <app>**. If the app does not start by itself, start it the way you normally do. You have 3 minutes to start it (change this under Settings). The app stays unlocked while it is running (or for the unlock length you set). A few seconds after you close it, it locks again, and opening it again brings the exam back.
4. To leave without passing, click **Exit** (top right), enter the admin PIN and click **Exit exam**. the app stays closed. **Back** returns to the exam where you left it.

To rehearse without closing anything, run `"$HOME/Library/Application Support/AcademicHub/bin/quillio" test-quiz` in Terminal. That opens the quiz in a normal window with no restrictions and no effect on any app.

## 3. The dashboard

Open **http://127.0.0.1:8765** in a browser on the same Mac. The first time, if you skipped the PIN in the installer, you are asked to create one. After that, sign in with the admin PIN.

> **Safari is not restricted any more**, so you can open the dashboard in Safari or any other browser. If you want Safari guarded too, add it under **App Lock** (it is already listed there in older installs, switched off: tick it on).

The dashboard only listens on `127.0.0.1`. Nothing else on your network can reach it.

| Page | What you can do |
|---|---|
| **Dashboard** | Lime welcome banner with the hedgehog, stat cards (questions, average score, pass rate, apps protected with an on/off switch), subject cards with each subject's average, weekly activity chart and recent attempts. **Preview quiz app** and **Start practice session** open the exam in a normal window (nothing is closed or unlocked). The search box (Command + K) jumps to matching questions, and the bell lists anything that needs attention. |
| **Quiz Library** | Add, edit, rename, switch off or delete subjects. Add, edit, search, switch off or delete questions (2 to 6 choices, one correct answer, explanation). |
| **Import / Export** | JSON or CSV. Merge into the current bank or replace it. |
| **Progress & Attempts** | Score trend against the pass mark, accuracy per subject, questions most often missed, retries before the first pass, and every attempt with its answers. |
| **App Lock** | The **protection switch** (pauses all blocking), **Lock all apps now**, which apps are unlocked right now, and the restricted apps (one-click presets, pick from installed apps, or type a name or bundle id; untick to pause one). **Edit rules** gives each app its own exam rules (see below). |
| **Settings** | **Default exam rules**: questions per exam (default 10), pass mark (1 to 100, default 70), unlock length, time to start the app after passing, parent unlock length, answer shuffling, **the learner's name and the exam's first-screen text**, change the PIN, clear history. |

### Rules for each app

Under **App Lock**, press **Edit rules** on any app. Empty boxes use the defaults from Settings (so a later change of the default still applies); a filled box overrides it for that app only:

| Rule | Meaning |
|---|---|
| **Questions per exam** | 1 to 100 questions for this app's exam. |
| **Passing score** | 1 to 100 out of 100. |
| **Exams to pass in a row** | 1 to 5. With 2, the learner must pass two exams one after the other; failing one starts the count again. |
| **Unlock length (minutes)** | 0 = unlocked until the app is closed. 30 = a new exam every 30 minutes. |
| **Subjects** | Which subjects the exam draws from (all ticked = every subject that is switched on). |

Example: Roblox keeps the defaults (10 questions, pass 70), while a browser needs a 5-question Mathematics and English exam with a pass mark of 100. **Use all defaults** removes an app's own rules. Rules are read again at the start of each exam, so a change applies to the next exam.

Changes apply to the **next** quiz. An attempt already in progress keeps the pass mark it started with.

### Import and export formats

**JSON** (`correct_index` counts from 0):

```json
{
  "subjects": [{
    "name": "Science", "icon": "🔬",
    "questions": [{
      "text": "Which planet is closest to the Sun?",
      "choices": ["Venus", "Earth", "Mercury", "Mars"],
      "correct_index": 2,
      "explanation": "Mercury is the first planet from the Sun."
    }]
  }]
}
```

**CSV** columns: `subject, question, choice_a … choice_f, correct, explanation, active`. `correct` is a letter A to F. Open it in Numbers or Excel. Importing checks every row first, so one bad row cancels the whole import and nothing is changed.

## 4. Rules the quiz follows

- 10 questions per exam (Settings: "Questions per exam"), spread as evenly as possible over the enabled subjects. With 8 subjects, six subjects give one question and two give two, and the two change every time. Fewer active questions than that means a shorter exam.
- Questions that were seen least are chosen first, so a retry rarely repeats the previous questions.
- Score = correct answers ÷ questions × 100, **rounded down**. 7 of 10 is 70 and passes. 6 of 10 is 60 and fails.
- There is no time limit.
- A failed attempt cannot open the app. The buttons are **Try again**, **Parent: open without the quiz** (PIN) and **Exit** (PIN). Exit closes the exam and leaves the app closed.
- An exam closed with Exit shows as "Unfinished" in the history and does not count as a score.
- Five wrong PIN attempts lock PIN entry for 5 minutes.
- Questions are not deleted from history when you delete them. Old attempts keep the text they were asked.

## 5. Everyday commands

On your **Mac, in Terminal**, as the protected account (quote the path because it contains a space):

```bash
AH="$HOME/Library/Application Support/AcademicHub/bin/quillio"
"$AH" status      # are both services loaded? PIN set? recent attempts
"$AH" url         # prints the dashboard address
"$AH" set-pin     # change the admin PIN
"$AH" restart     # restart monitor and dashboard
"$AH" test-quiz   # open the quiz in a normal window for testing
"$AH" logs        # last lines of the log files
```

For a hardened install, the folder is `/Library/Application Support/AcademicHub/bin/quillio` instead.

Logs are in `~/Library/Logs/AcademicHub/`. The database is `~/Library/Application Support/AcademicHub/data/academic_hub.db`. Back it up by exporting from the dashboard, or copy that file while the services are stopped.

## 6. Uninstall

On your **Mac, in Terminal**, from the `quillio` folder:

```bash
./uninstall.sh              # quick install: asks before deleting quiz data
sudo ./uninstall.sh         # hardened install
./uninstall.sh --purge      # also delete database and logs without asking
./uninstall.sh --keep-data  # keep database and logs without asking
```

It stops both services, removes the LaunchAgents and the program files, and leaves everything else on your Mac untouched. Every app works normally straight away.

If you no longer have the folder, delete these by hand in Terminal:

```bash
launchctl bootout gui/$(id -u)/com.academichub.monitor
launchctl bootout gui/$(id -u)/com.academichub.dashboard
rm -f ~/Library/LaunchAgents/com.academichub.*.plist
rm -rf "$HOME/Library/Application Support/AcademicHub" "$HOME/Library/Logs/AcademicHub"
```

## 7. Limitations (please read)

macOS has no supported way for an ordinary program to "lock" another app. Quillio uses the strongest approach available without kernel extensions, a paid developer account, or an MDM server: it watches running applications and force-quits any restricted app that has not been unlocked. What that means in practice:

1. **It is a strong guard for a child, not a security boundary against a determined user.** Any program running as the child's own user, including that user's Terminal, can stop the services, edit the SQLite database, or change the PIN hash. Standard accounts cannot edit the `/Library` program files from the hardened install, but they can still stop their own login-session services and edit their own data. If the child knows how to do that, only an Administrator-controlled option can stop it (see the next point).
2. **Use Apple's Screen Time as a second layer.** Screen Time (System Settings, Screen Time, Content & Privacy and App Limits) is enforced by macOS and protected by its own passcode. It cannot run a quiz, but it can block categories of apps and websites that Quillio cannot see.
3. **There is a short gap.** The monitor checks about every 0.4 seconds, so a restricted app may flash on screen for a moment before it is closed. Unsaved work in a restricted app is lost, because the app is force-quit on purpose.
4. **It only guards the apps on the list.** That is whatever you put on the App Lock list (Roblox and Roblox Studio to start with). Other games and websites are not guarded. Add more apps under App Lock, and consider Screen Time web restrictions.
5. **It runs only while the account is logged in.** At the login screen, and under other accounts, nothing is guarded. Turn on automatic login only for accounts that should be guarded, and use Fast User Switching with care.
6. **macOS can switch it off.** On macOS 13 and newer, System Settings, General, Login Items & Extensions lists "Quillio" background items. If someone turns those switches off, the guard stops. Keep them on, and check them if the quiz stops appearing.
7. **The full-screen lock is a convenience, not a lock.** The quiz window sits above other windows, hides the Dock and menu bar, and disables Command-Tab and Force Quit while it is the active app. macOS still allows some system shortcuts (screenshots, Mission Control gestures, power button). They do not unlock anything, because the monitor keeps closing the restricted app regardless of what the quiz window is doing. Log Out, Restart and Shut Down stay available on purpose so a Mac can never be trapped.
8. **It fails closed once running, but not before.** If the quiz cannot start, restricted apps stay closed. If the monitor itself is stopped, apps open freely until it restarts (launchd restarts it within about 5 seconds if it is killed).
9. **Two Macs, two databases.** There is no sync. This is by design, since there is no cloud.
10. **Scores are self-reported by the Mac.** Someone who can edit the database can change history.

## 8. Troubleshooting

| Problem | Fix (on your Mac, in Terminal) |
|---|---|
| The quiz never appears | `"$AH" status`. If a service says "NOT loaded", log out and back in, or run `"$AH" restart`. Check System Settings, General, Login Items & Extensions. |
| The Quillio window is blank when opened from Finder | The app starts the window through launchd (`open-window.sh`) with the graphics chip off, and opens the dashboard in your browser by itself if the window is blank. If it still fails, send the files in `~/Library/Logs/AcademicHub`: `window-launch.log`, `window.stdout.log`, `window.stderr.log`. To open it by hand in Terminal: `"/Library/Application Support/AcademicHub/bin/open-window.sh"`. |
| Dashboard will not load | `"$AH" logs`. Another program may use port 8765. Run `./install.sh --port 8800` again to use a different port. |
| "Python 3.9 or newer is needed" | Install Python from python.org, then run `./install.sh` again. |
| Forgot the PIN | In Terminal run `"$AH" set-pin`. Anyone who can run that as the protected account can reset the PIN, which is one more reason to use a Standard account for the child. |
| A guarded app is not blocked | Open App Lock. Add it with the "Pick from installed apps" list so the bundle id is exact. Names are also matched as prefixes, so "Roblox" covers "Roblox Studio". |
| A restricted app keeps closing after I passed | Check the pass mark under Settings. Check that "Unlock length after passing" is 0 or long enough. |

## 9. Project layout

```
quillio/
  install.sh  uninstall.sh  requirements.txt
  scripts/            launch.sh (used by launchd), quillio (control commands)
  academic_hub/
    db.py             SQLite schema, settings, seeding
    seed_data.py      80 starter questions (Grade 5, replaceable)
    quiz_engine.py    sessions, grading, attempts, unlocks
    quiz_ui.py        full-screen PySide6 quiz
    monitor.py        background app monitor
    macos.py          AppKit helpers (running apps, kiosk mode)
    dashboard_server.py  local JSON API + static files
    static/           the dashboard (HTML, CSS, JavaScript) and mascot.svg (the hedgehog; replace it with your own SVG to change the mascot in the dashboard and the exam)
    bank_io.py        import and export
    progress.py       statistics for the dashboard
    security.py       PIN hashing and lockout
  tests/              87 automated tests
```

## 10. Running the tests

On any computer with Python 3.9+ (the Mac-specific parts are skipped automatically elsewhere):

```bash
pip install PySide6-Essentials
python3 -m unittest discover -s tests -v
```

The tests cover seeding, session building, grading (including the 70/100 boundary), unlocks, the PIN lockout, import and export, the dashboard API and its security checks, and the quiz window driven offscreen. The AppKit app monitoring, kiosk mode, installer, uninstaller and launchd behaviour need a real Mac and were **not** run by the automated tests. See section 2C for the quick manual check.
