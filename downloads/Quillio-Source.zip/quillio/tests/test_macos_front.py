"""The macOS-only 'bring the exam in front of the browser' code, run against a stand-in for AppKit."""

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from academic_hub import macos  # noqa: E402


class FakeWindow:
    def __init__(self):
        self.calls = []

    def level(self): return 1000
    def isVisible(self): return True
    def isOnActiveSpace(self): return True
    def frame(self): return SimpleNamespace(origin=SimpleNamespace(x=0, y=0), size=SimpleNamespace(width=1440, height=900))
    def setLevel_(self, v): self.calls.append(("level", v))
    def setCollectionBehavior_(self, v): self.calls.append(("behavior", v))
    def setHidesOnDeactivate_(self, v): self.calls.append(("hides", v))
    def orderFrontRegardless(self): self.calls.append(("front",))


class FakeAppKit:
    NSWindowCollectionBehaviorCanJoinAllSpaces = 1
    NSWindowCollectionBehaviorFullScreenAuxiliary = 2
    NSWindowCollectionBehaviorIgnoresCycle = 4
    NSApplicationActivateIgnoringOtherApps = 2
    NSApplicationActivateAllWindows = 1
    NSApplicationActivationPolicyAccessory = 1

    def __init__(self, windows):
        self.activated = []
        outer = self

        class NSApplication:
            @staticmethod
            def sharedApplication():
                return SimpleNamespace(
                    windows=lambda: windows,
                    setActivationPolicy_=lambda p: outer.activated.append(("policy", p)) or True,
                    activationPolicy=lambda: 1,
                    isActive=lambda: False,
                    activateIgnoringOtherApps_=lambda v: outer.activated.append(("app", v)),
                )

        class NSRunningApplication:
            @staticmethod
            def currentApplication():
                return SimpleNamespace(activateWithOptions_=lambda o: outer.activated.append(("running", o)))

        self.NSApplication, self.NSRunningApplication = NSApplication, NSRunningApplication


class BringToFront(unittest.TestCase):
    def setUp(self):
        self._saved = (macos.IS_MAC, getattr(macos, "AppKit", None))
        self.windows = [FakeWindow(), FakeWindow()]  # the exam window and a cover for a second screen
        macos.IS_MAC = True
        macos.AppKit = FakeAppKit(self.windows)

    def tearDown(self):
        macos.IS_MAC = self._saved[0]
        if self._saved[1] is None:
            del macos.AppKit
        else:
            macos.AppKit = self._saved[1]

    def test_every_window_goes_above_everything_and_to_the_front(self):
        self.assertTrue(macos.elevate_all_windows())
        for w in self.windows:
            self.assertIn(("level", 1000), w.calls)
            self.assertIn(("behavior", 7), w.calls)     # all Spaces + over full-screen apps + no Cmd-Tab
            self.assertIn(("hides", False), w.calls)
            self.assertIn(("front",), w.calls)          # ordered front even if the app is not active

    def test_activation_asks_both_ways(self):
        macos.activate_app()
        self.assertEqual({k for k, _ in macos.AppKit.activated}, {"app", "running"})

    def test_overlay_policy_is_requested_so_a_fullscreen_browser_can_be_covered(self):
        self.assertTrue(macos.use_overlay_policy())
        self.assertIn(("policy", 1), macos.AppKit.activated)

    def test_diagnostics_line_names_level_space_and_frame(self):
        line = macos.describe_windows()
        self.assertIn("level=1000", line)
        self.assertIn("onActiveSpace=True", line)
        self.assertIn("1440x900", line)

    def test_a_failure_never_raises(self):
        macos.AppKit.NSApplication.sharedApplication = staticmethod(lambda: (_ for _ in ()).throw(RuntimeError("boom")))
        self.assertFalse(macos.elevate_all_windows())
        macos.activate_app()  # logs, does not raise


if __name__ == "__main__":
    unittest.main()
