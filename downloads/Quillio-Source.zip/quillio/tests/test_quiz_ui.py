"""Drives the real PySide6 quiz window offscreen. Skipped when PySide6 is missing."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
_TMP = tempfile.mkdtemp(prefix="ah-ui-")

try:
    from PySide6.QtWidgets import QApplication
    HAVE_QT = True
except ImportError:  # pragma: no cover
    HAVE_QT = False

if HAVE_QT:
    from academic_hub import db, quiz_engine, quiz_ui, security


ROBLOX = "com.roblox.RobloxPlayer"


@unittest.skipUnless(HAVE_QT, "PySide6 not installed")
class QuizWindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(sys.argv[:1])
        cls.app.setStyleSheet(quiz_ui.STYLE)

    def setUp(self):
        self.conn = db.connect(Path(_TMP) / f"{self._testMethodName}.db")
        db.init_db(self.conn)
        security.set_pin(self.conn, "2468")
        self.win = quiz_ui.QuizWindow(self.conn, "Roblox", ROBLOX, windowed=True, test_mode=False)
        self.win.present()
        self.win.launched = []
        quiz_ui.macos.launch_app = lambda name, bundle="": self.win.launched.append((name, bundle))

    def tearDown(self):
        self.win._allow_close = True
        self.win.close()

    def answer_all(self, wrong: int):
        self.win.start_quiz()
        for i in range(len(self.win.session)):
            q = self.win.session[i]
            pick = q["correct_index"]
            if i < wrong:
                pick = (pick + 1) % len(q["choices"])
            self.win.choose(pick)
            if i < wrong:  # wrong answer must show the explanation and the right answer
                self.assertIn("Not quite", self.win.feedback_title.text())
            else:
                self.assertIn("Correct", self.win.feedback_title.text())
            self.win.next_question()

    # ---------------------------------------------------------------- the exam itself
    def test_intro_shows_rules(self):
        text = self.win.intro_info.text()
        self.assertIn("10 questions", text)
        self.assertIn("no time limit", text)
        self.assertIn("70/100", text)
        self.assertEqual(self.win.intro_title.text(), "Quiz time! Pass to open Roblox.")

    def test_intro_text_comes_from_the_dashboard_settings(self):
        db.set_setting(self.conn, "intro_title", "Brain first, {app} second!")
        db.set_setting(self.conn, "intro_message", "Good luck.")
        db.set_setting(self.conn, "questions_per_quiz", 6)
        self.win._refresh_intro_info()
        self.assertEqual(self.win.intro_title.text(), "Brain first, Roblox second!")
        self.assertEqual(self.win.intro_message.text(), "Good luck.")
        self.assertIn("6 questions", self.win.intro_info.text())

    def test_exam_has_ten_questions(self):
        self.win.start_quiz()
        self.assertEqual(len(self.win.session), 10)
        self.assertEqual(self.win.q_progress_label.text(), "Question 1 of 10")

    def test_fail_then_retry_then_pass_unlocks_only_after_pass(self):
        self.answer_all(wrong=4)  # 6/10 = 60
        self.assertIsNone(quiz_engine.active_unlock(self.conn, ROBLOX))
        row = self.conn.execute("SELECT * FROM attempts ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual((row["score"], row["passed"]), (60, 0))
        self.assertEqual(self.win.launched, [])

        self.answer_all(wrong=3)  # retry: 7/10 = 70
        row = self.conn.execute("SELECT * FROM attempts ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual((row["score"], row["passed"]), (70, 1))
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, ROBLOX))
        self.assertEqual(self.conn.execute("SELECT COUNT(*) n FROM attempts").fetchone()["n"], 2)

    def test_hedgehog_is_sad_when_not_passed_and_happy_when_passed(self):
        self.answer_all(wrong=4)  # 60: not passed
        page = self.win.page_result
        self.assertIsNotNone(page.findChild(quiz_ui.QWidget, "mascot-sad"))
        self.assertIsNone(page.findChild(quiz_ui.QWidget, "mascot"))
        self.answer_all(wrong=0)  # 100: passed
        page = self.win.page_result
        self.assertIsNotNone(page.findChild(quiz_ui.QWidget, "mascot"))
        self.assertIsNone(page.findChild(quiz_ui.QWidget, "mascot-sad"))

    def test_real_exam_cannot_be_closed_until_done(self):
        self.win.windowed = False  # the real exam is full-screen, not a preview window
        self.win._allow_close = False
        self.assertFalse(self.win.close())
        self.assertTrue(self.win.isVisible())

    def test_preview_window_closes_normally(self):
        self.win._allow_close = False
        self.assertTrue(self.win.close())

    def test_empty_bank_shows_message_instead_of_crashing(self):
        self.conn.execute("UPDATE questions SET active = 0")
        self.win.start_quiz()
        self.assertIn("no active questions", self.win.intro_error.text())

    # ---------------------------------------------------------------- Exit button + PIN
    def test_exit_button_is_visible_on_every_screen(self):
        self.assertTrue(self.win.exit_btn.isVisible())             # start screen
        self.win.start_quiz()
        self.assertTrue(self.win.exit_btn.isVisible())             # question screen
        for _ in range(len(self.win.session)):
            self.win.choose(self.win.session[self.win.index]["correct_index"])
            self.win.next_question()
        self.assertIs(self.win.stack.currentWidget(), self.win.page_result)
        self.assertTrue(self.win.exit_btn.isVisible())             # result screen

    def test_exit_asks_for_the_pin_and_wrong_pin_does_not_exit(self):
        self.win.exit_btn.click()
        self.assertIs(self.win.stack.currentWidget(), self.win.page_admin)
        self.assertEqual(self.win.pin_ok.text(), "Exit exam")
        self.assertFalse(self.win.exit_btn.isVisible())
        self.win.pin_input.setText("0000")
        self.win.submit_pin()
        self.assertIn("Wrong PIN", self.win.pin_error.text())
        self.assertFalse(self.win._allow_close)
        self.assertTrue(self.win.isVisible())

    def test_exit_with_correct_pin_closes_exam_and_unlocks_nothing(self):
        self.win.start_quiz()
        self.win.choose(self.win.session[0]["correct_index"])      # part-way through
        self.win.exit_btn.click()
        self.win.pin_input.setText("2468")
        self.win.submit_pin()
        self.assertTrue(self.win._allow_close)                     # window is allowed to close
        self.assertIsNone(quiz_engine.active_unlock(self.conn, ROBLOX))
        self.assertEqual(self.win.launched, [])                    # Roblox is NOT opened
        row = self.conn.execute("SELECT * FROM attempts").fetchone()
        self.assertIsNone(row["finished_at"])                      # shows as "Unfinished"
        self.assertEqual(row["passed"], 0)

    def test_back_from_pin_page_returns_to_the_same_question(self):
        self.win.start_quiz()
        self.win.choose(self.win.session[0]["correct_index"])
        self.win.next_question()
        self.assertEqual(self.win.index, 1)
        self.win.exit_btn.click()
        self.win.hide_admin()
        self.assertIs(self.win.stack.currentWidget(), self.win.page_question)
        self.assertEqual(self.win.index, 1)
        self.assertTrue(self.win.exit_btn.isVisible())

    def test_back_from_pin_page_on_the_start_screen(self):
        self.win.exit_btn.click()
        self.win.hide_admin()
        self.assertIs(self.win.stack.currentWidget(), self.win.page_intro)

    def test_five_wrong_pins_lock_the_exit(self):
        self.win.exit_btn.click()
        for _ in range(5):
            self.win.pin_input.setText("1111")
            self.win.submit_pin()
        self.win.pin_input.setText("2468")                          # even the right PIN is refused now
        self.win.submit_pin()
        self.assertIn("Too many", self.win.pin_error.text())
        self.assertFalse(self.win._allow_close)

    def test_exit_without_a_pin_set_explains_what_to_do(self):
        self.conn.execute("UPDATE settings SET value = '' WHERE key = 'admin_pin_hash'")
        self.win.exit_btn.click()
        self.win.pin_input.setText("2468")
        self.win.submit_pin()
        self.assertIn("No admin PIN", self.win.pin_error.text())
        self.assertFalse(self.win._allow_close)

    # ---------------------------------------------------------------- parent unlock (unchanged behaviour)
    def test_admin_pin_path(self):
        self.win.show_admin()
        self.assertEqual(self.win.pin_ok.text(), "Unlock")
        self.win.pin_input.setText("0000")
        self.win.submit_pin()
        self.assertIsNone(quiz_engine.active_unlock(self.conn, ROBLOX))
        self.assertIn("Wrong PIN", self.win.pin_error.text())
        self.win.pin_input.setText("2468")
        self.win.submit_pin()
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, ROBLOX))
        self.assertEqual(self.conn.execute("SELECT kind FROM attempts").fetchone()["kind"], "admin_override")
        self.assertEqual(self.win.launched, [("Roblox", ROBLOX)])


if __name__ == "__main__":
    unittest.main()
