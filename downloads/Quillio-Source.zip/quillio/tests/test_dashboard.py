"""Dashboard API tests against a real server on a random loopback port."""

import http.client
import json
import os
import socket
import sys
import tempfile
import threading
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    PORT = s.getsockname()[1]
_TMP = tempfile.mkdtemp(prefix="ah-dash-")
os.environ.update(ACADEMIC_HUB_DATA=_TMP, ACADEMIC_HUB_LOGS=_TMP, ACADEMIC_HUB_PORT=str(PORT))

from academic_hub import config, dashboard_server, db  # noqa: E402

config.DASHBOARD_PORT = PORT  # config may already be imported by another test module


class Client:
    def __init__(self):
        self.cookie = None
        self.csrf = None

    def call(self, method, path, body=None, host=None, headers=None, raw=False):
        conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        hdrs = {"Host": host or f"127.0.0.1:{PORT}"}
        if self.cookie:
            hdrs["Cookie"] = self.cookie
        if self.csrf and method != "GET":
            hdrs["X-CSRF-Token"] = self.csrf
        data = None
        if body is not None:
            data = json.dumps(body)
            hdrs["Content-Type"] = "application/json"
        hdrs.update(headers or {})
        conn.request(method, path, body=data, headers=hdrs)
        res = conn.getresponse()
        payload = res.read()
        set_cookie = res.getheader("Set-Cookie")
        if set_cookie and "Max-Age=0" not in set_cookie:
            self.cookie = set_cookie.split(";")[0]
        conn.close()
        if raw:
            return res.status, payload, res
        try:
            return res.status, json.loads(payload or b"{}")
        except ValueError:
            return res.status, payload


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        conn = db.connect()
        db.init_db(conn)
        conn.close()
        cls.server = dashboard_server.make_server("127.0.0.1", PORT)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def login(self):
        c = Client()
        status, data = c.call("GET", "/api/session")
        if not data["pin_set"]:
            status, data = c.call("POST", "/api/setup", {"pin": "2468"})
        else:
            status, data = c.call("POST", "/api/login", {"pin": "2468"})
        self.assertEqual(status, 200, data)
        c.csrf = data["csrf"]
        return c

    # ---------------------------------------------------------------- access control
    def test_pages_are_served_and_api_needs_login(self):
        c = Client()
        status, body, res = c.call("GET", "/", raw=True)
        self.assertEqual(status, 200)
        self.assertIn(b"Quillio", body)
        self.assertIn("frame-ancestors 'none'", res.getheader("Content-Security-Policy"))
        for path in ["/api/overview", "/api/questions", "/api/settings", "/api/export", "/api/apps"]:
            self.assertEqual(c.call("GET", path)[0], 401, path)

    def test_foreign_host_header_is_rejected(self):
        self.assertEqual(Client().call("GET", "/api/session", host="evil.example.com")[0], 403)
        self.assertEqual(Client().call("GET", "/", host="evil.example.com")[0], 403)

    def test_wrong_pin_and_csrf(self):
        c = self.login()
        bad = Client()
        self.assertEqual(bad.call("POST", "/api/login", {"pin": "0000"})[0], 401)
        c.csrf = "wrong"
        self.assertEqual(c.call("POST", "/api/subjects", {"name": "Nope"})[0], 403)

    def test_cross_origin_post_and_non_json_rejected(self):
        c = self.login()
        status, _ = c.call("POST", "/api/subjects", {"name": "X1"}, headers={"Origin": "http://evil.example.com"})
        self.assertEqual(status, 403)
        status, _ = c.call("POST", "/api/subjects", {"name": "X1"}, headers={"Content-Type": "text/plain"})
        self.assertEqual(status, 415)

    def test_setup_cannot_overwrite_existing_pin(self):
        self.login()
        self.assertEqual(Client().call("POST", "/api/setup", {"pin": "9999"})[0], 409)

    # ---------------------------------------------------------------- CRUD
    def test_subject_and_question_crud(self):
        c = self.login()
        status, subject = c.call("POST", "/api/subjects", {"name": "Music Theory", "icon": "🎼"})
        self.assertEqual(status, 200)
        self.assertEqual(c.call("POST", "/api/subjects", {"name": "Music Theory"})[0], 409)
        q = {"subject_id": subject["id"], "text": "How many beats in a whole note?",
             "choices": ["1", "2", "4"], "correct_index": 2, "explanation": "Four."}
        status, created = c.call("POST", "/api/questions", q)
        self.assertEqual(status, 200)
        q["text"] = "How many beats does a whole note get in 4/4?"
        status, updated = c.call("PUT", f"/api/questions/{created['id']}", q)
        self.assertEqual((status, updated["text"]), (200, q["text"]))
        status, listed = c.call("GET", f"/api/questions?subject_id={subject['id']}")
        self.assertEqual(len(listed), 1)
        status, found = c.call("GET", "/api/questions?q=whole%20note")
        self.assertEqual(len(found), 1)
        self.assertEqual(c.call("POST", "/api/questions", {**q, "choices": ["1"]})[0], 400)
        self.assertEqual(c.call("DELETE", f"/api/questions/{created['id']}")[0], 200)
        self.assertEqual(c.call("DELETE", f"/api/questions/{created['id']}")[0], 404)
        status, updated_subject = c.call("PUT", f"/api/subjects/{subject['id']}", {"enabled": False})
        self.assertFalse(updated_subject["enabled"])
        self.assertEqual(c.call("DELETE", f"/api/subjects/{subject['id']}")[0], 200)

    def test_sql_wildcards_in_search_are_literal(self):
        c = self.login()
        total = len(c.call("GET", "/api/questions")[1])
        # A lone % is searched literally (only "25% of 80" contains one), not treated as "match all".
        status, found = c.call("GET", "/api/questions?q=%25")
        self.assertEqual(status, 200)
        self.assertTrue(0 < len(found) < total)
        self.assertTrue(all("%" in q["text"] or "%" in "".join(q["choices"]) for q in found))
        self.assertEqual(c.call("GET", "/api/questions?q=zzz%25")[1], [])
        self.assertEqual(c.call("GET", "/api/questions?q=_")[1].__len__() < total, True)

    def test_settings_validation_and_persistence(self):
        c = self.login()
        self.assertEqual(c.call("PUT", "/api/settings", {"passing_score": 150})[0], 400)
        self.assertEqual(c.call("PUT", "/api/settings", {"passing_score": "abc"})[0], 400)
        self.assertEqual(c.call("PUT", "/api/settings", {"questions_per_quiz": 0})[0], 400)
        self.assertEqual(c.call("PUT", "/api/settings", {"reopen_grace_seconds": 5})[0], 400)
        status, s = c.call("GET", "/api/settings")
        self.assertEqual((s["questions_per_quiz"], s["session_size"], s["reopen_grace_seconds"]), (10, 10, 180))
        status, s = c.call("PUT", "/api/settings", {"passing_score": 80, "questions_per_quiz": 15})
        self.assertEqual((s["passing_score"], s["questions_per_quiz"], s["session_size"]), (80, 15, 15))
        status, s = c.call("PUT", "/api/settings", {"questions_per_quiz": 500})
        self.assertEqual(status, 400)
        c.call("PUT", "/api/settings", {"passing_score": 70, "questions_per_quiz": 10})

    def test_exam_on_top_settings(self):
        c = self.login()
        status, s = c.call("GET", "/api/settings")
        self.assertEqual((s["exam_on_top"], s["cover_delay_seconds"]), (0, 5))
        self.assertEqual(c.call("PUT", "/api/settings", {"exam_on_top": 2})[0], 400)
        self.assertEqual(c.call("PUT", "/api/settings", {"cover_delay_seconds": 301})[0], 400)
        status, s = c.call("PUT", "/api/settings", {"exam_on_top": 1, "cover_delay_seconds": 8, "unlock_minutes": 10})
        self.assertEqual((s["exam_on_top"], s["cover_delay_seconds"], s["unlock_minutes"]), (1, 8, 10))
        c.call("PUT", "/api/settings", {"exam_on_top": 0, "cover_delay_seconds": 5, "unlock_minutes": 0})

    def test_exam_text_can_be_edited_and_reset(self):
        c = self.login()
        status, s = c.call("PUT", "/api/settings", {"intro_title": "  Hi! Pass to open {app}  ", "intro_message": "Take your time."})
        self.assertEqual((s["intro_title"], s["intro_message"]), ("Hi! Pass to open {app}", "Take your time."))
        self.assertEqual(c.call("PUT", "/api/settings", {"intro_title": "x" * 121})[0], 400)
        status, s = c.call("PUT", "/api/settings", {"intro_title": "", "intro_message": "   "})
        self.assertEqual(s["intro_title"], db.DEFAULT_TEXT_SETTINGS["intro_title"])
        self.assertEqual(s["intro_message"], db.DEFAULT_TEXT_SETTINGS["intro_message"])

    def test_mascot_and_new_dashboard_numbers(self):
        c = self.login()
        status, body, res = c.call("GET", "/mascot.svg", raw=True)
        self.assertEqual(status, 200)
        self.assertTrue(res.getheader("Content-Type").startswith("image/svg+xml"))
        self.assertIn(b"<svg", body)
        status, o = c.call("GET", "/api/overview")
        for key in ("questions_added_30d", "pass_rate", "protected_apps", "guard_enabled"):
            self.assertIn(key, o)
        self.assertEqual(o["protected_apps"], 2)          # Roblox + Roblox Studio
        self.assertTrue(o["guard_enabled"])

    def test_protection_switch_and_learner_name(self):
        c = self.login()
        self.assertEqual(c.call("GET", "/api/settings")[1]["guard_enabled"], 1)
        status, s = c.call("PUT", "/api/settings", {"guard_enabled": 0})
        self.assertEqual((status, s["guard_enabled"]), (200, 0))
        self.assertFalse(c.call("GET", "/api/overview")[1]["guard_enabled"])
        self.assertEqual(c.call("PUT", "/api/settings", {"guard_enabled": 2})[0], 400)
        c.call("PUT", "/api/settings", {"guard_enabled": 1})
        status, s = c.call("PUT", "/api/settings", {"learner_name": "  Jamie "})
        self.assertEqual(s["learner_name"], "Jamie")
        self.assertEqual(c.call("PUT", "/api/settings", {"learner_name": "x" * 41})[0], 400)
        self.assertEqual(c.call("PUT", "/api/settings", {"learner_name": ""})[1]["learner_name"], "")

    def test_preview_quiz_opens_one_window_and_needs_login(self):
        self.assertEqual(Client().call("POST", "/api/preview-quiz", {})[0], 401)
        c = self.login()
        started = []

        class FakeProc:
            def poll(self):
                return None  # still running

        saved = dashboard_server._spawn_preview
        dashboard_server._spawn_preview = lambda: started.append(1) or FakeProc()
        dashboard_server._preview["proc"] = None
        try:
            self.assertEqual(c.call("POST", "/api/preview-quiz", {})[1], {"ok": True, "already_open": False})
            self.assertEqual(c.call("POST", "/api/preview-quiz", {})[1], {"ok": True, "already_open": True})
            self.assertEqual(len(started), 1)              # the second click does not open another window
        finally:
            dashboard_server._spawn_preview = saved
            dashboard_server._preview["proc"] = None

    def test_per_app_exam_rules(self):
        c = self.login()
        subjects = c.call("GET", "/api/subjects")[1]
        status, app = c.call("POST", "/api/apps", {"name": "Minecraft Rules", "bundle_id": "",
                                                    "questions_per_quiz": 5, "passing_score": 80,
                                                    "unlock_minutes": 30, "exams_required": 2,
                                                    "subject_ids": [subjects[0]["id"], subjects[1]["id"]]})
        self.assertEqual(status, 200, app)
        self.assertEqual(app["effective"]["questions_per_quiz"], 5)
        self.assertEqual(app["effective"]["exams_required"], 2)
        self.assertEqual(app["subject_ids"], sorted([subjects[0]["id"], subjects[1]["id"]]))
        # an app with no overrides shows the global defaults
        status, plain = c.call("POST", "/api/apps", {"name": "Plain Defaults"})
        self.assertEqual(status, 200)
        self.assertIsNone(plain["passing_score"])
        self.assertEqual(plain["effective"]["passing_score"], c.call("GET", "/api/settings")[1]["passing_score"])
        # clearing a value goes back to the default; bad values are rejected
        status, back = c.call("PUT", f"/api/apps/{app['id']}", {"passing_score": None, "subject_ids": []})
        self.assertEqual(status, 200)
        self.assertIsNone(back["passing_score"])
        self.assertIsNone(back["subject_ids"])
        self.assertEqual(back["questions_per_quiz"], 5)  # untouched fields are kept
        for body in ({"passing_score": 0}, {"passing_score": 101}, {"exams_required": 9}, {"questions_per_quiz": "x"},
                     {"unlock_minutes": -1}, {"subject_ids": [999999]}, {"subject_ids": "all"}):
            self.assertEqual(c.call("PUT", f"/api/apps/{app['id']}", body)[0], 400, body)
        # the old simple update still works (toggle only)
        self.assertEqual(c.call("PUT", f"/api/apps/{app['id']}", {"enabled": False})[1]["enabled"], False)
        for a in (app, plain):
            c.call("DELETE", f"/api/apps/{a['id']}")

    def test_app_presets(self):
        c = self.login()
        status, presets = c.call("GET", "/api/app-presets")
        self.assertEqual(status, 200)
        names = [p["name"] for p in presets]
        self.assertIn("Roblox", names)
        self.assertTrue(any(n.startswith("Minecraft") for n in names))
        self.assertGreaterEqual(len(presets), 8)

    def test_restricted_apps(self):
        c = self.login()
        status, apps = c.call("GET", "/api/apps")
        names = {a["name"] for a in apps}
        self.assertTrue({"Roblox", "Roblox Studio"} <= names)
        self.assertNotIn("Safari", names)  # only Roblox is guarded by default
        status, created = c.call("POST", "/api/apps", {"name": "Minecraft", "bundle_id": "com.mojang.minecraft"})
        self.assertEqual(status, 200)
        self.assertEqual(c.call("POST", "/api/apps", {"name": "Minecraft", "bundle_id": "com.mojang.minecraft"})[0], 409)
        self.assertEqual(c.call("POST", "/api/apps", {"name": "x", "bundle_id": "bad id!"})[0], 400)
        self.assertEqual(c.call("PUT", f"/api/apps/{created['id']}", {"enabled": False})[1]["enabled"], False)
        self.assertEqual(c.call("DELETE", f"/api/apps/{created['id']}")[0], 200)

    # ---------------------------------------------------------------- import / export / progress
    def test_export_download_and_import(self):
        c = self.login()
        status, body, res = c.call("GET", "/api/export?format=json", raw=True)
        self.assertEqual(status, 200)
        self.assertIn("attachment", res.getheader("Content-Disposition"))
        bank = json.loads(body)
        self.assertGreaterEqual(len(bank["subjects"]), 8)
        status, body, _ = c.call("GET", "/api/export?format=csv", raw=True)
        self.assertTrue(body.startswith(b"\xef\xbb\xbfsubject,question"))
        status, stats = c.call("POST", "/api/import", {"format": "json", "mode": "merge", "content": json.dumps(bank)})
        self.assertEqual((status, stats["questions_added"]), (200, 0))
        self.assertEqual(c.call("POST", "/api/import", {"format": "json", "mode": "replace", "content": json.dumps(bank)})[0], 400)
        self.assertEqual(c.call("POST", "/api/import", {"format": "json", "content": "{not json"})[0], 400)

    def test_progress_endpoints(self):
        c = self.login()
        for path in ["/api/overview", "/api/progress", "/api/attempts", "/api/installed-apps"]:
            self.assertEqual(c.call("GET", path)[0], 200, path)
        self.assertEqual(c.call("GET", "/api/attempts/999999")[0], 404)
        self.assertEqual(c.call("POST", "/api/lock-now", {})[0], 200)

    def test_logout_ends_session(self):
        c = self.login()
        self.assertEqual(c.call("POST", "/api/logout", {})[0], 200)
        self.assertEqual(c.call("GET", "/api/overview")[0], 401)

    def test_server_refuses_non_loopback_bind(self):
        with self.assertRaises(ValueError):
            dashboard_server.make_server("0.0.0.0", 0)


if __name__ == "__main__":
    unittest.main()
