"""Exercises Monitor.tick() with a fake process list (no macOS needed)."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
_TMP = tempfile.mkdtemp(prefix="ah-mon-")
os.environ.update(ACADEMIC_HUB_DATA=_TMP, ACADEMIC_HUB_LOGS=_TMP)

from academic_hub import db, macos, monitor, quiz_engine  # noqa: E402

ROBLOX = ("Roblox", "com.roblox.RobloxPlayer")
STUDIO = ("Roblox Studio", "com.roblox.RobloxStudio")
SAFARI = ("Safari", "com.apple.Safari")
NOTES = ("Notes", "com.apple.Notes")


class FakeApp(macos.RunningApp):
    killed = False

    def terminate(self):
        self.killed = True


class MonitorLoop(unittest.TestCase):
    def setUp(self):
        os.environ["ACADEMIC_HUB_DATA"] = tempfile.mkdtemp(prefix="ah-mon-", dir=_TMP)  # fresh DB per test
        self.mon = monitor.Monitor()
        self.started = []
        self.mon.start_quiz = lambda name, bundle: self.started.append((name, bundle))
        self.running = []
        macos.running_apps = lambda: self.running

    def launch(self, *apps):
        self.running = [FakeApp(pid=100 + i, name=n, bundle_id=b) for i, (n, b) in enumerate(apps)]
        return self.running

    def test_roblox_is_closed_and_exam_started(self):
        roblox, notes = self.launch(ROBLOX, NOTES)
        self.mon.tick()
        self.assertTrue(roblox.killed)
        self.assertFalse(notes.killed)
        self.assertEqual(self.started, [("Roblox", "com.roblox.RobloxPlayer")])

    def test_everything_else_is_left_alone_including_safari(self):
        safari, notes = self.launch(SAFARI, NOTES)
        self.mon.tick()
        self.assertFalse(safari.killed or notes.killed)
        self.assertEqual(self.started, [])

    def test_unlocked_app_is_left_alone_then_relocked_after_it_closes(self):
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertFalse(roblox.killed)
        self.assertEqual(self.started, [])

        self.running = []  # learner quits Roblox
        grace = db.get_int(self.mon.conn, "reopen_grace_seconds")
        self.mon.last_seen["com.roblox.RobloxPlayer"] -= grace + 5
        self.mon.conn.execute("UPDATE unlocks SET granted_at = granted_at - ?", (grace + 5,))
        self.mon.tick()
        self.assertIsNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))

        (roblox,) = self.launch(ROBLOX)  # reopening needs a new exam
        self.mon.tick()
        self.assertTrue(roblox.killed)
        self.assertEqual(len(self.started), 1)

    def test_exam_comes_back_right_after_roblox_is_closed(self):
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.mon.conn.execute("UPDATE unlocks SET granted_at = granted_at - 60")  # passed a minute ago
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()                                     # plays Roblox
        self.assertFalse(roblox.killed)
        self.running = []                                   # closes Roblox
        self.mon.last_seen["com.roblox.RobloxPlayer"] -= monitor.CLOSE_DEBOUNCE + 1
        self.mon.tick()
        self.assertIsNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))
        (roblox,) = self.launch(ROBLOX)                     # opens it again, well inside 180 s
        self.mon.tick()
        self.assertTrue(roblox.killed)
        self.assertEqual(self.started, [("Roblox", "com.roblox.RobloxPlayer")])

    def test_short_flicker_of_the_process_does_not_relock(self):
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.launch(ROBLOX)
        self.mon.tick()
        self.running = []                                   # launcher hands over to the game
        self.mon.tick()
        self.assertIsNotNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))

    def test_child_has_time_to_press_play_after_passing(self):
        # Roblox is started from its website, so right after a pass it is usually not running yet.
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.running = []
        self.mon.conn.execute("UPDATE unlocks SET granted_at = granted_at - 90")  # 90 s later
        self.mon.tick()
        self.assertIsNotNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))
        (roblox,) = self.launch(ROBLOX)  # presses Play: no second exam
        self.mon.tick()
        self.assertFalse(roblox.killed)
        self.assertEqual(self.started, [])

    def test_grace_length_is_a_setting(self):
        db.set_setting(self.mon.conn, "reopen_grace_seconds", 30)
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.running = []
        self.mon.conn.execute("UPDATE unlocks SET granted_at = granted_at - 45")
        self.mon.tick()
        self.assertIsNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))

    def test_fresh_unlock_survives_the_gap_before_the_app_launches(self):
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.running = []  # exam just passed; Roblox is still starting
        self.mon.tick()
        self.assertIsNotNone(quiz_engine.active_unlock(self.mon.conn, "com.roblox.RobloxPlayer"))

    def test_disabled_rule_is_not_enforced(self):
        self.mon.conn.execute("UPDATE restricted_apps SET enabled = 0 WHERE name = 'Roblox'")
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertFalse(roblox.killed)

    def test_protection_switch_pauses_all_blocking(self):
        db.set_setting(self.mon.conn, "guard_enabled", 0)
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertFalse(roblox.killed)
        self.assertEqual(self.started, [])
        db.set_setting(self.mon.conn, "guard_enabled", 1)  # switched back on: guarded again
        self.mon.tick()
        self.assertTrue(roblox.killed)

    def test_parent_can_still_add_safari_back(self):
        self.mon.conn.execute("INSERT INTO restricted_apps(name, bundle_id) VALUES ('Safari', 'com.apple.Safari')")
        (safari,) = self.launch(SAFARI)
        self.mon.tick()
        self.assertTrue(safari.killed)

    def test_expired_timed_unlock_blocks_again(self):
        db.set_setting(self.mon.conn, "unlock_minutes", 5)
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.mon.conn.execute("UPDATE unlocks SET expires_at = ?", (db.now() - 1,))
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertTrue(roblox.killed)
        db.set_setting(self.mon.conn, "unlock_minutes", 0)

    def test_roblox_and_studio_both_covered(self):
        player, studio = self.launch(ROBLOX, STUDIO)
        self.mon.tick()
        self.assertTrue(player.killed and studio.killed)


class ExamOnTop(unittest.TestCase):
    launch = MonitorLoop.launch
    """Exam-on-top mode: Roblox keeps running while the exam is shown over it."""

    def setUp(self):
        os.environ["ACADEMIC_HUB_DATA"] = tempfile.mkdtemp(prefix="ah-mon-", dir=_TMP)
        self.mon = monitor.Monitor()
        self.started = []
        self.running = []
        macos.running_apps = lambda: self.running
        db.set_setting(self.mon.conn, "exam_on_top", 1)
        db.set_setting(self.mon.conn, "cover_delay_seconds", 5)
        self.exam_up = False

        def start(name, bundle):
            self.started.append((name, bundle))
            self.exam_up = True

        self.mon.start_quiz = start
        self.mon.quiz_running = lambda: self.exam_up

    def wait(self, seconds):
        for key in list(self.mon.blocked_since):
            self.mon.blocked_since[key] -= seconds

    def test_roblox_is_not_closed_and_exam_appears_after_the_delay(self):
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertEqual(self.started, [])          # a few seconds of waiting first
        self.wait(6)
        self.mon.tick()
        self.assertEqual(len(self.started), 1)
        self.assertFalse(roblox.killed)

    def test_exam_stays_up_without_restarting_or_closing_roblox(self):
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick(); self.wait(6); self.mon.tick()
        for _ in range(5):
            self.mon.tick()
        self.assertEqual(len(self.started), 1)
        self.assertFalse(roblox.killed)

    def test_leaving_the_exam_without_a_pass_closes_roblox(self):
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick(); self.wait(6); self.mon.tick()
        self.exam_up = False                          # Exit button + PIN, or a crash
        self.mon.tick()
        self.assertTrue(roblox.killed)

    def test_passing_keeps_roblox_running_and_the_exam_returns_when_time_is_up(self):
        db.set_setting(self.mon.conn, "unlock_minutes", 10)
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick(); self.wait(6); self.mon.tick()
        quiz_engine.grant_unlock(self.mon.conn, "com.roblox.RobloxPlayer", "Roblox")
        self.exam_up = False
        self.mon.tick()
        self.assertFalse(roblox.killed)
        self.assertEqual(len(self.started), 1)

        self.mon.conn.execute("UPDATE unlocks SET expires_at = ?", (db.now() - 1,))   # 10 minutes later
        self.mon.tick()                                # unlock expires, delay starts
        self.assertEqual(len(self.started), 1)
        self.wait(6)
        self.mon.tick()
        self.assertEqual(len(self.started), 2)         # exam over Roblox again
        self.assertFalse(roblox.killed)

    def test_zero_delay_shows_the_exam_at_once(self):
        db.set_setting(self.mon.conn, "cover_delay_seconds", 0)
        (roblox,) = self.launch(ROBLOX)
        self.mon.tick()
        self.assertEqual(len(self.started), 1)
        self.assertFalse(roblox.killed)

    def test_other_apps_are_still_left_alone(self):
        safari, = self.launch(SAFARI)
        self.mon.tick(); self.wait(60); self.mon.tick()
        self.assertEqual(self.started, [])
        self.assertFalse(safari.killed)


if __name__ == "__main__":
    unittest.main()
