"""Windows code paths, run on any computer with fake psutil / fake child processes."""

import json
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
_TMP = tempfile.mkdtemp(prefix="ah-win-")
os.environ.setdefault("ACADEMIC_HUB_DATA", _TMP)
os.environ.setdefault("ACADEMIC_HUB_LOGS", _TMP)

from academic_hub import config, macos, monitor, supervisor, winos  # noqa: E402


class FakeProc:
    def __init__(self, pid, name, owner="kid", exe=None):
        self.pid, self.info, self._owner = pid, {"name": name, "exe": exe}, owner
        self.killed = False

    def username(self):
        return f"PC\\{self._owner}"

    def kill(self):
        self.killed = True


def fake_psutil(procs):
    mod = types.ModuleType("psutil")
    mod.process_iter = lambda attrs=None: list(procs)
    mod.NoSuchProcess = type("NoSuchProcess", (Exception,), {})
    mod.AccessDenied = type("AccessDenied", (Exception,), {})
    return mod


class WindowsAppListTests(unittest.TestCase):
    def setUp(self):
        winos._mine_cache.clear()
        self.getuser = mock.patch("getpass.getuser", return_value="Kid")
        self.getuser.start()

    def tearDown(self):
        self.getuser.stop()

    def test_roblox_is_recognised_by_its_exe_and_shown_as_Roblox(self):
        procs = [FakeProc(10, "RobloxPlayerBeta.exe"), FakeProc(11, "notepad.exe")]
        with mock.patch.dict(sys.modules, {"psutil": fake_psutil(procs)}):
            apps = winos.running_apps(macos.RunningApp)
        by_id = {a.bundle_id: a for a in apps}
        self.assertEqual(by_id["RobloxPlayerBeta.exe"].name, "Roblox")
        self.assertEqual(by_id["notepad.exe"].name, "notepad")
        rules = [{"name": "Roblox", "bundle_id": "RobloxPlayerBeta.exe", "enabled": 1}]
        self.assertIsNotNone(monitor.find_rule(rules, "Roblox", "RobloxPlayerBeta.exe"))
        self.assertIsNotNone(monitor.find_rule(rules, "x", "robloxplayerbeta.EXE"))  # file names ignore case
        self.assertIsNone(monitor.find_rule(rules, "notepad", "notepad.exe"))

    def test_other_accounts_programs_are_never_touched(self):
        procs = [FakeProc(20, "RobloxPlayerBeta.exe", owner="parent"), FakeProc(21, "RobloxPlayerBeta.exe", owner="KID")]
        with mock.patch.dict(sys.modules, {"psutil": fake_psutil(procs)}):
            apps = winos.running_apps(macos.RunningApp)
        self.assertEqual([a.pid for a in apps], [21])

    def test_terminate_kills_the_process(self):
        proc = FakeProc(30, "RobloxPlayerBeta.exe")
        with mock.patch.dict(sys.modules, {"psutil": fake_psutil([proc])}), mock.patch.object(macos, "IS_WIN", True):
            macos.RunningApp(pid=30, name="Roblox", bundle_id="RobloxPlayerBeta.exe", _ref=proc).terminate()
        self.assertTrue(proc.killed)

    def test_picker_lists_running_programs_but_not_windows_itself(self):
        procs = [
            FakeProc(1, "RobloxPlayerBeta.exe", exe="C:\\Users\\kid\\AppData\\Local\\Roblox\\RobloxPlayerBeta.exe"),
            FakeProc(2, "svchost.exe", exe="C:\\Windows\\System32\\svchost.exe"),
        ]
        with mock.patch.dict(sys.modules, {"psutil": fake_psutil(procs)}), mock.patch.dict(os.environ, {"SystemRoot": "C:\\Windows"}):
            found = winos.installed_apps()
        self.assertEqual([a["bundle_id"] for a in found], ["RobloxPlayerBeta.exe"])


class WindowsPathsTests(unittest.TestCase):
    def test_data_and_logs_live_in_local_app_data_on_windows(self):
        base = tempfile.mkdtemp()
        env = {"LOCALAPPDATA": base}
        with mock.patch.object(config.sys, "platform", "win32"), mock.patch.dict(os.environ, env):
            os.environ.pop("ACADEMIC_HUB_DATA", None)
            os.environ.pop("ACADEMIC_HUB_LOGS", None)
            self.assertEqual(config.data_dir(), Path(base) / "AcademicHub" / "data")
            self.assertEqual(config.log_dir(), Path(base) / "AcademicHub" / "logs")
        os.environ["ACADEMIC_HUB_DATA"] = _TMP
        os.environ["ACADEMIC_HUB_LOGS"] = _TMP

    def test_children_get_no_console_window_on_windows(self):
        import subprocess

        with mock.patch.object(config.sys, "platform", "win32"), \
             mock.patch.object(subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True), \
             mock.patch.object(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x200, create=True):
            self.assertEqual(config.detached_popen_kwargs(), {"creationflags": 0x08000000 | 0x200})
        self.assertEqual(config.detached_popen_kwargs(), {"start_new_session": True})


class SupervisorTests(unittest.TestCase):
    class FakeChild:
        def __init__(self):
            self.alive = True
            self.terminated = False

        def poll(self):
            return None if self.alive else 1

        def terminate(self):
            self.terminated = True

    def make(self):
        self.now = 1000.0
        self.spawned = []

        def popen(cmd, **kw):
            child = self.FakeChild()
            self.spawned.append((cmd[-1], child))
            return child

        return supervisor.Supervisor({}, popen=popen, clock=lambda: self.now)

    def test_starts_both_helpers_and_restarts_one_that_stops(self):
        sup = self.make()
        sup.step()
        self.assertEqual([m for m, _ in self.spawned], list(supervisor.SERVICES))
        sup.step()
        self.assertEqual(len(self.spawned), 2)                       # both alive: nothing new
        monitor_child = self.spawned[0][1]
        monitor_child.alive = False                                   # the monitor is killed
        sup.step()
        self.assertEqual(len(self.spawned), 2)                       # too soon, wait
        self.now += supervisor.RESTART_DELAY + 1
        sup.step()
        self.assertEqual(len(self.spawned), 3)
        self.assertEqual(self.spawned[2][0], "academic_hub.monitor")
        self.assertEqual(sup.restarts, 1)

    def test_stop_all_ends_the_helpers(self):
        sup = self.make()
        sup.step()
        sup.stop_all()
        self.assertTrue(all(c.terminated for _, c in self.spawned))

    def test_only_the_protected_account_is_guarded(self):
        with mock.patch("getpass.getuser", return_value="Kid"):
            self.assertTrue(supervisor.protected_here({"user": "kid"}))
            self.assertFalse(supervisor.protected_here({"user": "mum"}))
            self.assertTrue(supervisor.protected_here({}))  # empty = everyone

    def test_settings_file_is_read(self):
        folder = Path(tempfile.mkdtemp())
        (folder / "config.json").write_text(json.dumps({"user": "kid", "port": 9000}), encoding="utf-8-sig")
        with mock.patch.object(supervisor, "config_file", return_value=folder / "config.json"):
            self.assertEqual(supervisor.load_settings()["port"], 9000)
        with mock.patch.object(supervisor, "config_file", return_value=folder / "missing.json"):
            self.assertEqual(supervisor.load_settings(), {})

    def test_nothing_happens_off_windows(self):
        self.assertFalse(supervisor.ensure_running())
        self.assertEqual(supervisor.main(), 0)


if __name__ == "__main__":
    unittest.main()
