"""Core logic tests. Run:  python3 -m unittest discover -s tests -v"""

import json
import os
import random
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
_TMP = tempfile.mkdtemp(prefix="ah-test-")
os.environ["ACADEMIC_HUB_DATA"] = _TMP
os.environ["ACADEMIC_HUB_LOGS"] = _TMP

from academic_hub import bank_io, db, monitor, progress, quiz_engine, security  # noqa: E402


def fresh_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    db.init_db(conn)
    return conn


def play(conn, wrong: int, rng=None):
    """Run a whole session, answering `wrong` questions incorrectly."""
    session = quiz_engine.build_session(conn, rng)
    attempt = quiz_engine.start_attempt(conn, "Roblox", "com.roblox.RobloxPlayer")
    for i, q in enumerate(session):
        pick = q["correct_index"]
        if i < wrong:
            pick = (pick + 1) % len(q["choices"])
        quiz_engine.record_answer(conn, attempt, q, pick)
    return quiz_engine.finish_attempt(conn, attempt, len(session)), session


class SeedAndSession(unittest.TestCase):
    def setUp(self):
        self.conn = fresh_conn()

    def test_eight_subjects_ten_questions_each(self):
        rows = self.conn.execute(
            "SELECT s.name, COUNT(*) n FROM subjects s JOIN questions q ON q.subject_id = s.id GROUP BY s.id"
        ).fetchall()
        self.assertEqual(len(rows), 8)
        self.assertTrue(all(r["n"] == 10 for r in rows))
        names = {r["name"] for r in rows}
        for expected in ["Mathematics", "Science", "English", "Filipino", "Araling Panlipunan",
                         "MAPEH", "Computer Studies", "General Knowledge"]:
            self.assertIn(expected, names)

    def test_every_seed_question_is_valid(self):
        for row in self.conn.execute("SELECT * FROM questions"):
            data = {"text": row["text"], "choices": json.loads(row["choices"]),
                    "correct_index": row["correct_index"], "explanation": row["explanation"]}
            bank_io.clean_question(data)  # raises if invalid (duplicates, bad index, ...)
            self.assertTrue(row["explanation"], f"missing explanation: {row['text']}")

    def test_default_exam_is_10_questions_spread_over_the_subjects(self):
        self.assertEqual(db.get_int(self.conn, "questions_per_quiz"), 10)
        for seed in range(20):
            session = quiz_engine.build_session(self.conn, random.Random(seed))
            self.assertEqual(len(session), 10)
            per = {}
            for q in session:
                per[q["subject_name"]] = per.get(q["subject_name"], 0) + 1
            self.assertEqual(len(per), 8)                    # every subject appears
            self.assertTrue(set(per.values()) <= {1, 2})     # 10 over 8 subjects: one or two each
            self.assertEqual(len({q["question_id"] for q in session}), 10)

    def test_exam_is_shown_in_subject_order(self):
        session = quiz_engine.build_session(self.conn, random.Random(3))
        order = [r["name"] for r in self.conn.execute("SELECT name FROM subjects ORDER BY position, id")]
        positions = [order.index(q["subject_name"]) for q in session]
        self.assertEqual(positions, sorted(positions))

    def test_extra_questions_rotate_between_subjects(self):
        doubled = set()
        for seed in range(30):
            counts = {}
            for q in quiz_engine.build_session(self.conn, random.Random(seed)):
                counts[q["subject_name"]] = counts.get(q["subject_name"], 0) + 1
            doubled |= {name for name, n in counts.items() if n == 2}
        self.assertGreater(len(doubled), 4)  # not always the same two subjects

    def test_shuffle_keeps_correct_answer_correct(self):
        originals = {r["id"]: json.loads(r["choices"])[r["correct_index"]]
                     for r in self.conn.execute("SELECT * FROM questions")}
        for q in quiz_engine.build_session(self.conn, random.Random(7)):
            self.assertEqual(q["choices"][q["correct_index"]], originals[q["question_id"]])

    def test_retries_rotate_through_the_bank(self):
        _, first = play(self.conn, 40, random.Random(1))
        _, second = play(self.conn, 40, random.Random(2))
        # 10 per subject and at most 2 shown per subject each time: unseen ones come first.
        self.assertFalse({q["question_id"] for q in first} & {q["question_id"] for q in second})

    def test_disabled_subject_and_inactive_question_are_skipped(self):
        self.conn.execute("UPDATE subjects SET enabled = 0 WHERE name = 'MAPEH'")
        self.conn.execute("UPDATE questions SET active = 0 WHERE subject_id = "
                          "(SELECT id FROM subjects WHERE name = 'Science') AND id % 2 = 0")
        session = quiz_engine.build_session(self.conn)
        self.assertNotIn("MAPEH", {q["subject_name"] for q in session})
        self.assertEqual(len(session), 10)  # still a full 10: the other subjects fill the gap
        self.assertEqual(len({q["subject_name"] for q in session}), 7)

    def test_no_questions_raises(self):
        self.conn.execute("UPDATE questions SET active = 0")
        with self.assertRaises(quiz_engine.NoQuestionsError):
            quiz_engine.build_session(self.conn)

    def test_questions_per_quiz_setting(self):
        db.set_setting(self.conn, "questions_per_quiz", 3)
        session = quiz_engine.build_session(self.conn)
        self.assertEqual(len(session), 3)
        self.assertEqual(len({q["subject_name"] for q in session}), 3)
        db.set_setting(self.conn, "questions_per_quiz", 20)
        self.assertEqual(len(quiz_engine.build_session(self.conn)), 20)
        db.set_setting(self.conn, "questions_per_quiz", 100)
        self.assertEqual(len(quiz_engine.build_session(self.conn)), 80)  # the whole bank, no repeats
        self.assertEqual(quiz_engine.session_size(self.conn), 80)

    def test_small_bank_gives_a_shorter_exam(self):
        self.conn.execute("UPDATE questions SET active = 0 WHERE id > 2")
        self.assertEqual(len(quiz_engine.build_session(self.conn)), 2)
        self.assertEqual(quiz_engine.session_size(self.conn), 2)

    def test_only_roblox_is_restricted_by_default(self):
        rows = self.conn.execute("SELECT name, enabled FROM restricted_apps").fetchall()
        self.assertEqual({r["name"] for r in rows}, {"Roblox", "Roblox Studio"})
        self.assertTrue(all(r["enabled"] for r in rows))

    def test_old_install_has_safari_switched_off_once(self):
        # An install made before this change: Safari rule on, migration flag absent.
        self.conn.execute("DELETE FROM settings WHERE key = 'roblox_only_v1'")
        self.conn.execute("INSERT INTO restricted_apps(name, bundle_id, enabled) VALUES ('Safari', 'com.apple.Safari', 1)")
        db.init_db(self.conn)
        safari = lambda: self.conn.execute("SELECT enabled FROM restricted_apps WHERE name = 'Safari'").fetchone()["enabled"]
        self.assertEqual(safari(), 0)
        roblox = self.conn.execute("SELECT enabled FROM restricted_apps WHERE name = 'Roblox'").fetchone()["enabled"]
        self.assertEqual(roblox, 1)
        # A parent who turns Safari back on keeps it on (the migration never runs twice).
        self.conn.execute("UPDATE restricted_apps SET enabled = 1 WHERE name = 'Safari'")
        db.init_db(self.conn)
        self.assertEqual(safari(), 1)


class Grading(unittest.TestCase):
    def setUp(self):
        self.conn = fresh_conn()

    def test_7_of_10_passes_at_70(self):
        result, _ = play(self.conn, wrong=3)
        self.assertEqual((result["total"], result["correct"], result["score"], result["passed"]), (10, 7, 70, True))

    def test_6_of_10_fails(self):
        result, _ = play(self.conn, wrong=4)
        self.assertEqual((result["correct"], result["score"], result["passed"]), (6, 60, False))

    def test_perfect_and_zero(self):
        self.assertEqual(play(self.conn, 0)[0]["score"], 100)
        zero, _ = play(self.conn, 10)
        self.assertEqual((zero["score"], zero["passed"]), (0, False))

    def test_score_rounds_down_never_up(self):
        # 2 of 3 is 66.6%: it shows as 66 and must not pass a 67 mark.
        db.set_setting(self.conn, "questions_per_quiz", 3)
        db.set_setting(self.conn, "passing_score", 67)
        result, _ = play(self.conn, wrong=1)
        self.assertEqual((result["score"], result["passed"]), (66, False))

    def test_custom_passing_score(self):
        db.set_setting(self.conn, "passing_score", 90)
        result, _ = play(self.conn, wrong=2)  # 8/10 = 80
        self.assertFalse(result["passed"])
        self.assertEqual(result["passing_score"], 90)

    def test_changing_pass_mark_mid_attempt_does_not_move_goalposts(self):
        session = quiz_engine.build_session(self.conn)
        attempt = quiz_engine.start_attempt(self.conn)          # started with 70
        db.set_setting(self.conn, "passing_score", 20)          # parent edits the setting
        for i, q in enumerate(session):
            quiz_engine.record_answer(self.conn, attempt, q, (q["correct_index"] + 1) % len(q["choices"]) if i < 5 else q["correct_index"])
        self.assertFalse(quiz_engine.finish_attempt(self.conn, attempt, len(session))["passed"])

    def test_history_survives_question_deletion(self):
        result, _ = play(self.conn, 0)
        self.conn.execute("DELETE FROM questions")
        detail = progress.attempt_detail(self.conn, result["attempt_id"])
        self.assertEqual(len(detail["answers"]), 10)

    def test_progress_views(self):
        play(self.conn, 4)
        play(self.conn, 0)
        p = progress.learning_progress(self.conn)
        self.assertEqual(len(p["by_subject"]), 8)
        self.assertEqual(p["failed_before_first_pass"], 1)
        self.assertEqual(len(p["trend"]), 2)
        o = progress.overview(self.conn)
        self.assertEqual((o["attempts"], o["passed"], o["best_score"], o["session_size"]), (2, 1, 100, 10))


class Unlocks(unittest.TestCase):
    def setUp(self):
        self.conn = fresh_conn()

    def test_locked_until_granted_then_revoked(self):
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "com.apple.Safari"))
        quiz_engine.grant_unlock(self.conn, "com.apple.Safari", "Safari")
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, "com.apple.Safari"))
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "com.roblox.RobloxPlayer"))
        quiz_engine.revoke_unlocks(self.conn, "com.apple.Safari")
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "com.apple.Safari"))

    def test_only_one_live_unlock_per_app(self):
        quiz_engine.grant_unlock(self.conn, "com.apple.Safari", "Safari")
        quiz_engine.grant_unlock(self.conn, "com.apple.Safari", "Safari")
        quiz_engine.grant_unlock(self.conn, "com.roblox.RobloxPlayer", "Roblox")
        live = self.conn.execute("SELECT bundle_id FROM unlocks WHERE active = 1").fetchall()
        self.assertEqual(sorted(r["bundle_id"] for r in live), ["com.apple.Safari", "com.roblox.RobloxPlayer"])

    def test_timed_unlock_expires(self):
        db.set_setting(self.conn, "unlock_minutes", 10)
        quiz_engine.grant_unlock(self.conn, "x.y", "X")
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, "x.y"))
        self.conn.execute("UPDATE unlocks SET expires_at = ?", (db.now() - 1,))
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "x.y"))

    def test_admin_override_is_logged_and_unlocks(self):
        quiz_engine.record_admin_override(self.conn, "Safari", "com.apple.Safari")
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, "com.apple.Safari"))
        kind = self.conn.execute("SELECT kind FROM attempts").fetchone()["kind"]
        self.assertEqual(kind, "admin_override")
        # an override is not a quiz score
        self.assertEqual(progress.overview(self.conn)["attempts"], 0)
        self.assertEqual(progress.overview(self.conn)["admin_overrides"], 1)


class PinSecurity(unittest.TestCase):
    def setUp(self):
        self.conn = fresh_conn()

    def test_no_pin_means_no_access(self):
        self.assertFalse(security.check_pin(self.conn, "1234")[0])

    def test_hash_is_salted_and_verifies(self):
        a, b = security.hash_pin("2468"), security.hash_pin("2468")
        self.assertNotEqual(a, b)
        self.assertTrue(security.verify_pin_hash("2468", a))
        self.assertFalse(security.verify_pin_hash("2469", a))
        self.assertNotIn("2468", a)

    def test_format_rules(self):
        for bad in ["123", " 1234", "x" * 33, ""]:
            self.assertIsNotNone(security.validate_pin_format(bad), bad)
        self.assertIsNone(security.validate_pin_format("1234"))

    def test_lockout_after_five_failures(self):
        security.set_pin(self.conn, "2468")
        for _ in range(5):
            self.assertFalse(security.check_pin(self.conn, "0000")[0])
        ok, message = security.check_pin(self.conn, "2468")  # correct PIN is refused while locked
        self.assertFalse(ok)
        self.assertIn("Try again", message)
        self.conn.execute("UPDATE settings SET value = '0' WHERE key = 'pin_locked_until'")
        self.assertTrue(security.check_pin(self.conn, "2468")[0])


class ImportExport(unittest.TestCase):
    def setUp(self):
        self.conn = fresh_conn()

    def test_json_roundtrip(self):
        bank = bank_io.export_bank(self.conn)
        other = fresh_conn()
        other.execute("DELETE FROM questions"); other.execute("DELETE FROM subjects")
        stats = bank_io.import_bank(other, json.loads(json.dumps(bank)), "merge")
        self.assertEqual(stats["questions_added"], 80)
        self.assertEqual(other.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"], 80)

    def test_csv_roundtrip(self):
        bank = bank_io.export_bank(self.conn)
        parsed = bank_io.parse_csv(bank_io.bank_to_csv(bank))
        other = fresh_conn()
        other.execute("DELETE FROM questions"); other.execute("DELETE FROM subjects")
        self.assertEqual(bank_io.import_bank(other, parsed)["questions_added"], 80)
        a = {r["text"]: (json.loads(r["choices"]), r["correct_index"]) for r in self.conn.execute("SELECT * FROM questions")}
        b = {r["text"]: (json.loads(r["choices"]), r["correct_index"]) for r in other.execute("SELECT * FROM questions")}
        self.assertEqual(a, b)

    def test_merge_skips_duplicates_replace_wipes(self):
        bank = bank_io.export_bank(self.conn)
        stats = bank_io.import_bank(self.conn, bank, "merge")
        self.assertEqual((stats["questions_added"], stats["questions_skipped"]), (0, 80))
        small = {"subjects": [{"name": "Art", "questions": [
            {"text": "Q?", "choices": ["a", "b"], "correct_index": 1}]}]}
        bank_io.import_bank(self.conn, small, "replace")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"], 1)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) n FROM subjects").fetchone()["n"], 1)

    def test_bad_import_changes_nothing(self):
        bad = {"subjects": [{"name": "New", "questions": [
            {"text": "ok?", "choices": ["a", "b"], "correct_index": 0},
            {"text": "bad", "choices": ["a", "a"], "correct_index": 0}]}]}
        before = self.conn.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"]
        with self.assertRaises(ValueError):
            bank_io.import_bank(self.conn, bad, "merge")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"], before)
        self.assertIsNone(self.conn.execute("SELECT 1 FROM subjects WHERE name = 'New'").fetchone())

    def test_validation_messages(self):
        cases = [
            ({"text": "", "choices": ["a", "b"], "correct_index": 0}, "empty"),
            ({"text": "q", "choices": ["a"], "correct_index": 0}, "2 to"),
            ({"text": "q", "choices": ["a", "b"], "correct_index": 5}, "correct"),
            ({"text": "q", "choices": ["a", ""], "correct_index": 0}, "blank"),
            ({"text": "q", "choices": ["a", "A"], "correct_index": 0}, "different"),
        ]
        for data, word in cases:
            with self.assertRaisesRegex(ValueError, word):
                bank_io.clean_question(data)

    def test_csv_errors_and_letter_mapping(self):
        with self.assertRaisesRegex(ValueError, "missing"):
            bank_io.parse_csv("foo,bar\n1,2\n")
        # blank middle choice: correct=C must still point at the right text after compaction
        text = "subject,question,choice_a,choice_b,choice_c,correct\nS,Q?,x,,z,C\n"
        q = bank_io.parse_csv(text)["subjects"][0]["questions"][0]
        self.assertEqual(q["choices"][q["correct_index"]], "z")


class MonitorRules(unittest.TestCase):
    RULES = [
        {"name": "Safari", "bundle_id": "com.apple.Safari"},
        {"name": "Roblox", "bundle_id": "com.roblox.RobloxPlayer"},
    ]

    def test_bundle_and_prefix_matches(self):
        self.assertIsNotNone(monitor.find_rule(self.RULES, "Safari", "com.apple.Safari"))
        self.assertIsNotNone(monitor.find_rule(self.RULES, "Roblox Studio", "com.roblox.RobloxStudio"))
        self.assertIsNotNone(monitor.find_rule(self.RULES, "Safari Technology Preview", "com.apple.SafariTechnologyPreview"))
        self.assertIsNone(monitor.find_rule(self.RULES, "Notes", "com.apple.Notes"))
        self.assertIsNone(monitor.find_rule(self.RULES, "Finder", "com.apple.finder"))

    def test_short_name_rules_do_not_match_by_prefix(self):
        rules = [{"name": "TV", "bundle_id": ""}]
        self.assertIsNone(monitor.find_rule(rules, "TV Guide Pro", "x.y"))


if __name__ == "__main__":
    unittest.main()
