"""Per-app exam rules: which rule matches, overrides vs defaults, subjects, passing mark, unlock length,
several exams in a row, and upgrading an old database. Run:  python3 -m unittest discover -s tests -v"""

import os
import random
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
_TMP = tempfile.mkdtemp(prefix="ah-rules-")
os.environ.setdefault("ACADEMIC_HUB_DATA", _TMP)
os.environ.setdefault("ACADEMIC_HUB_LOGS", _TMP)

from academic_hub import db, quiz_engine, rules  # noqa: E402

try:
    from PySide6.QtWidgets import QApplication
    HAVE_QT = True
except ImportError:  # pragma: no cover
    HAVE_QT = False
if HAVE_QT:
    from academic_hub import quiz_ui, security  # noqa: E402


def fresh():
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    db.init_db(conn)
    return conn


def add_app(conn, name, bundle="", **cols):
    cur = conn.execute("INSERT INTO restricted_apps(name, bundle_id) VALUES (?, ?)", (name, bundle))
    for k, v in cols.items():
        conn.execute(f"UPDATE restricted_apps SET {k} = ? WHERE id = ?", (v, cur.lastrowid))
    return cur.lastrowid


class RuleMatching(unittest.TestCase):
    def test_exact_bundle_beats_name_prefix(self):
        conn = fresh()
        # default rows: "Roblox" (player) and "Roblox Studio"; Studio must get its own rule
        conn.execute("UPDATE restricted_apps SET passing_score = 90 WHERE name = 'Roblox Studio'")
        rows = conn.execute("SELECT * FROM restricted_apps").fetchall()
        studio = rules.find_rule(rows, "Roblox Studio", rows[1]["bundle_id"])
        self.assertEqual(studio["name"], "Roblox Studio")
        self.assertEqual(rules.effective(conn, studio)["passing_score"], 90)

    def test_longest_name_wins_and_unknown_apps_have_no_rule(self):
        conn = fresh()
        add_app(conn, "Minecraft")
        add_app(conn, "Minecraft Education")
        rows = conn.execute("SELECT * FROM restricted_apps").fetchall()
        self.assertEqual(rules.find_rule(rows, "Minecraft Education Edition", "")["name"], "Minecraft Education")
        self.assertEqual(rules.find_rule(rows, "Minecraft Launcher", "")["name"], "Minecraft")
        self.assertIsNone(rules.find_rule(rows, "Notes", "com.apple.Notes"))


class Overrides(unittest.TestCase):
    def test_defaults_then_overrides(self):
        conn = fresh()
        base = rules.defaults(conn)
        self.assertEqual((base["questions_per_quiz"], base["passing_score"], base["exams_required"]), (10, 70, 1))
        add_app(conn, "Minecraft", questions_per_quiz=4, passing_score=100, unlock_minutes=15, exams_required=2)
        r = rules.for_app(conn, "Minecraft", "")
        self.assertEqual((r["questions_per_quiz"], r["passing_score"], r["unlock_minutes"], r["exams_required"]), (4, 100, 15, 2))
        # a default changed later still applies where the app has no override
        db.set_setting(conn, "passing_score", 60)
        add_app(conn, "Discord")
        self.assertEqual(rules.for_app(conn, "Discord", "")["passing_score"], 60)
        self.assertEqual(rules.for_app(conn, "Minecraft", "")["passing_score"], 100)

    def test_session_uses_the_apps_size_and_subjects(self):
        conn = fresh()
        ids = [r["id"] for r in conn.execute("SELECT id FROM subjects ORDER BY id")]
        add_app(conn, "Minecraft", questions_per_quiz=4, subject_ids="[%d, %d]" % (ids[0], ids[1]))
        r = rules.for_app(conn, "Minecraft", "")
        self.assertEqual(quiz_engine.session_size(conn, r), 4)
        session = quiz_engine.build_session(conn, random.Random(3), r)
        self.assertEqual(len(session), 4)
        self.assertEqual({q["subject_id"] for q in session} - {ids[0], ids[1]}, set())
        self.assertEqual({q["subject_id"] for q in session}, {ids[0], ids[1]})  # spread over both
        # other apps still get the global 10 questions over every subject
        self.assertEqual(len(quiz_engine.build_session(conn, random.Random(3))), 10)

    def test_passing_mark_is_stored_per_attempt(self):
        conn = fresh()
        r = {**rules.defaults(conn), "passing_score": 100, "questions_per_quiz": 3}
        session = quiz_engine.build_session(conn, random.Random(1), r)
        attempt = quiz_engine.start_attempt(conn, "Minecraft", "Minecraft", r["passing_score"])
        for i, q in enumerate(session):  # one wrong answer: 66%, below a 100 mark
            pick = q["correct_index"] if i else (q["correct_index"] + 1) % len(q["choices"])
            quiz_engine.record_answer(conn, attempt, q, pick)
        result = quiz_engine.finish_attempt(conn, attempt, len(session))
        self.assertEqual((result["score"], result["passing_score"], result["passed"]), (66, 100, False))

    def test_unlock_length_comes_from_the_app(self):
        conn = fresh()
        db.set_setting(conn, "unlock_minutes", 0)
        quiz_engine.grant_unlock(conn, "x.y", "Minecraft", None, minutes=20)
        row = quiz_engine.active_unlock(conn, "x.y")
        self.assertIsNotNone(row["expires_at"])
        self.assertAlmostEqual(row["expires_at"] - row["granted_at"], 1200, delta=3)
        quiz_engine.grant_unlock(conn, "x.z", "Other")          # no override -> the global default (until closed)
        self.assertIsNone(quiz_engine.active_unlock(conn, "x.z")["expires_at"])
        quiz_engine.grant_unlock(conn, "x.a", "Admin", None, "admin_override", minutes=5)  # admin length is global
        self.assertAlmostEqual(quiz_engine.active_unlock(conn, "x.a")["expires_at"] - db.now(), 1800, delta=3)


class Migration(unittest.TestCase):
    def test_old_database_gets_the_new_columns(self):
        conn = sqlite3.connect(":memory:", isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.executescript("""
            CREATE TABLE restricted_apps (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
              bundle_id TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, UNIQUE (name, bundle_id));
            INSERT INTO restricted_apps(name, bundle_id) VALUES ('Roblox', 'com.roblox.RobloxPlayer');
        """)
        db.init_db(conn)
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(restricted_apps)")}
        self.assertTrue({"questions_per_quiz", "passing_score", "unlock_minutes", "exams_required", "subject_ids"} <= cols)
        row = conn.execute("SELECT * FROM restricted_apps WHERE name = 'Roblox'").fetchone()
        self.assertIsNone(row["passing_score"])           # existing rule keeps using the defaults
        db.init_db(conn)                                    # running it again is harmless


@unittest.skipUnless(HAVE_QT, "PySide6 not installed")
class SeveralExams(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(sys.argv[:1])
        cls.app.setStyleSheet(quiz_ui.STYLE)

    def setUp(self):
        self.conn = db.connect(Path(_TMP) / f"{self._testMethodName}.db")
        db.init_db(self.conn)
        security.set_pin(self.conn, "2468")
        add_app(self.conn, "Minecraft", "com.mojang.minecraftlauncher", questions_per_quiz=3, passing_score=100,
                exams_required=2, unlock_minutes=45)
        self.win = quiz_ui.QuizWindow(self.conn, "Minecraft", "com.mojang.minecraftlauncher", windowed=True, test_mode=False)
        self.win.present()

    def tearDown(self):
        self.win._allow_close = True
        self.win.close()

    def run_exam(self, right: bool):
        self.win.start_quiz()
        self.assertEqual(len(self.win.session), 3)
        for q in self.win.session:
            self.win.choose(q["correct_index"] if right else (q["correct_index"] + 1) % len(q["choices"]))
            self.win.next_question()

    def test_intro_shows_this_apps_rules(self):
        text = self.win.intro_info.text()
        self.assertIn("3 questions", text)
        self.assertIn("100/100", text)
        self.assertIn("2 exams in a row", text)

    def test_two_passes_in_a_row_unlock_for_the_set_time(self):
        self.run_exam(True)
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "com.mojang.minecraftlauncher"))
        self.assertEqual(self.win.passes, 1)
        self.run_exam(True)
        row = quiz_engine.active_unlock(self.conn, "com.mojang.minecraftlauncher")
        self.assertIsNotNone(row)
        self.assertAlmostEqual(row["expires_at"] - row["granted_at"], 45 * 60, delta=3)

    def test_a_fail_between_resets_the_count(self):
        self.run_exam(True)
        self.run_exam(False)
        self.assertEqual(self.win.passes, 0)
        self.run_exam(True)
        self.assertIsNone(quiz_engine.active_unlock(self.conn, "com.mojang.minecraftlauncher"))
        self.run_exam(True)
        self.assertIsNotNone(quiz_engine.active_unlock(self.conn, "com.mojang.minecraftlauncher"))


if __name__ == "__main__":
    unittest.main()
